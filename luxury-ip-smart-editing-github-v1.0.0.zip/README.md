# luxury-ip-smart-editing

轻奢IP智能剪辑🧠。结合口播视频与SRT，确认居中基础字幕，按完整句意断句、选择重点与金句，设计标题、流程图及上下/前后/左右动态排版；按请求搭配画面推拉、人物后方文字、蒙版、语义音效和BGM，并通过可用转换器生成独立可编辑剪映草稿。适用于轻奢口播包装、字幕重点词强调及声画精剪；保留已剪切点，不默认爆点前置。

## 安装

```bash
npx -y skills add your-github-username/luxury-ip-smart-editing -g --all
```

上传后，将命令中的 `your-github-username` 替换成你的 GitHub 用户名或组织名。

## 上传到 GitHub

新建一个名为 `luxury-ip-smart-editing` 的仓库，将本压缩包解压后的全部内容上传到仓库根目录。上传完成后，使用上面的安装命令即可安装；网站下载时可直接提供本压缩包。

## 使用

安装后，可以这样开始：

> 使用 $luxury-ip-smart-editing，结合我的视频和SRT，先确认基础字幕，再按完整句意设计标题、重点、动态排版与授权范围内的声画包装，生成独立可编辑草稿并报告真实验收状态。

## 运行依赖

- 支持 Agent Skills 的客户端
- Python 3（用于运行 Skill 内脚本）

## 内容

本仓库只发布运行这个 Skill 所需的文件。本地评测样本、预期答案和运行记录不包含在公开包中。
