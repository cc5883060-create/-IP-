// type-metrics.js — 真实字体度量驱动的排版宽度计算
//
// 为什么需要它：原来断句/落位都用「CJK=1，拉丁≈0.52」的粗略模型，但实际成片字体差别极大：
//   造字工房俊雅体（基础字幕）  CJK 推进 = 0.75 em   ← 是 75% 压缩字，同字号下又小又挤
//   思源粗宋（标题/花字/组合）   CJK 推进 = 1.00 em
//   青鸟华光中长宋（细体装饰）   CJK 推进 = 1.00 em
// 下面的表是用 tools/fontmetrics.js 从 assets-src/fonts/ 里逐字读 hmtx 得到的实测值。
//
// 用途：
//   1. 断句时判断一行会不会超宽 / 会不会出画（安全区约束）
//   2. 排版组合落位时算出每一段的真实宽度，从而算出「能位移多少」而不是拍脑袋给百分比

const ADV = {
  JunYa: {
    cjk: 0.75,
    latin: {
      ' ': 0.225, '-': 0.410, '.': 0.222, ',': 0.222,
      '0': 0.4, '1': 0.4, '2': 0.4, '3': 0.4, '4': 0.4, '5': 0.4, '6': 0.4, '7': 0.4, '8': 0.4, '9': 0.4,
      A: 0.582, B: 0.582, C: 0.6, D: 0.62, E: 0.55, F: 0.53, G: 0.62, H: 0.62, I: 0.347, J: 0.4,
      K: 0.598, L: 0.52, M: 0.739, N: 0.62, O: 0.65, P: 0.582, Q: 0.65, R: 0.6, S: 0.55, T: 0.56,
      U: 0.62, V: 0.58, W: 0.82, X: 0.6, Y: 0.56, Z: 0.55,
      a: 0.379, b: 0.448, c: 0.379, d: 0.441, e: 0.399, f: 0.25, g: 0.44, h: 0.44, i: 0.235, j: 0.235,
      k: 0.423, l: 0.218, m: 0.66, n: 0.43, o: 0.430, p: 0.448, q: 0.44, r: 0.326, s: 0.321, t: 0.28,
      u: 0.43, v: 0.40, w: 0.60, x: 0.410, y: 0.40, z: 0.36,
    },
    latinDefault: 0.42,
  },
  TitleHeavy: {
    cjk: 1.0,
    latin: {
      ' ': 0.247, '-': 0.382, '.': 0.340, ',': 0.340,
      '0': 0.608, '1': 0.608, '2': 0.608, '3': 0.608, '4': 0.608, '5': 0.608, '6': 0.608, '7': 0.608, '8': 0.608, '9': 0.608,
      A: 0.761, B: 0.727, C: 0.75, D: 0.78, E: 0.69, F: 0.66, G: 0.78, H: 0.78, I: 0.436, J: 0.5,
      K: 0.785, L: 0.65, M: 1.014, N: 0.78, O: 0.82, P: 0.690, Q: 0.82, R: 0.75, S: 0.69, T: 0.70,
      U: 0.78, V: 0.73, W: 1.03, X: 0.75, Y: 0.70, Z: 0.69,
      a: 0.599, b: 0.689, c: 0.579, d: 0.673, e: 0.586, f: 0.40, g: 0.68, h: 0.66, i: 0.358, j: 0.358,
      k: 0.673, l: 0.366, m: 0.99, n: 0.65, o: 0.637, p: 0.689, q: 0.68, r: 0.520, s: 0.511, t: 0.44,
      u: 0.65, v: 0.62, w: 0.90, x: 0.617, y: 0.62, z: 0.55,
    },
    latinDefault: 0.62,
  },
  HuaGuang: {
    cjk: 1.0,
    latin: {
      ' ': 0.5, '-': 0.582, '.': 0.428, ',': 0.428,
      '0': 0.541, '1': 0.42, '2': 0.5, '3': 0.5, '4': 0.502, '5': 0.5, '6': 0.5, '7': 0.5, '8': 0.5, '9': 0.5,
      A: 0.648, B: 0.590, I: 0.316, K: 0.660, M: 0.758, P: 0.586,
      a: 0.47, b: 0.492, c: 0.449, d: 0.512, e: 0.473, i: 0.297, k: 0.484, l: 0.277,
      o: 0.480, r: 0.367, s: 0.398, x: 0.461,
    },
    latinDefault: 0.48,
  },
};

/** CJK / 全角标点判定 */
const CJK_RE = /[\u1100-\u11ff\u2e80-\u303f\u3040-\u33ff\u3400-\u4dbf\u4e00-\u9fff\ua000-\ua4cf\uac00-\ud7ff\uf900-\ufaff\ufe30-\ufe4f\uff00-\uffef]/;

/** 一个字符的推进宽度（em） */
function charAdv(ch, font) {
  const t = ADV[font] || ADV.TitleHeavy;
  if (CJK_RE.test(ch)) return t.cjk;
  return t.latin[ch] != null ? t.latin[ch] : t.latinDefault;
}

/**
 * 文本推进宽度（em）。不含 letter-spacing 与中西文间隙。
 */
function advanceEm(text, font) {
  let s = 0;
  for (const ch of text) s += charAdv(ch, font);
  return s;
}

/** 该字符是否算「拉丁/数字」（用于中西文间隙判定） */
const LATIN_RE = /[0-9A-Za-z]/;

/**
 * 渲染宽度（px）—— 计入字间距、中西文间隙、重点词放大。
 *
 * 字距规则（与成片 CSS 严格对应）：CJK 之间加 letterSpacing；**拉丁内部不加**
 * （拉丁字母自带侧边距，再加 CJK 式字距会又丑又占宽，长英文行还会直接超宽）；
 * 中西文边界按 letterSpacing 计（CSS 侧由父级 letter-spacing / `.lt` 的 margin-right 实现）。
 *
 * @param {string} text       纯文本（不含标记）
 * @param {object} o
 *   font         'JunYa' | 'TitleHeavy' | 'HuaGuang'
 *   size         字号 px
 *   letterSpacing 字间距 (em)
 *   emphasis     [{start,end}] 重点词区间（按放大倍率计入）
 *   emphasisScale 重点词倍率
 */
function measure(text, o) {
  const { font = 'TitleHeavy', size = 80, letterSpacing = 0, emphasis = [], emphasisScale = 1 } = o || {};
  const chars = [...text];
  let em = 0;
  const gaps = [];
  for (let i = 0; i < chars.length; i++) {
    let a = charAdv(chars[i], font);
    if (emphasis.some((r) => i >= r.start && i < r.end)) a *= emphasisScale;
    em += a;
    if (i === chars.length - 1) break;
    const a0 = LATIN_RE.test(chars[i]), a1 = LATIN_RE.test(chars[i + 1]);
    if (a0 && a1) continue;              // 拉丁内部：不加字距
    em += letterSpacing;
    if (a0 !== a1) gaps.push({ at: i, em: letterSpacing });
  }
  return { px: em * size, em, gaps: gaps.length, chars: chars.length };
}

/** 安全区宽度：canvas 1080 减去两侧内边距 */
function safeWidth(canvasW, inset) { return canvasW - inset * 2; }

module.exports = { ADV, CJK_RE, LATIN_RE, charAdv, advanceEm, measure, safeWidth };
