#!/usr/bin/env node
/** build-sfx-sheet.js — 生成剪映音效落点表（sfx-plan.json）+ 给人看的音效清单（音效清单.md）。 */
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const P = require('./plan.js');
const T = require('./theme.js');
const cues = require('./subtitles.timeline.json');

// 我们的音效角色 → 剪映音效库检索词（用户可直接搜到对应音色）
const SEARCH = {
  'whoosh-deep': '转场-呼啸/低频嗖声（搜「转场 嗖」「whoosh」）',
  'whoosh-soft': '轻柔风声转场（搜「转场 风声」「轻盈 嗖」）',
  'whoosh-thin': '细窄快速划过（搜「转场 快速 细」）',
  tick: 'UI 轻点击（搜「UI 点击」「轻 滴」）',
  land: '落定闷响（搜「落地 咚」「重物落下」）',
  sparkle: '闪光叮（搜「闪光」「亮片 叮」）',
  boom: '低频重音（搜「重音 咚」「低音 冲击」）',
  thud: '闷实撞击（搜「闷响 撞击」）',
  'water-drop': '水滴（搜「水滴」）',
  gear: '机械齿轮（搜「机械 齿轮」「机关」）',
  'variety-in': '综艺弹入（搜「综艺 弹入」「搞怪 弹出」）',
  radio: '收音机对频（搜「收音机」「对频 咔哒」）',
  keyboard: '键盘打字（搜「键盘 打字」）',
  spring: '弹簧回弹（搜「弹簧 咚」「boing」）',
  'water-soft': '柔和水声渐隐（搜「水声 柔和」）',
  'paper-flip': '翻纸（搜「翻纸」「纸张 翻页」）',
  'paper-shake': '纸张抖动（搜「纸张 抖动」「翻书」）',
  'bell-wood': '木铃敲击（搜「木鱼 铃」「木质 敲击」）',
};

const plan = P.buildSfxPlan(cues).map((n) => ({
  at: +n.at.toFixed(3),
  key: n.key,
  file: (T.SFX_ROLE[n.key] || 'pop') + '.mp3',
  vol: T.SFX_VOL[n.key] != null ? T.SFX_VOL[n.key] : 0.16,
  why: n.why || '',
}));

fs.writeFileSync(path.join(ROOT, 'jianying/sfx-plan.json'), JSON.stringify(plan, null, 1));

const mmss = (t) => `${String(Math.floor(t / 60)).padStart(2, '0')}:${(t % 60).toFixed(2).padStart(5, '0')}`;
const rows = plan.map((p, i) => `| ${i + 1} | ${mmss(p.at)} | ${p.file.replace('.mp3', '')} | ${p.vol} | ${p.why} |`).join('\n');
const types = [...new Set(plan.map((p) => p.file))];
const typeRows = types.map((f) => `| ${f.replace('.mp3', '')} | ${SEARCH[f.replace('.mp3', '')] || '—'} | ${plan.filter((p) => p.file === f).length} 处 |`).join('\n');

fs.writeFileSync(path.join(ROOT, 'jianying/音效清单.md'), `# 音效清单（${plan.length} 处）

草稿里已按此表铺好一条 **「音效」轨**（用的就是我们混音成片的那套音源）。若想换成剪映音效库里的原生音色：
在剪映里删掉对应片段，按下表的**检索词**在「音频 → 音效」里搜同类型音色，落点与音量照抄即可。

## 一、按音色类型对照剪映音效库

| 我的音源 | 剪映音效库检索词 | 用量 |
|---|---|---|
${typeRows}

## 二、逐点落点表（对照检查用）

| # | 时间 | 音色 | 音量 | 触发原因 |
|---|---|---|---|---|
${rows}
`);
console.log('sfx-plan:', plan.length, '| 音类:', types.length);
