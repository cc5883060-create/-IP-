#!/usr/bin/env node
/**
 * subset-fonts.js — 把 assets-src/fonts/ 的完整中文字体，按「成片实际用到的字符」子集化，
 * 输出到 public/fonts/*.woff2。
 *
 * 为什么：完整中文字体 5 个加起来 ~61MB，Chrome 每次渲染都要加载，拖慢 3-5 倍。
 * 子集化后通常 < 300KB，渲染更快、交付更轻。
 *
 * 用法：
 *   node subset-fonts.js                 # 自动扫描 public/ 与字幕稿收集字符
 *   node subset-fonts.js --extra "额外字符"
 */
const fs = require('fs');
const path = require('path');
const subsetFont = require('subset-font');

const ROOT = __dirname;
const MASTER = path.join(ROOT, 'assets-src', 'fonts');
const OUT = path.join(ROOT, 'public', 'fonts');

// 字体角色表：角色名 -> 母版文件 + 输出文件
// 角色与主题变量（theme.js 的 F）一一对应；换字体只改这里 + FONTS.md 那张表
const ROLES = [
  { role: 'base',    master: 'JunYa.ttf',                       out: 'JunYa.woff2',      label: '基础字幕 —— 造字工房俊雅体（用户指定）' },
  { role: 'heavy',   master: 'SourceHanSerifSC-Heavy.otf',      out: 'TitleHeavy.woff2', label: '标题主字/重点花字 —— 思源粗宋（用户指定）' },
  { role: 'thin',    master: 'HuaGuangZhongChangSong.ttf',      out: 'HuaGuang.woff2',   label: '细体装饰/红斜杠 —— 青鸟华光中长宋（用户指定）' },
  { role: 'body',    master: 'SourceHanSerifSC-Regular.otf',    out: 'BodySong.woff2',   label: '正文/副说明 —— 思源宋体 Regular' },
  { role: 'tech',    master: 'XiTi.otf',                        out: 'XiTi.woff2',       label: '专业科普细体 —— 思源黑体7号（用户指定「细体」）' },
  { role: 'techH',   master: 'TeHei.otf',                       out: 'TeHei.woff2',      label: '专业科普粗体 —— 思源黑体1号（用户指定「特黑体」）' },
  { role: 'yan',     master: 'AaYanSong.ttf',                   out: 'YanSong.woff2',    label: '备用宋 —— Aa研宋（用户指定「研宋体」）' },
];

/** 收集所有会被渲染出来的字符 */
function collectChars() {
  const buf = [];
  const push = (s) => buf.push(s);

  // 1. 字幕稿
  const subPath = path.join(ROOT, 'subtitles.timeline.json');
  if (fs.existsSync(subPath)) {
    for (const c of JSON.parse(fs.readFileSync(subPath, 'utf8'))) push(c.text || '');
  }
  // 2. 分镜卡片内容
  const sbPath = path.join(ROOT, 'storyboard.json');
  if (fs.existsSync(sbPath)) push(fs.readFileSync(sbPath, 'utf8'));

  // 3. 合成与卡片 HTML 里的可见文本
  const scan = (dir) => {
    if (!fs.existsSync(dir)) return;
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) scan(p);
      else if (/\.(html|js|json|css)$/.test(e.name)) push(fs.readFileSync(p, 'utf8'));
    }
  };
  scan(path.join(ROOT, 'public'));

  const extraIdx = process.argv.indexOf('--extra');
  if (extraIdx > -1 && process.argv[extraIdx + 1]) push(process.argv[extraIdx + 1]);

  // 只要「会被打印」的字符，去掉 HTML/CSS/JS 的结构噪声没意义（宁可多留，保证不漏字）
  const set = new Set();
  for (const chunk of buf) {
    for (const ch of chunk) {
      const cp = ch.codePointAt(0);
      // 控制字符跳过；其余全留（含中英文标点、拉丁、数字）
      if (cp === 9 || cp === 10 || cp === 13) continue;
      if (cp < 32) continue;
      set.add(ch);
    }
  }
  // 常备字符：数字、拉丁、常用中文标点，避免遗漏
  for (const ch of '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz.,:;!?%()[]{}/\\-–—+=<>@#&*\'"“”‘’·…、。，；：！？（）【】《》〈〉「」『』〔〕％－＋×÷＝') {
    set.add(ch);
  }
  set.add(' ');
  return [...set].join('');
}

async function main() {
  const chars = collectChars();
  console.log(`[subset] 字符集大小: ${[...chars].length}`);
  fs.mkdirSync(OUT, { recursive: true });

  let totalBefore = 0;
  let totalAfter = 0;
  for (const r of ROLES) {
    const src = path.join(MASTER, r.master);
    if (!fs.existsSync(src)) {
      console.warn(`[subset] ⚠ 跳过 ${r.role}: 找不到母版 ${r.master}`);
      continue;
    }
    const fontBuf = fs.readFileSync(src);
    let outBuf;
    try {
      outBuf = await subsetFont(fontBuf, chars, { targetFormat: 'woff2' });
    } catch (e) {
      console.warn(`[subset] ⚠ ${r.role} 子集化失败(${e.message})，回退为原文件`);
      outBuf = fontBuf;
    }
    fs.writeFileSync(path.join(OUT, r.out), outBuf);
    const kb = (n) => (n / 1024).toFixed(0) + 'KB';
    console.log(`  ✓ ${r.out.padEnd(20)} ${kb(fontBuf.length).padStart(8)} → ${kb(outBuf.length).padStart(8)}   ${r.label}`);
    totalBefore += fontBuf.length;
    totalAfter += outBuf.length;
  }
  console.log(`[subset] 合计 ${(totalBefore / 1024 / 1024).toFixed(1)}MB → ${(totalAfter / 1024).toFixed(0)}KB`);
}

main().catch((e) => {
  console.error('[subset] 失败:', e);
  process.exit(1);
});
