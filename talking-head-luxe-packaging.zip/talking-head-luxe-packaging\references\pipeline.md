# 管线操作手册（pipeline）

把「粗剪口播 MP4 + SRT」变成「轻奢包装成片」的完整执行步骤。引擎文件在 `scripts/engine/`，资源在 `assets/`。

## 0. 环境事实（勿重新踩坑）

- hyperframes CLI 不在 PATH：`~/.workbuddy/binaries/node/workspace/node_modules/.bin/hyperframes`。
- npm registry 必须用 `https://registry.npmmirror.com`；PyPI 直连与清华镜像不可达，**阿里云镜像 `https://mirrors.aliyun.com/pypi/simple/` 可用**。
- `subset-fonts.js` 依赖 npm 包 `subset-font`（已装在 managed node workspace，运行前确认 `NODE_PATH` 指向它）。
- **Windows 上 `execSync` 调 ffmpeg 读 stdout 管道容易 EBUSY** → 写临时 raw 文件再 `fs.readFileSync`。
- **本机 PATH 上的旧 ffmpeg（剪映自带）libmp3lame 是坏的**：真实音频 → mp3 全静音（lavfi 合成的反而正常）。大音频一律用 WAV 中转；也不支持 `-filter_complex_script`（要内联 `-filter_complex`）。
- `rm` 会被安全钩子拦（`SAFE_DELETE_BULK_CONFIRM_REQUIRED`）→ 渲染输出换版本号文件名，不要先删旧文件。

## 1. 建项目骨架

```
videos/<project>/
  public/            # 合成与资源（index.html、input-video.mp4、sfx/、vendor/、fonts/、bgm.wav）
  assets-src/fonts/  # 母版字体（从 skill assets/fonts-master 复制）
  design-preview/    # 设计门禁输出
  scratch/ qa/ audit/
  plan.js  theme.js  build-*.js  subtitles.timeline.json  FRAME.md
```

复制引擎：`scripts/engine/*.js` → 项目根；`assets/sfx/*.mp3` → `public/sfx/`；`assets/vendor/*` → `public/vendor/`；`assets/fonts-master/*` → `assets-src/fonts/`。若缺音效可跑 `build-sfx.sh` 用 lavfi 重新生成全套。

## 2. 源素材审计

- `ffprobe` 拿分辨率/帧率/时长；导出帧率 = 源帧率（如 50fps）。
- 抽帧看构图：人脸位置、嘴部安全区、是否坐播/走播、有无自带花字。
- **检测原片是否自带 BGM**：`silencedetect` + 语句间隙 RMS 点测。间隙只有房噪（≈-50dB）才能直接垫新 BGM。

## 3. 字幕层（build-subtitles.js）

输入 SRT → 输出 `subtitles.timeline.json`：断句（视觉宽度 CJK=1、拉丁≈0.52，>10 断；11–12 且句意完整→缩 10.7 单位保一行）、重点词 emphasisSpans、排版组合编组（groupId + kind:layout）。断句规则的细节见 design-system.md。

## 4. 写 plan.js（每个片子的核心创作步骤）

以 `plan.template.js` 为底，按 transcript 填：
- `SECTIONS`：章节切分 + 拉丁徽标（TIPS/RULES 类，**不用「符号+点」**）。
- `COMBO_PLAN`：哪些编组做排版组合（上下/前后/左右式）。
- `BROLL_PLAN`：每段的 t0/t1、pip/frame/chrome 形态、exit 出场方式、items 内容。**A-Roll 能讲清的不加图形，B-Roll 才加**。
- `SFX_CONTENT_ACCENTS`：全片真正扛论点的重音词（时间 = 该词的**说话起点**）。
- 插图类需求（如对话框）用 `chat` 字段挂到对应 b-roll 段。

## 5. 构建与门禁

```bash
NODE_PATH=<managed node_modules> node build-composition.js   # → public/index.html
NODE_PATH=<managed node_modules> node subset-fonts.js        # 按成片字符子集化字体
NODE_PATH=<managed node_modules> node build-design-preview.js # → design-preview/
hyperframes lint .                                             # 快，先跑
hyperframes check . --at-transitions --json > ck.json          # 5-6 分钟，必跑
```

- `check` 必须加 `--at-transitions`（tween 边界采样能抓中点漏掉的瞬态溢出）。
- `--json` 输出前有非 JSON 前缀，解析前 `s.slice(s.indexOf('{'))`。
- `escaped_container` / 手机框入场裁剪 / 波纹环出画布 属设计使然的 warn，可接受；**error 必须为 0**。
- layout 门禁用 em-box 而非 ink：思源粗宋行距要 ≥1.44em；刻意分层用 `data-layout-allow-overlap` 显式声明。

## 6. 渲染 + 外挂混音（关键！）

**hyperframes render 混多个 `<audio>` 元素不可靠**（实测 72 个元素只有 source-audio 进成片，52 处音效全丢过一次）。正确姿势：

```bash
hyperframes render public -o <name>_v<N>.mp4 -q delivery --video-bitrate 9500k -f <源帧率>
node build-audio-mix.js        # 读 plan.buildSfxPlan → adelay 卡点 + volume + amix + alimiter → final-mix.wav
ffmpeg -i <rendered>.mp4 -i scratch/final-mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest <final>.mp4
```

- BGM：预做片头 1s 淡入 + 片尾 ~3.7s 淡出，裁到片长，转 **WAV**（躲坏 lame），混入音量 ≈0.14（人声 RMS 下 ~12dB）。
- 验证音频用**频谱对比**（`showspectrumpic`：音乐床=连续宽带，音效=瞬态竖条），别用 astats 点测（帧粒度噪声大易误判）。全片峰值 ≤ -0.8dB。

## 7. 交付 QA

- 从**最终成片**抽 12 帧 tile 接触表：`select='eq(n\,A)+...',scale=270:480,tile=6x2`。
- `snapshot` 用法：`-o/--output --at --no-end`，`--at` 可逗号分隔多时间点；**必须在 `public/` 目录下执行**（`snapshot .`）。
- 同步更新 `FRAME.md`（设计契约）与工作区记忆。

## 8. 从剪映曲库抓 BGM（用户指定剪映音乐时）

`%LOCALAPPDATA%/JianyingPro/User Data/Cache/ressdk_db/*/rp.db`（sqlite）的 `http_cache` 表缓存了曲库 API 响应，按歌名 LIKE 查 `preview_url` 可直接下载完整版；`Cache/music/` 下的 hash mp3 无 ID3 无法反查，别浪费时间。

## 9. 剪映草稿交付（最终交付之一，完整流程见 SKILL.md「剪映草稿最终交付」）

- 顺序：无字幕包装版渲染 → build-jianying-plan → cut-segments → dump-combo-rows → assemble/download（**临时目录**）→ post-process-draft → 安装为新草稿。
- 安装新草稿三步：复制目录到 `E:/JianyingPro Drafts/<中文名>`；**按 JSON 对象递归**替换所有含临时路径的 `path` 字段（正/反斜杠混写至少三种，sed 字符串替换会漏）；对齐 meta 的 fold_path/root_path/name。复核「残留临时路径 = 0 && 全部素材 os.path.isfile」。
- 排版组合三式的关键帧映射与 schema 详见 SKILL.md；文本段只有位置/缩放关键帧，没有 alpha。
- 打开过的草稿会被剪映加密 → 任何返工都要走「重新下载 → post-process → 新目录安装」，旧草稿挪到草稿目录之外归档。

## 10. 常见渲染 bug 速查

- 人脸被暗层带飞 → slide 用在 PIP 版面时缺「孔心跟头+视频回全画幅」A 段。
- 静止亮圆盘 → fade 只动了 opacity，必须同步 scale ×1.5。
- 过渡期半透暗层割裂 → 容器做了 opacity 淡入；蒙版要自己负责可见性，容器恒 opacity:1。
- 观众看到跳变 → 片段 `data-start` 必须 = 过渡起点 − lead − 0.08，早于过渡。
- lint 报 overlapping_gsap_tweens → 同属性两条 tween 边界相触，段间留 10ms。
- 连环 fromTo 起点被覆盖 → 改 `tl.set(初态, 0)` + 多条 `tl.to`。
- 中文字体 Google Fonts 只有 46KB 拉丁子集 → 去剪映缓存 `%LOCALAPPDATA%/JianyingPro/User Data/Cache/AITextTemplate/Resource/*/` 找。
