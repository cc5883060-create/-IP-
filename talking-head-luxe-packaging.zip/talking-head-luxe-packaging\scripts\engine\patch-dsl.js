// patch-dsl.js — keep dsl.json in sync with the current pipeline output.
//
// The HyperFrames composition (public/index.html) is the sole owner of the source
// picture, program audio and its burned-in captions, so the DSL references it as a
// single self-contained HyperFrames item and keeps no second copy of the main video.
// The corrected caption timing/text stays available in subtitles.timeline.json.
const fs = require('fs');
const path = require('path');
const WORK = 'C:/Users/Administrator/WorkBuddy/2026-09-30-12-56-13/videos/broll-skill-recut';

const dslPath = path.join(WORK, 'dsl.json');
const dsl = JSON.parse(fs.readFileSync(dslPath, 'utf8'));
const cues = JSON.parse(fs.readFileSync(path.join(WORK, 'subtitles.timeline.json'), 'utf8'));
const DUR = dsl.totalDuration;

dsl.videoTracks = [
  {
    id: 'graphics',
    type: 'sub',
    videos: [
      {
        id: 'broll-skill-packaging',
        type: 'hyperframes',
        startTime: 0,
        duration: DUR,
        endTime: DUR,
        htmlSourceFilePath: 'public/index.html',
        params: { sourceStartTime: 0, enabled: true },
      },
    ],
  },
];

// captions are burned into the referenced composition — keep the DSL overlay empty
// so a Timeline render cannot double-render them.
dsl.subtitles = [];
dsl.sounds = [];

fs.writeFileSync(dslPath, JSON.stringify(dsl, null, 2), 'utf8');
console.log('dsl patched → tracks:', dsl.videoTracks.map(t => `${t.id}:${t.type}:${t.videos.length}`).join(', '),
  '| captions in composition:', cues.length, '| duration:', DUR);
