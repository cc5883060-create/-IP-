---
name: talking-head-luxe-packaging
description: 把粗剪后的真人出镜口播视频（MP4）加字幕稿（SRT）包装成「轻奢质感」成片的全流程——字幕断句/重点词强调/排版组合、章节标题、b-roll 信息图版面（圆窗 PIP/手机样机/REC 取景框/纯内容）、针点波纹背景、语义音效、BGM 垫乐、门禁校验与 1080p 渲染交付。当用户发来口播/坐播/走播/真人出镜的粗剪视频和 SRT（或逐字稿），要求加字幕、做包装、出成片时使用；也适用于对已有包装成片做返工修改（换 BGM、加插图、调出场动效、补音效）。
agent_created: true
---

# 轻奢口播包装（talking-head-luxe-packaging）

## 用途

输入：粗剪口播 MP4 + SRT 字幕稿。输出：烧入字幕与拼贴包装的 1080p 成片（H.264 / ≈9500kbps / 帧率同源），含字幕三层体系、章节标题、b-roll 版面、语义音效与 BGM。

## 总流程（严格按序）

1. **建项目骨架**：在 `videos/<project>/` 下按 `references/pipeline.md` §1 建目录，把 `scripts/engine/*.js` 复制到项目根，`assets/sfx/`→`public/sfx/`、`assets/vendor/`→`public/vendor/`、`assets/fonts-master/`→`assets-src/fonts/`。
2. **源素材审计**：ffprobe 分辨率/帧率/时长；抽帧看构图；测语句间隙电平判断原片是否自带 BGM（pipeline §2）。
3. **字幕层**：跑 `build-subtitles.js`（SRT → subtitles.timeline.json），断句与三层规则见 `references/design-system.md` §1。
4. **写 plan.js**：以 `scripts/engine/plan.template.js` 为底，按本片 transcript 填 SECTIONS / COMBO_PLAN / BROLL_PLAN / SFX_CONTENT_ACCENTS——这是每部片的核心创作步骤，形态与出场轮换规则见 design-system §3。
5. **构建**：`build-composition.js` → `subset-fonts.js` → `build-design-preview.js`（命令与环境变量见 pipeline §5）。
6. **门禁**：`hyperframes lint` + `check --at-transitions`，error 必须为 0；设计使然的 warn 白名单见 pipeline §5。
7. **渲染 + 外挂混音**：render 只出画面，**音频必须** `build-audio-mix.js` 外挂混音再 mux（pipeline §6，渲染器丢多音轨是踩过的坑）。
8. **QA 交付**：从最终成片抽 12 帧接触表 + 频谱对比验证音频；同步写 FRAME.md 与工作区记忆。
9. **（最终交付·可选）转剪映可编辑草稿**：见下「剪映草稿最终交付」——画面切自「无字幕包装版」，字幕/排版组合/音效全部转成剪映原生对象（含三式排版组合的关键帧复现）。

## 关键规则（违反必返工）

- **先读 `references/design-system.md`**：字幕三层、断句阈值、俊雅体 0.75em 字宽、拉丁徽标、4 种 b-roll 形态 × 出场轮换、背景三层、音效密度与映射——全部是用户六轮返工沉淀的硬口径。
- **再读 `references/pipeline.md`**：hyperframes/ffmpeg 环境坑（坏 lame、EBUSY、check 必加 --at-transitions、剪映曲库抓 BGM 方法）。
- A-Roll 能讲清的不加图形，B-Roll 才加；不要处处加料，保留呼吸段落。
- 出场方式逐版面轮换；iris 只能用于 PIP 版面；fade 必须同步 scale×1.5；slide 用于 PIP 前必须先归位。
- 每完成一轮交付，把新踩的坑回写本 skill 的 references（保持 skill 是最新真相）。

## 资源地图

- `scripts/engine/`：theme.js（设计令牌）、build-subtitles.js、plan.template.js、build-composition.js、build-audio-mix.js、build-design-preview.js、subset-fonts.js、type-metrics.js（字体度量）、patch-dsl.js、build-sfx.sh（lavfi 重新生成全套音效）。
- `assets/sfx/`：26 个语义音效 mp3（whoosh/pop/tick/spring/keyboard/water-soft/boom/radio…）。
- `assets/fonts-master/`：7 款母版字体（俊雅体/思源粗宋/华光中长宋/思源宋/细体/特黑/研宋），供子集化。
- `assets/vendor/`：gsap.min.js。
- `references/pipeline.md`：管线操作手册（环境、命令、门禁、混音、QA、踩坑速查）。
- `references/design-system.md`：设计系统契约（用户审美硬规则）。
- `scripts/jianying/`：剪映草稿交付链——build-jianying-plan.js（分镜/切点）、cut-segments.js（切段）、dump-combo-rows.js（排版组合几何导出）、post-process-draft.py（字幕+排版组合+音效注入）、build-sfx-sheet.js（音效清单）。

## 剪映草稿最终交付（配合市场技能 `jianying-assistant`）

用户要剪映可编辑草稿时，用 `scripts/jianying/` 这套，**严格按序**：

1. **先渲一版「画面包装版·无字幕」**：`HIDE_CAPTIONS=1 node build-composition.js` 再 render —— 只去掉字幕层与排版组合层，**章节标题/斜切底板/b-roll 版面/背景全部保留**。这是唯一正确的画面来源（切自源片会丢口播画面包装；切自带字幕的成片会把字幕烙进 b-roll）。
2. `build-jianying-plan.js`：字幕行 + b-roll 窗口 → 96 镜（b-roll 窗口整段保留、其余按字幕行切），总时长严格对齐。
3. `cut-segments.js` → 4 路并行 ffmpeg 物理切段（尾垫 80ms）。
4. `dump-combo-rows.js`：把 15 组排版组合的真实几何（theme.comboRows 同源：每段 y/tx/size/scale + 触发时刻）导出为 `jianying/combo-rows.json`。
5. `jianying-assistant` 的 assemble_draft → download_draft（**下载到临时目录，别直接落剪映目录**）。
6. `post-process-draft.py --draft-dir <临时草稿> --work <项目根>`：**在打开剪映之前**重写草稿 JSON——
   - 字幕轨：79 行平铺原生富文本（重点词独立金色区间）
   - **排版组合轨：31 段分 3 条文本轨（A/B/C 按段序错开防同轨重叠），三种式样的原生关键帧复现**（见下）
   - 音效轨：70 落点 × 18 音源
7. **安装为新草稿**：复制到 `E:/JianyingPro Drafts/<中文名>`，递归重写所有 `path` 字段（正/反斜杠混写都要处理，`_fresh` 等临时路径必须清零），对齐 `draft_meta_info.json` 的 fold_path/root_path/name。
8. `build-sfx-sheet.js`：出 `音效清单.md`（含剪映音效库检索词对照）。

**排版组合 → 剪映原生关键帧映射**（`post-process-draft.py` 已实现）：
- 上下式 up_down：各段独立上滑入场（KFT PositionY：+56px→0，0.24s），落位 `y = 1152 + i*1.3*字号`。
- 前后式 front_back：后句同位置覆盖——前句段在触发点截止（下一句 start−0.06），后句 KFT PositionY（+40px→0，0.30s）+ ScaleX/Y（0.9→1.0），末句金色 + 1.2× 字号烘入 font_size。
- 左右式 left_right：前句 3 帧 KFT PositionX（0→0→−118px，触发点前保持 0）；后句 KFT PositionX（−110px→+tx）+ Scale 0.94→1。
- 关键帧 schema（对齐 pyJianYingDraft/实测）：`segment.common_keyframes[] = {id, material_id:"", property_type:"KFTypePositionX/Y"|"KFTypeScaleX/Y", keyframe_list:[{curveType:"Line", graphID:"", left_control/right_control:{x,y}, id, time_offset:<µs 相对段首>, values:[<norm>]}]}`；文本段**只支持位置/缩放**关键帧（alpha 不支持，入场用位移+缩放表达）。

**剪映草稿关键真值（实测，1080×1920）**：
- `font_size 12 ↔ text_size 72`（= 我们的 72px 标准）；小字档 11；排版组合按 px/6 直接换算（可带小数）。
- 位置 `clip.transform.y = -0.2` 正好是画面 **0.600**（1.0 单位 = 画布高，y 正=向上）；归一换算 `y = -0.2 + (1152−px)/1920`、`x = px/1080`。
- 字体用**本机真实存在的**（`C:/Windows/Fonts/msyhl.ttc` + `Microsoft YaHei Light`；排版组合用 `msyhbd.ttc` 粗体近似思源粗宋）；写 `font_path:"D:"` 或机器上没有的字体资源会渲染成空白 → 用户会看到「字幕是空的」。
- 重点词强调用 `content.styles` 的多个 `range` 区间（各自 fill 颜色 + size），这是原生可编辑的逐词改色。
- 音频段 `volume` 直接用我们的 sfx 分档值（0.12–0.21）。
- `jianying-assistant v1.0.0` 有浮点微秒 bug：`assemble_draft.py` 的 `current_time * US_PER_SEC` 会产生浮点微秒，服务端静默拒收（报「缺少 video_infos 参数」）→ 3 处（视频/图片/字幕轨）改 `int(round(...))`；本机已修并标 userModified，被更新覆盖需重打。
- 用户打开过草稿后 `draft_content.json` 会被加密（不可再改）→ 要改必须重新组装**新草稿**（新文件夹名 + 路径全量重写），旧的挪出草稿目录归档。
- 素材路径在 draft_content/draft_info 里至少有三种写法（绝对反斜杠 / 相对正斜杠 / 混合），安装时必须按 JSON 对象递归遍历替换，字符串级 sed 会漏。
