// build-design-preview.js — 设计门禁页
// 直连 theme.js / plan.js，保证「预览上看到的 = 成片渲染的」。样张取自成片渲染截帧。
const fs = require('fs');
const path = require('path');
const T = require('./theme.js');
const P = require('./plan.js');
const PLAN = require('./caption-plan.json');

const { C, F, CAPTION, EMPHASIS, TITLE, COMBO, PX, MOTION, PUSH, SFX_ROLE, SFX } = T;
const OUT = path.join(__dirname, 'design-preview', 'index.html');

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const mmss = (t) => `${Math.floor(t / 60)}:${(t % 60).toFixed(1).padStart(4, '0')}`;

const cues = PLAN.timeline;
const combos = P.assignComboTypes(P.COMBO_PLAN).filter((c) => !P.COMBO_DOWNGRADE.includes(c.group));
const typeLabel = { left_right: '左右式', up_down: '上下式', front_back: '先后式' };
const typeCount = combos.reduce((m, c) => ((m[c.type] = (m[c.type] || 0) + 1), m), {});

// ------------------------------------------------------------------ 样张
const STILLS = [
  ['frame-00-at-2.6s.png', '开场两段式主旨 g001', `上下式：前句在基础字幕位，后句用位置关键帧落在前句下方，两句同屏不影响空间感`],
  ['frame-01-at-14.6s.png', '章节标题（1.）', `斜切底板 868×297 · 实拍校准 156/134/102/47px`],
  ['frame-02-at-17.6s.png', '上下式组合 g003', `「让它逐句分析 / 哪些地方需要b-roll」两段同尺同色不强调，行距 1.30em`],
  ['frame-03-at-42.4s.png', 'b-roll 圆形 PIP 版面 b1', `人物收进右侧圆孔（R=230，头高占 67%），光圈两段式进出场`],
  ['frame-04-at-48.6s.png', 'b-roll 整屏拼贴 b2', `画面够满时人物不出现，声音当旁白`],
  ['frame-05-at-35s.png', '前后式组合 g004', `后句覆盖在前句上、放大 1.20× 并转金；前句补透明度关键帧压到 0.18`],
  ['frame-06-at-70.2s.png', 'b-roll 圆形 PIP 版面 b4', `底部拼贴卡 + 圆孔透出原视频`],
  ['frame-07-at-76s.png', '章节标题（!.）', `顶边 y=138，下移 13px 避开平台顶部裁切`],
  ['frame-08-at-97.6s.png', '整屏版面 b6 · 下载路径', `D:\\素材\\b-roll\\ 路径与磁盘示意`],
  ['frame-09-at-130.6s.png', '左右式组合 g013', `同样是上下结构：后句向右展开时前句向左位移，关键帧点位同步；全在安全区内`],
];

const stillsHTML = STILLS.map(([f, t, d]) => `
  <div class="still">
    <img src="stills/${f}" alt="${esc(t)}" />
    <div class="cap"><b>${esc(t)}</b><span>${esc(d)}</span></div>
  </div>`).join('');

// ------------------------------------------------------------------ 色板
const SW = [
  ['金 gold', C.gold, '重点词 / 大编号'],
  ['红 red', C.red, '强调线'],
  ['红斜杠 redSlash', C.redSlash, '标题斜杠（提亮 4% 过 AA）'],
  ['奶油 cream', C.cream, '副说明小字'],
  ['白 white', C.white, '主标题 / 基础字幕'],
  ['墨 ink', C.ink, 'vox b-roll 深底'],
  ['纸 paper', C.paper, 'vox 拼贴纸面'],
  ['马克笔 mark', C.mark, '高亮条'],
];
const swHTML = SW.map(([n, v, d]) => `
  <div class="sw"><div class="box" style="background:${v}"></div>
  <div class="lbl">${esc(n)}<br><code>${esc(v)}</code><br><span>${esc(d)}</span></div></div>`).join('');

// ------------------------------------------------------------------ 字体角色表
const FONTS = [
  ['基础字幕', F.base, '造字工房俊雅体', '用户指定「基础字幕…改成俊雅体」'],
  ['标题主字 / 重点花字', F.heavy, '思源粗宋', '用户指定「标题设计可以是思源粗宋」'],
  ['细体装饰 / 红斜杠', F.thin, '青鸟华光中长宋', '用户指定「青鸟华光中长宋」'],
  ['正文 / 副说明', F.body, '思源宋体 Regular', '—'],
  ['专业科普细体', F.tech, '思源黑体 7 号', '用户指定「标准的细体」'],
  ['专业科普粗体', F.techH, '思源黑体 1 号', '用户指定「特黑体」'],
  ['备用宋', F.yan, 'Aa 研宋', '预留女生调色板'],
  ['数字 / 拉丁', F.num, 'Inter', '—'],
];

// ------------------------------------------------------------------ 组合表
const comboHTML = combos.map((c) => {
  const parts = cues.filter((x) => x.groupId === c.group);
  const rows = T.comboRows(c.type, parts.map((p) => ({ text: p.text })));
  const pos = rows.map((r, i) => `<span class="pill">段${i + 1} · y ${Math.round(r.y)} · ${r.size}px${r.tx ? ` · x ${r.tx > 0 ? '+' : ''}${Math.round(r.tx)}` : ' · x 居中'}</span>`).join('');
  return `<tr>
    <td><b>${c.group}</b><br><span class="dim">${mmss(c.t0)}</span></td>
    <td><span class="ty ty-${c.type}">${typeLabel[c.type]}</span></td>
    <td>${parts.map((p) => esc(p.text)).join(' <span class="dim">／</span> ')}</td>
    <td>${pos}</td>
    <td class="dim">${esc(c.note)}</td>
  </tr>`;
}).join('');

// ------------------------------------------------------------------ 章节标题表
const secHTML = P.SECTIONS.map((s) => `<tr>
  <td><b>${esc(s.num || '（开场）')}</b></td>
  <td>${esc(s.main || '如何从 0–1 手搓一个自动找 B-roll 的 Skill')}</td>
  <td class="dim">${esc(s.sub || '两段式主旨')}</td>
  <td class="dim">${s.t0.toFixed(1)}–${(s.t1 != null ? s.t1 : 0).toFixed(1)}s</td>
</tr>`).join('');

// ------------------------------------------------------------------ b-roll 表
const brollHTML = P.BROLL_PLAN.map((b) => {
  const top = b.pip ? 660 : b.title ? 292 : 200;
  return `<tr>
    <td><b>${b.id}</b><br><span class="dim">${mmss(b.t0)}</span></td>
    <td><span class="ty ${b.pip ? 'ty-front_back' : 'ty-up_down'}">${b.pip ? '圆形 PIP' : '整屏拼贴'}</span></td>
    <td class="dim">${b.pip ? '人物收进右侧圆孔' : '人物不出现，声音当旁白'}</td>
    <td>${esc(b.title || '（无标题条）')}</td>
    <td class="dim">y ${top} – 1080</td>
  </tr>`;
}).join('');

// 形态矩阵：每个版面选了什么形态、为什么（用户要求「根据画面匹配度和文字内核去分析适合哪一种」）
const CONTENT_BOT = 1104;
const SHAPE_REASON = {
  b1: ['手机样机 + 右上圆窗', '讲「把素材网站告诉 AI」→ 网站装进手机框最贴语义', '外出圆窗（手机内并列）'],
  b2: ['取景框 + ● REC 角标', '讲「逐条核对镜头 / 这个素材对应哪句文案」→ 拍摄审片语义', '不出镜（声音当旁白）'],
  b3: ['圆窗 + 三档卡', '您已认可的式样，保持不动', '右上圆窗'],
  b4: ['整屏两栏卡（无框）', '「剪辑逻辑 / 审美标准」两栏本身就是主体，再叠圆窗是冗余', '不出镜'],
  b5: ['整屏三行规则', '三条并列规则，信息密度高，不需要人物分心', '不出镜'],
  b6: ['整屏路径 + 磁盘条', '横向进度条需要整屏宽度', '不出镜'],
  b7: ['整屏目录树', '缩进层级需要整屏宽度', '不出镜'],
  b8: ['圆窗 + 三段管道', '收尾呼应开场，人物在画面里结束', '右上圆窗'],
};
const EXIT_LABEL = { iris: 'iris 光圈胀满', fade: 'fade 交叉溶解', 'slide-up': 'slide-up 上擦', 'slide-down': 'slide-down 下擦', 'slide-left': 'slide-left 左擦', 'slide-right': 'slide-right 右擦' };
const shapeHTML = P.BROLL_PLAN.map((b) => {
  const [shape, reason, face] = SHAPE_REASON[b.id] || ['—', '—', '—'];
  return `<tr>
    <td><b>${b.id}</b><br><span class="dim">${mmss(b.t0)}</span></td>
    <td class="dim">${esc(b.title || b.kind)}</td>
    <td><b>${esc(shape)}</b></td>
    <td class="dim">${esc(face)}</td>
    <td><code>${esc(EXIT_LABEL[b.exit] || b.exit)}</code></td>
    <td class="dim">${esc(reason)}</td>
  </tr>`;
}).join('');

// ------------------------------------------------------------------ 音效表
// 依据用户《动画音效搭配逻辑》脑图：动效类别 → 音效词。只列本片真正用到的。
const SFX_USE = {
  move: ['位移', '呼', '开场整层推入 / 暗层横向擦出退场'],
  'move-fast': ['位移', '唰', '章节标题条上滑 / 左右式同步位移 / 暗层纵向擦出退场'],
  'move-deep': ['位移', '嗖', '开场主旨铺开'],
  land: ['位移', '落地', '上下式后半句落定'],
  'zoom-in': ['缩放', '嘭', '前后式后半句放大覆盖 / 光圈胀满退场'],
  'zoom-out': ['缩放', '咚', '圆形 PIP 圆窗收拢'],
  flash: ['缩放', '闪光', '重点词重音落点'],
  ripple: ['波纹（晕开、吸入）', '水滴相关', '圆形 PIP 圆环晕开落定'],
  'jump-in': ['跃入', '综艺开始系统提示音', '整屏拼贴跃入'],
  gear: ['滚动类', '齿轮', '搜索格 / 对应表 / 文件夹树逐行滚出'],
  grow: ['生长', '木质铃铛响一下', '磁盘占用条横向生长'],
  fan: ['折叠、开屏、收拢', '折扇展开', '三档卡片展开'],
  paper: ['折叠、开屏、收拢', '纸张', '左右两栏铺纸'],
  'paper-shake': ['折叠、开屏、收拢', '纸张抖动', '三段管道连续抖出'],
  'snap-upright': ['字幕歪到正', '收音机声', 'b2 取景框对上内容（● REC 落定）'],
  fade: ['渐隐', '水滴', 'b3 圆形版蒙版交叉溶解退场'],
};
const sfxUseCount = P.buildSfxPlan(cues).reduce((a, e) => { a[e.key] = (a[e.key] || 0) + 1; return a; }, {});
const sfxHTML = Object.entries(SFX_USE).map(([role, [cat, word, where]]) => {
  const name = SFX_ROLE[role];
  return `<tr><td class="dim">${esc(cat)}</td><td><b>${esc(word)}</b></td><td><code>${esc(name)}</code></td><td class="dim">${esc(where)}</td><td class="dim">${SFX[name]}s</td><td class="dim">×${sfxUseCount[role] || 0}</td></tr>`;
}).join('');
const sfxUnused = ['magic', 'tap-soft', 'coin', 'wobble', 'bo', 'spring', 'radio', 'ding', 'pop', 'tick', 'keyboard', 'whoosh-deep'];
const SFX_TOTAL = P.buildSfxPlan(cues).length;

const counts = PLAN.counts;

const html = `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<title>设计门禁 · 陆总口播《手搓自动找 B-roll 的 skill》轻奢包装</title>
<style>
  :root{
    --bg:#F7F3EC; --card:#FFFFFF; --ink:#1A1512; --dim:#6E6459;
    --line:rgba(26,21,18,.22); --gold:${C.gold}; --red:${C.redSlash}; --paper2:#EFE7D9;
  }
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--ink);
    font-family:"Microsoft YaHei","PingFang SC","Heiti SC",sans-serif;-webkit-font-smoothing:antialiased}
  .wrap{max-width:1200px;margin:0 auto;padding:56px 36px 96px}
  h1{font-size:38px;line-height:1.25;margin:0 0 10px;letter-spacing:-.01em}
  .lead{color:var(--dim);font-size:16px;line-height:1.75;margin:0;max-width:900px}
  h2{font-size:22px;margin:64px 0 8px;padding-bottom:12px;border-bottom:3px solid var(--ink)}
  h2 .n{color:var(--red);font-weight:900;margin-right:10px}
  h3{font-size:17px;margin:30px 0 10px}
  .hint{color:var(--dim);font-size:14px;line-height:1.7;margin:6px 0 16px}
  .meta{display:flex;gap:10px;flex-wrap:wrap;margin:22px 0 0}
  .tag{background:var(--card);border:2px solid var(--ink);box-shadow:4px 4px 0 rgba(26,21,18,.14);
    padding:7px 14px;font-size:13.5px;font-weight:700}
  .tag.ok{background:#E7F3E9;border-color:#2F6B3F;color:#20522C}
  .tag.warn{background:#FCF0E0;border-color:#9A6416;color:#7A4E10}
  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(268px,1fr));gap:22px;margin-top:20px}
  .still{background:var(--card);border:2.5px solid var(--ink);box-shadow:7px 7px 0 rgba(26,21,18,.16);overflow:hidden}
  .still img{display:block;width:100%;height:auto;background:#111}
  .still .cap{padding:12px 14px;border-top:2.5px solid var(--ink);background:var(--paper2)}
  .still .cap b{display:block;font-size:15px;margin-bottom:5px}
  .still .cap span{display:block;font-size:13px;color:var(--dim);line-height:1.6}
  .swatches{display:flex;gap:16px;flex-wrap:wrap;margin-top:18px}
  .sw{width:168px;background:var(--card);border:2.5px solid var(--ink);box-shadow:5px 5px 0 rgba(26,21,18,.14)}
  .sw .box{height:84px;border-bottom:2.5px solid var(--ink)}
  .sw .lbl{padding:10px 12px;font-size:13px;font-weight:700;line-height:1.65}
  .sw .lbl code{font-size:11.5px;font-weight:600;color:var(--dim)}
  .sw .lbl span{display:block;font-weight:400;color:var(--dim);font-size:12px;margin-top:3px}
  table{width:100%;border-collapse:collapse;margin-top:18px;background:var(--card);
    border:2.5px solid var(--ink);box-shadow:6px 6px 0 rgba(26,21,18,.14);font-size:14.5px}
  th,td{border-bottom:1.5px solid var(--line);padding:12px 14px;text-align:left;vertical-align:top;line-height:1.65}
  th{background:var(--paper2);font-weight:800;font-size:13.5px;letter-spacing:.02em}
  tr:last-child td{border-bottom:0}
  .dim{color:var(--dim);font-size:13px}
  code{background:rgba(26,21,18,.06);padding:1px 6px;border-radius:4px;font-size:12.5px}
  .ty{display:inline-block;padding:3px 10px;border-radius:999px;font-size:12.5px;font-weight:800;
    border:1.5px solid var(--ink);white-space:nowrap}
  .ty-left_right{background:#FBE7D2}
  .ty-up_down{background:#DDEAF2}
  .ty-front_back{background:#E6E2F5}
  .pill{display:inline-block;background:rgba(26,21,18,.06);border:1px solid var(--line);
    border-radius:6px;padding:2px 8px;font-size:12px;margin:2px 4px 2px 0;white-space:nowrap}
  .note{background:var(--card);border:2.5px solid var(--ink);box-shadow:7px 7px 0 rgba(26,21,18,.16);
    padding:20px 24px;margin-top:20px;line-height:1.8;font-size:15px}
  .note b{color:var(--red)}
  .two{display:grid;grid-template-columns:1fr 1fr;gap:22px;margin-top:18px}
  .zone{position:relative;background:#141110;border:2.5px solid var(--ink);border-radius:8px;
    box-shadow:7px 7px 0 rgba(26,21,18,.16);overflow:hidden;aspect-ratio:9/16;max-width:330px;margin-top:18px}
  .zone .band{position:absolute;left:0;right:0;font-size:12px;font-weight:700;display:flex;
    align-items:center;justify-content:space-between;padding:0 12px}
  .zone .b-mouth{background:rgba(209,92,71,.34);border-top:1.5px dashed rgba(255,255,255,.55);
    border-bottom:1.5px dashed rgba(255,255,255,.55);color:#FFD9CF}
  .zone .b-cap{background:rgba(255,204,130,.30);border-top:2px solid var(--gold);border-bottom:2px solid var(--gold);color:#FFE7BE}
  .zone .b-plat{background:rgba(255,255,255,.13);border-top:1.5px dashed rgba(255,255,255,.55);color:#DCD6CC}
  .zone .capdemo{position:absolute;left:0;right:0;text-align:center;color:#fff;
    font-family:"Microsoft YaHei",sans-serif;font-weight:800;font-size:20px;
    text-shadow:0 3px 6px rgba(0,0,0,.6)}
  .zone .capdemo em{font-style:normal;color:var(--gold);font-size:22.4px}
  .demo{background:#141110;border:2.5px solid var(--ink);border-radius:8px;padding:28px 24px;
    box-shadow:7px 7px 0 rgba(26,21,18,.16);margin-top:18px}
  .demo .l{color:#fff;font-family:"Microsoft YaHei",sans-serif;font-weight:800;font-size:30px;
    text-shadow:0 3px 6px rgba(0,0,0,.6);text-align:center;line-height:1.5}
  .demo .l em{font-style:normal;color:var(--gold);font-size:33.6px}
  .demo .cap2{text-align:center;color:#9C9488;font-size:13px;margin-top:12px}
  .rolegrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px;margin-top:18px}
  .rolecard{background:var(--card);border:2.5px solid var(--ink);box-shadow:5px 5px 0 rgba(26,21,18,.14);padding:14px 16px}
  .rolecard b{display:block;font-size:14.5px;margin-bottom:6px}
  .rolecard code{display:block;font-size:11.5px;word-break:break-all;margin-bottom:6px}
  .rolecard span{font-size:12.5px;color:var(--dim);line-height:1.6}
  footer{margin-top:70px;padding-top:22px;border-top:2.5px solid var(--ink);color:var(--dim);font-size:13.5px;line-height:1.8}
</style>
</head>
<body>
<div class="wrap">

<h1>设计门禁 · 陆总口播《手搓自动找 B-roll 的 skill》轻奢包装</h1>
<p class="lead">
  本页所有数值都从 <code>theme.js</code> / <code>plan.js</code> 直接读出，样张取自<strong>成片渲染截帧</strong>——
  所以「你在这里看到的 = 成片里渲染出来的」。字幕系统的基准是您提供的参考片
  <code>字幕效果预览_非剪映导出.mp4</code>；由于它与本片是<strong>同一条源素材</strong>（SRT sha256 一致），
  参考片的章节落点、排版组合落点、字号与底板几何都是可直接沿用的<strong>实测值</strong>。
</p>
<div class="meta">
  <span class="tag">1080×1920 · 50fps</span>
  <span class="tag">160.28s · H.264 ≈9855kbps</span>
  <span class="tag">字幕 ${counts.total} 条 · 平均 8.8 字</span>
  <span class="tag">排版组合 ${combos.length} 组 / ${counts.layout} 段</span>
  <span class="tag">b-roll ${P.BROLL_PLAN.length} 版面</span>
  <span class="tag">音效 ${SFX_TOTAL} 处</span>
  <span class="tag ok">hyperframes check → ok: true · errors 0</span>
  <span class="tag warn">vidmuse CLI 未安装 → Serve 实时预览未执行</span>
</div>

<h2><span class="n">01</span>关键版面样张</h2>
<p class="hint">成片渲染截帧。可对照核对：字幕轴心位置、标题底板、组合落位、b-roll 人物处理。</p>
<div class="grid">${stillsHTML}</div>

<h2><span class="n">02</span>基础字幕与安全区</h2>
<p class="hint">
  夹击条件下的可行带：不得遮嘴（上界 y 0.470），不得落入平台标题区（下界 y 0.860）。
  参考片实测轴心 <strong>y = 0.600（1152px）</strong>同时满足两者——上距嘴 206px、下距平台区 455px。
</p>
<div class="two">
  <div>
    <div class="zone">
      <div class="band b-mouth" style="top:46.2%;height:4%"><span>嘴 · y 0.470</span><span>不得越过</span></div>
      <div class="band b-cap" style="top:55.4%;height:9%"><span>字幕轴心 · y 0.600（1152px）</span><span>${CAPTION.sizeNormal}px + ${CAPTION.letterSpacing}em 字距 / 行高 ${CAPTION.lineHeight}</span></div>
      <div class="band b-plat" style="top:85.4%;height:6%"><span>平台标题 / 点赞区 · y 0.860</span><span>不得落入</span></div>
      <div class="capdemo" style="top:51.5%">是不是经常不知道<br>哪里该加<em>B-roll</em></div>
    </div>
  </div>
  <div>
    <table>
      <tr><th>项</th><th>取值</th><th>来源</th></tr>
      <tr><td>位置</td><td>居中 x 0.500 / <b>y 0.600</b>（1152px）</td><td class="dim">参考片 ASS <code>\\pos</code>，Alignment=5</td></tr>
      <tr><td>字号</td><td><b>${CAPTION.sizeNormal}px</b>（缩排 ${CAPTION.sizeSmall}px）</td><td class="dim">见下方「0.75em 补偿」</td></tr>
      <tr><td><b>字间距</b></td><td><b>${CAPTION.letterSpacing}em</b>；中西文边界另加，拉丁内部不加</td><td class="dim">补偿俊雅体 0.75em 窄推进</td></tr>
      <tr><td>颜色</td><td>#FFFFFF，无描边</td><td class="dim">参考片实测</td></tr>
      <tr><td>阴影</td><td>0 3px 6px rgba(0,0,0,.60)<br>0 2px 14px rgba(0,0,0,.42)</td><td class="dim">参考片 60% / 模糊 10</td></tr>
      <tr><td>字体</td><td>俊雅体（CJK 推进仅 0.750em）</td><td class="dim">用户指定</td></tr>
      <tr><td>安全内边距</td><td>左右各 ${CAPTION.safeInset}px → 可用宽 ${1080 - CAPTION.safeInset * 2}px</td><td class="dim">最宽一条 906px · <b>越界 0 条</b></td></tr>
      <tr><td>缩排条数</td><td>${cues.filter((c) => c.size === 'small').length} 条</td><td class="dim">11–12 视觉字且句意完整</td></tr>
    </table>
    <div class="note">
      <b>⚠ 关键判定 1 · 俊雅体是 75% 压缩中文字体</b>（<code>tools/fontmetrics.js</code> 直读 <code>hmtx</code> 实测）：
      造字工房俊雅体 CJK 推进 <b>0.750 em</b>，思源粗宋 / 青鸟华光中长宋均为 <b>1.000 em</b>。
      同样是「字号 12」，俊雅体渲染出来只有常规中文字体的 75% 宽、字与字天然贴合——
      这正是「字间距过于紧凑、不够舒展」的<strong>字体层面的内因</strong>。<br>
      <b>补偿推导（真实字宽反解，非拍脑袋）</b>：参考片 10 字实测 ink 宽 769px / ink 高 67px / advance÷ink高 ≈ 1.16。
      对俊雅体解 <code>(6.75 + 9L)·F = 756</code> 与 <code>advance÷ink高 ≈ 1.1</code> →
      <b>F = ${CAPTION.sizeNormal}px、L = ${CAPTION.letterSpacing}em</b>（10 字行 752px = 画布 69.6%，ink 高 72.5px）。
      <code>letter-spacing</code> 会在末字后多留一格使整行视觉左偏 L/2，用 <code>margin-left</code> 抵消。<br>
      <b>⚠ 关键判定 2 · 基础字幕不缩放</b>：ASS <code>\\fs</code> 对<strong>标题 / 花字层</strong>是设计规格，参考片实拍比规格<strong>小一档</strong>；
      但对基础字幕层实拍与规格完全一致（参考片「做IP口播剪辑的」<code>\\fs72</code> 实测 ink 宽 382px，本工程同字号渲染 389px，比值 0.98）。
    </div>
  </div>
</div>

<h2><span class="n">03</span>断句标准（逐条落地）</h2>
<table>
  <tr><th style="width:44%">您的规则</th><th style="width:28%">落地阈值</th><th>结果</th></tr>
  <tr><td>一行字幕超出 10 个字就断句</td><td><code>MAX_VISUAL = 10</code>（视觉宽度，拉丁按 0.5 计）</td><td>越限 <b>0 条</b></td></tr>
  <tr><td>先调整基础字幕的位置大小在合适的位置</td><td>先定 y 0.600 / ${CAPTION.sizeNormal}px + ${CAPTION.letterSpacing}em</td><td>见第 02 节</td></tr>
  <tr><td>前后句意密不可分 → 做字幕排版设计</td><td>语意编组 → ${PLAN.counts.layoutGroups} 组</td><td>见第 05 节</td></tr>
  <tr><td>≤12 字能讲完一段 → 缩小字号</td><td><code>SOFT_VISUAL = 12</code> + ${CAPTION.sizeSmall}px</td><td>${cues.filter((c) => c.size === 'small').length} 条缩排</td></tr>
  <tr><td>拉丁词不拆（B-roll 等）</td><td>词边界断句</td><td>合规</td></tr>
  <tr><td>单条最短时长</td><td><code>MIN_CUE_DUR = 0.62s</code></td><td>${counts.tooShort} 条偏短（口语极短句，已复核）</td></tr>
</table>
<p class="hint">
  字幕总量 <strong>${counts.total}</strong> 条 = 基础层 <strong>${counts.base}</strong> + 重点强调 <strong>${counts.emphasis}</strong> + 排版组合 <strong>${counts.layout}</strong> 段；
  覆盖 ${cues[0].startTime.toFixed(2)}–${cues[cues.length - 1].endTime.toFixed(2)}s，<strong>时间轴 0 重叠</strong>。
  您提到的「第一步还没说怎么提前出现了」→ 根因是断句时下一句的起止时间侵入了上一句；本版对每条 cue 做边界互斥（<code>end_i ≤ start_{i+1}</code>）。
</p>

<h2><span class="n">04</span>三类区分：强调 vs 排版设计</h2>
<p class="hint">您明确要求先区分这两件事。它们层级不同、手段不同、时序规则也不同。</p>
<table>
  <tr><th style="width:16%"></th><th>重点词强调</th><th>排版设计组合</th></tr>
  <tr><td><b>载体</b></td><td>单条字幕内的<strong>若干字</strong></td><td><strong>2–3 句</strong>独立成段</td></tr>
  <tr><td><b>手段</b></td><td>内联改色 + 放大 ${EMPHASIS.scale}×</td><td>段与段的空间关系 + 分时入场</td></tr>
  <tr><td><b>参照</b></td><td>参考片内联写法 <code>{\\c&H82CCFF&\\fs80.64}</code></td><td><b>您口述的三种式样</b>（上下式 / 前后式 / 左右式）</td></tr>
  <tr><td><b>令牌</b></td><td><code>color ${EMPHASIS.color} · scale ${EMPHASIS.scale}</code></td><td>三种式样，见第 05 节</td></tr>
  <tr><td><b>数量</b></td><td>${cues.filter((c) => (c.emphasis || []).length).length} 条含重点词</td><td>${combos.length} 组 / ${counts.layout} 段</td></tr>
  <tr><td><b>时序</b></td><td>提前量 ≤ <code>${MOTION.lead}s</code>，<strong>出点正落在重音上</strong></td><td>段落随口播说到才出现</td></tr>
</table>
<div class="demo">
  <div class="l">还有 <em>AI</em> 会帮你把素材<em>自动</em>下载</div>
  <div class="cap2">重点词强调：白字中改色 + 1.12× 放大，不改变字幕整体位置</div>
</div>
<h3>时序铁律</h3>
<div class="rolegrid">
  <div class="rolecard"><b>1 · 全部加缓动</b><span>Bezier <code>0.42, 0, 0.58, 1</code>，复刻参考工程 <code>curveType=Bezier</code> 控制点，非近似</span></div>
  <div class="rolecard"><b>2 · 两点之间留空间</b><span><code>spaceRatio ${MOTION.spaceRatio}</code>：入场 0.18s，则出点距入点至少 0.18s，不仓促也不拖沓</span></div>
  <div class="rolecard"><b>3 · 卡在重音上</b><span>重音时间取自 <code>transcript.json</code> 的字级时间戳</span></div>
  <div class="rolecard"><b>4 · 提前量 ≤ ${MOTION.lead}s</b><span>话未到字幕先动，但<strong>动画完成的那一刻</strong>正好落在重音</span></div>
</div>

<h2><span class="n">05</span>排版组合：${combos.length} 组</h2>
<p class="hint">
  密度约束：任意连续 60 秒内，同一种式样不超过 2 组；组合之间保留普通字幕段落（回溯求解，不是手工排）。
  实际分配 → ${Object.entries(typeCount).map(([k, v]) => `${typeLabel[k]} ${v}`).join(' / ')}。
</p>
<h3>三种式样 —— 以您的口述定义为唯一准绳</h3>
<p class="hint">
  旧版我按参考片 ASS 反解出的「左右式＝对角舒展」是<strong>错的</strong>（您已纠正），已废弃。
  现在三种式样的落位与位移全部按您给的文字定义实现，并受两条硬约束夹逼。
</p>
<table>
  <tr><th style="width:14%">式样</th><th style="width:34%">您的定义</th><th>落地实现</th><th style="width:8%">段字号</th><th style="width:9%">音效</th></tr>
  <tr><td><b>上下式</b><br><span class="dim">up_down</span></td>
      <td>前句先出现在<strong>基础字幕位置</strong>，后句再利用字幕位置关键帧出现在<strong>前句的下方</strong>，两句话同屏、不影响空间感</td>
      <td>前句锚在 y ${Math.round(COMBO.baseY * 1920)}（基础字幕位置），后句落在 y + ${COMBO.lineGapEm}×F；两段同尺同色、共存<strong>不强调</strong></td>
      <td>${COMBO.size.up_down}px</td><td><code>land</code></td></tr>
  <tr><td><b>前后式</b><br><span class="dim">front_back</span></td>
      <td>后半句<strong>覆盖</strong>在前句的字幕上，再给前句打上<strong>字幕透明度关键帧</strong>；既保留前句完整信息又突出后句重点</td>
      <td>两段同 y；后段 <code>opacity 0→1</code> + <code>scale ${COMBO.emphasisScale}</code> + 金色，同一时刻前段 <code>opacity→0.18, scale→0.86</code>；显式声明 <code>data-layout-allow-overlap</code></td>
      <td>${COMBO.size.front_back}px</td><td><code>zoom-in</code></td></tr>
  <tr><td><b>左右式</b><br><span class="dim">left_right</span></td>
      <td>同样是<strong>上下的结构</strong>，用位置关键帧做左右位移：后半句<strong>向右展开</strong>出现时，前半句<strong>向左位移</strong>，<strong>关键帧点位要同步</strong></td>
      <td>后段向右 <code>+shiftR</code>、前段同时向左 <code>−shiftL</code>，两者挂在<strong>同一个 trig 时刻</strong>；幅度各自取「不越界的最大值」，上限 ${COMBO.xShiftMax}px</td>
      <td>${COMBO.size.left_right}px</td><td><code>move-fast</code></td></tr>
</table>
<h3>两条硬约束</h3>
<div class="rolegrid">
  <div class="rolecard"><b>1 · 位移由后半句的重点词触发</b><span>您原话：「是因为后半句的<strong>重点词</strong>才导致前句话让位发生位移」。落地：所有「让位 / 展开」tween 的起点 = <code>后段.startTime − ${COMBO.triggerLead}s</code>，<strong>不是</strong>组合开头。</span></div>
  <div class="rolecard"><b>2 · 绝不出画</b><span>您原话：「一定要在安全区的范围内」。落地：<code>comboRows(type, parts)</code> 收<strong>段落文本</strong>，用 <code>type-metrics.js</code> 算真实宽度 → 逐段自适应字号（下限 48px）→ 位移量按剩余空间反推，ink 夹在 <code>safeInset ${COMBO.safeInset}px</code> 内。</span></div>
  <div class="rolecard"><b>行距收紧到 ${COMBO.lineGapEm}em</b><span>您原话：「要稍微紧凑一些，不要过于分离，要有整体性，当然也不能过于紧凑」。${COMBO.lineGapEm}em × 段字号。</span></div>
</div>
<table>
  <tr><th>编组</th><th>式样</th><th>字幕段</th><th>落位与字号（页面 px）</th><th>语意</th></tr>
  ${comboHTML}
</table>
<div class="note">
  <b>标题字号要按实拍降一档</b>：大编号规格 <code>\\fs216</code> → 实拍 ink 122×116 → 本片 ${PX.num}px；
  主标题规格 <code>\\fs150</code> → 实拍 408×96 → 本片 ${PX.main}px。
  校准后同尺度对比 <code>qa/cmp-title3.png</code> / <code>qa/cmp-open.png</code> 与参考片基本重合。<br>
  <b>开场主旨三段必须基线对齐</b>：三段的字号不同（${PX.openBase} / ${PX.openHeavy} / ${PX.openBase}px），
  用 <code>align-items:center</code> 会让金字底边低 15px、看起来「0–1 掉下去了」——这就是您说的「不是居中水平对齐」，已改为 <code>align-items:baseline</code>。
</div>

<h2><span class="n">06</span>章节标题设计</h2>
<p class="hint">
  斜切平行四边形底板：高 ${TITLE.height}px · 宽 ${TITLE.width}px · 高度区间内左右位移 ${TITLE.skewPx}px（≈6.5°）·
  填充 <code>${C.plate}</code> + 红边 <code>${C.plateRed}</code>。
  顶边 y=${TITLE.top}（实测 125，<strong>下移 13px 避开平台顶部裁切</strong>）。
  字号按参考片实拍校准：大编号 ${PX.num} · 红斜杠 ${PX.slash} · 主标题 ${PX.main} · 副说明 ${PX.sub}。
</p>
<p class="hint">
  <strong>本轮修正</strong>：s4「＋.」与 s5「!.」原来的「序号 + 句点」写法里，<b>句点会紧贴后面的红色分隔斜杠</b>，
  看起来像「. 与 / 几乎重叠」。这两节本来也不是 1–2–3 那种序号，而是<strong>旁注型小标题</strong> ——
  改用英文标识 <code>TIPS</code> / <code>RULES</code>，以<strong>金线徽标</strong>呈现（拉丁字体 56px + 字距 + 3px 金框 + 圆角），
  并<strong>去掉分隔斜杠</strong>（英文标识与标题之间不需要「/」）。
  徽标形式同时替代了斜杠的视觉权重，版面几何不变。
</p>
<table>
  <tr><th style="width:12%">编号</th><th style="width:38%">主标题</th><th style="width:32%">副说明</th><th>时段</th></tr>
  ${secHTML}
</table>

<h2><span class="n">07</span>vox 拼贴 b-roll · ${P.BROLL_PLAN.length} 个版面</h2>
<p class="hint">
  <strong>形态按「画面匹配度 + 文字内核」逐个分配</strong>（您的返工：「不用一直都圆窗讲解的效果，有点太多了，审美疲劳，
  可以换成其他方式展示」）。参考片里的做法取其中贴合本片文案的几种，<strong>不照搬</strong>。
  落位由结构约束驱动：内容区上沿 <code>pip ? 660 : (title ? 292 : 200)</code>，下沿 ${CONTENT_BOT}（基础字幕安全带起）；
  内容在该区间内<strong>垂直居中</strong>，否则矮版面会在下方留半屏空白。
</p>
<table>
  <tr><th style="width:8%">版面</th><th style="width:13%">文字内核</th><th style="width:15%">展示形态</th><th style="width:15%">人物处理</th><th style="width:11%">出场方式</th><th>选它的理由</th></tr>
  ${shapeHTML}
</table>

<h3>出场方式轮换 —— 不再「每次都是展开放大」</h3>
<p class="hint">
  所有出场都是两段式：<strong>A 段</strong>人像窗归位 / 视频长回全画幅 / 内容淡出（这一段您已认可，保持不变），
  <strong>B 段</strong>按版面轮换三种机制。相邻版面从不同款。
</p>
<table>
  <tr><th style="width:14%">机制</th><th style="width:30%">做法</th><th style="width:14%">适用</th><th>为什么好看 / 坑在哪</th></tr>
  <tr><td><code>iris</code> 光圈胀满</td><td class="dim">孔<b>原地</b> scale <code>1.43 → 5.93</code>（盖住四角）</td><td class="dim">b1 · b8（圆形）</td>
      <td class="dim">蒙版自然不可见，<b>不需要淡出</b>，所以没有「亮圆盘残影」</td></tr>
  <tr><td><code>fade</code> 交叉溶解</td><td class="dim">蒙版 <code>opacity → 0</code> 的<b>同时</b>把孔再张开 <code>×1.5</code></td><td class="dim">b3（圆形）</td>
      <td class="dim">只做纯 opacity 会被读成「一个静止的亮圆盘在淡出」；同步外扩 ⇒ 读成「圆窗化开、人长回画面」</td></tr>
  <tr><td><code>slide-*</code> 擦除</td><td class="dim">暗层整块滑出画布（上 / 下 / 左 / 右），滑出量 3400 / 3600px</td><td class="dim">b2 b4 b5 b6 b7（整屏）</td>
      <td class="dim">A 段结束时视频已是全画幅，暗层滑走即露出人像。<b>滑出量必须足够</b>——圆形版暗层是 <code>inset:-600</code> 的 2280×3120 且 A 段后还带 <code>scale 1.43</code>，跨度达 x∈[−1492,1764]，用小位移会残留一大块黑（本轮实测踩到）</td></tr>
</table>

<h3>背景质感 —— 从「寡淡的纯黑」到三层结构</h3>
<p class="hint">
  您的原话：「背景有些寡淡，可以是黑色背景，但是可以模仿这种背景：<strong>相关对应文案的 b-roll 素材不透明度拉低</strong>，
  然后加上这种<strong>针点波纹效果</strong>的背景很有质感」。落地为三层（自下而上）：
</p>
<table>
  <tr><th style="width:16%">层</th><th style="width:30%">做法</th><th>为什么这么做</th></tr>
  <tr><td>1 纯黑底</td><td class="dim"><code>${T.BROLL.bg}</code></td><td class="dim">保持轻奢暗底基调</td></tr>
  <tr><td>2 内容底纹 <code>.br-ghost</code></td><td class="dim">把<b>该版面自己的内容盒子</b>复制一份 → 抹掉 id 与全部文字 → <code>blur ${T.BROLL.ghostBlur}px</code> + <code>opacity ${T.BROLL.ghostOpacity}</code> + <code>scale ${T.BROLL.ghostScale}</code></td>
      <td class="dim">就是「这条文案对应的素材压暗做底」。<b>抹掉文字</b>是必须的——文字会触发对比度门禁的低对比误报，而且重模糊后也读不出来；抹掉 id 是因为重复 id 会让 GSAP 选择器选错元素</td></tr>
  <tr><td>3 针点波纹 <code>.br-dots</code></td><td class="dim">静态点阵（步距 ${T.BROLL.dotPitch}px / 半径 ${T.BROLL.dotR}px / α ${T.BROLL.dotAlpha}）+ ${T.BROLL.rippleMax} 圈 <b>点环</b>错峰胀开（<code>border: 5px dotted</code> 天然成点环），<code>scale ${T.BROLL.rippleFrom}→${T.BROLL.rippleTo}</code> + <code>opacity 0→${T.BROLL.rippleAlpha}→0</code>，每圈 ${T.BROLL.rippleSpan}s / 错峰 ${T.BROLL.rippleGap}s</td>
      <td class="dim">用 <code>dotted</code> 圆边框当点环比 SVG 点阵省事得多，而且<b>只动 scale / opacity</b> —— 这才是 hyperframes 允许动画的属性集，也保证逐帧 seek 安全。<b>不能用 GSAP repeat</b>，那会破坏「时间轴 = 绝对时间」的前提</td></tr>
</table>
<p class="hint">
  实现细节：圆形版面的暗层从 <code>background: radial-gradient(…)</code> 改为 <code>mask-image</code> ——
  因为底纹与点阵要做成暗层的<b>子元素</b>（否则得为它们各建一套 x/y/scale 关键帧），而 background 渐变<b>不裁剪子元素</b>，mask 会。
  一处蒙版同时管住暗色、底纹、点阵三层。
</p>

<table>
  <tr><th>版面</th><th>类型</th><th>人物处理</th><th>标题条</th><th>落位</th></tr>
  ${brollHTML}
</table>

<h3>圆形 PIP 取景 —— 逐像素实测（<code>tools/inkbox.js</code> 在源画面上量头部边界）</h3>
<table>
  <tr><th style="width:26%">量</th><th style="width:26%">实测</th><th>说明</th></tr>
  <tr><td>头顶 / 下巴</td><td>y=542 / y=980</td><td class="dim">→ 头高 <b>438px</b></td></tr>
  <tr><td>头部中心</td><td><b>(522, 761)</b></td><td class="dim">取景对准点</td></tr>
  <tr><td>发际横向</td><td>322 – 725</td><td class="dim">→ 头宽 403px</td></tr>
</table>
<table>
  <tr><th style="width:26%"></th><th style="width:30%">旧值（错）</th><th>新值</th></tr>
  <tr><td>视频缩放</td><td>1.15</td><td><b>0.70</b></td></tr>
  <tr><td>对准点</td><td>(530, 800) = <b>胸口</b></td><td><b>(522, 761) = 头部中心</b></td></tr>
  <tr><td>结果</td><td class="dim">头被放大到 504px &gt; 460px 圆孔 → 顶满圆框、脸偏<br>（您原话：「人头为什么这么大，一点也不 chill，挤满这个原框，人脸也不居中」）</td>
      <td class="dim">头高 307px = 圆孔直径的 <b>67%</b>，上下各留 76px、左右各留 89px 呼吸</td></tr>
</table>

<h3>圆形蒙版出入场 —— 两段式「光圈开合」（消除「圆圈还在、头已经回去了」）</h3>
<p class="hint">
  旧版的割裂感有<strong>三个</strong>根因，本版逐个修掉：
  ① <strong>片段渲染晚于过渡起点</strong>——旧版 <code>data-start = t0</code>，而蒙版/视频的入场 tween 从 <code>t0−0.40</code> 就跑，那 0.40s 全发生在片段被渲染之前，观众只看到 t0 处一帧跳变；
  ② <strong>容器自身在做 opacity 淡入</strong>——<code>#bN-anim</code> 的 0.3s 淡入把整块蒙版一起变半透明，过渡期是「半透明暗色叠在全画幅视频上」而不是干净的暗底开孔；
  ③ <strong>蒙版与视频不同步</strong>——视频先归位、蒙版没跟上。
  现改为：片段 <code>data-start</code> 提前到 <code>t0 − lead − 0.08</code>；PIP 片段容器恒 <code>opacity: 1</code>；蒙版与视频共用<strong>同一段 A 段</strong>（同起点 / 同时长 / 同缓动）。
</p>
<table>
  <tr><th style="width:26%">阶段</th><th style="width:40%">圆形蒙版 <code>#bN-bg</code></th><th>视频 <code>#video-wrap</code></th></tr>
  <tr><td>进场 B 段 <code>t0−0.76 → t0−0.42</code>（0.34s）</td><td>孔原地由 <code>scale 5.93</code>（<b>孔胀满画布 ⇒ 蒙版不可见</b>）收到 <code>1.4286</code></td><td class="dim">保持全画幅 → 读感「光圈从四周收拢、贴到脸上」</td></tr>
  <tr><td>进场 A 段 <code>t0−0.42 → t0−0.04</code>（0.38s）</td><td>孔心 <code>(0,0)→(−288,+381)</code>，<code>scale 1.4286 → 1</code></td><td class="dim"><b>同刻、同时长</b>推到「人脸进圆」取景</td></tr>
  <tr><td>圆环 <code>t0−0.42</code> 起（0.38s）</td><td><code>#bN-ring scale 1.30 → 1</code> 淡入</td><td class="dim">—</td></tr>
  <tr><td>退场 A 段 <code>t1−0.76 → t1−0.38</code>（0.38s）</td><td>孔心 <code>(0,0)→(−288,+381)</code>，<code>scale 1 → 1.4286</code>（<b>等比放大 ⇒ 取景比恒定</b>）</td><td class="dim"><b>同刻、同时长</b>回到全画幅 → 读感「<b>人头回到居中位置、身子出现</b>」</td></tr>
  <tr><td>退场 B 段 <code>t1−0.38 → t1−0.04</code>（0.34s）</td><td>孔<b>原地</b> <code>1.4286 → 5.93</code>（盖住四角 ⇒ 蒙版自然不可见）</td><td class="dim">保持全画幅 → 读感「光圈张开吞掉画面」，<b>无需淡出</b></td></tr>
</table>
<p class="hint">
  <strong>为什么必须两段</strong>（<code>scratch/iris-sim.js</code> 逐 <code>u</code> 采样验证）：<br>
  · <b>单段「边平移边张开」不可行</b>——孔在中段（u≈0.5）会越出视频元素边界 <b>223px</b> → 孔内露出底层黑底；<br>
  · <b>只放大不铺满会留暗角残影</b>——旧版只放到 <code>scale 2.0</code>（半径 460），盖不满画布，靠 opacity 淡出收尾，45.1s 抽帧能看到一个清晰可见的亮圆盘。B 段直接把孔胀到覆盖四角，残影从根上不存在；<br>
  · A 段孔半径按 <code>1/scale</code> <b>等比</b>放大，保证取景比恒定 —— 头恒定占孔径 <b>67%</b>，不会出现「孔不动、头却缩小/涨大」的呼吸感。
</p>
<p class="hint">
  <strong>制作标记已删除</strong>：<code>#bN-piptag</code>「出镜」是给剪辑者看的制作标记，不该出现在成片里。
</p>
<p class="hint">
  另外针对"动效实在太丑，一点也不动感"的返工：内容卡片入场改为<strong>错峰落位 + 持续微漂移</strong>（容器整体 y ±12px，全段缓入缓出），
  而非一次性 slide-in。错峰<strong>只作用于最外层卡片</strong>——父子同时做 y 位移会叠加（34+34=68px），
  子元素里的文字会瞬态溢出父容器（布局门禁在 tween 边界采样时抓到，已用 div 栈还原嵌套关系修掉）。
</p>

<h2><span class="n">08</span>动效 ↔ 音效搭配（依据您的《动画音效搭配逻辑》脑图）</h2>
<p class="hint">
  <strong>不是</strong>按固定间隔撒点：有动效才有音，动效是什么就用什么音。计划由 <code>plan.js</code> 的
  <code>buildSfxPlan(cues)</code> 从<strong>真实动效事件</strong>（章节标题动效 / 排版组合动效 / b-roll 版面动效 / 内容重音）逐条译出，
  再按「同一时刻只留一个音 + 全局最小间隔 ${P.SFX_MIN_GAP}s」做密度控制。
</p>
<table>
  <tr><th style="width:17%">脑图类别</th><th style="width:11%">音效词</th><th style="width:15%">音源</th><th>本片对应动效</th><th style="width:8%">时长</th><th style="width:7%">用量</th></tr>
  ${sfxHTML}
</table>
<p class="hint">
  全片共 <strong>${SFX_TOTAL} 处</strong>（≈每 3.3 秒一次）。入场段允许三音连击（缩放→波纹→内容，间隔 0.48 / 0.72s），版面主体留白呼吸。
  音量按"越重的动效越响"分档：跃入 / 缩放 0.19–0.21 &gt; 位移 / 落定 0.16–0.18 &gt; 铺陈类（水滴 / 渐隐）0.12–0.14。<br>
  <strong>本片未用到、但已备好的音源库</strong>（脑图词汇表的其它条目，供后续项目复用）：
  ${sfxUnused.map((n) => `<code>${n}</code>`).join(' · ')}。<br>
  本片没有对应动效（无模糊转场、无翻转翻页、无弹簧回弹）的条目<strong>不硬塞</strong> —— 塞进去只会违反"不要过于频繁"。<br>
  <strong>BGM 不加入</strong>——未提供授权音源，且原声已占满中频。音效由 <code>build-sfx.sh</code> 用 ffmpeg <code>lavfi/aevalsrc</code> 合成（无外部素材，任何机器可重建），槽位与媒体时长精确对齐。
  画面运动：缓慢推近 <code>${PUSH.from} → ${PUSH.to}</code>，入场 ${PUSH.inSec}s / 出场 ${PUSH.outSec}s，全片 ${P.PUSH_PLAN.length} 处。
</p>

<h2><span class="n">09</span>字体角色</h2>
<div class="rolegrid">
  ${FONTS.map(([r, tok, name, why]) => `<div class="rolecard"><b>${esc(r)}</b><code>${esc(tok)} → ${esc(name)}</code><span>${esc(why)}</span></div>`).join('')}
</div>
<p class="hint">
  未来角色映射（您指定，本片未用到）：女生固定 清刻本悦 / 金陵体 / 研宋体；男生固定 金陵体。
  本片为男声，标题层实际使用 粗宋 + 华光中长宋。子集化见 <code>subset-fonts.js</code>，替换方式见 <code>FONTS.md</code>。
</p>

<h2><span class="n">10</span>色板</h2>
<div class="swatches">${swHTML}</div>

<h2><span class="n">11</span>技术门禁</h2>
<table>
  <tr><th style="width:22%">通道</th><th style="width:14%">error</th><th style="width:14%">warning</th><th>说明</th></tr>
  <tr><td>lint</td><td><b>0</b></td><td>112</td><td class="dim">全为官方模板同款结构提示：108 条 <code>nested_structure_needs_subcomposition</code> · 3 条 <code>timeline_track_too_dense</code> · 1 条 <code>composition_file_too_large</code></td></tr>
  <tr><td>runtime</td><td><b>0</b></td><td><b>0</b></td><td class="dim">GSAP 选择器全部命中，无空选择器</td></tr>
  <tr><td>layout</td><td><b>0</b></td><td><b>0</b></td><td class="dim">文字盒、溢出、重叠全部合规（含 <code>--at-transitions</code> 在 tween 边界的瞬态采样）</td></tr>
  <tr><td>motion</td><td><b>0</b></td><td><b>0</b></td><td class="dim">时间线单调、无同属性冲突</td></tr>
  <tr><td>contrast</td><td><b>0</b></td><td><b>0</b></td><td class="dim">WCAG AA 全通过（红斜杠为此提亮 4%）</td></tr>
</table>
<div class="note">
  <b>诚实披露</b>：<code>vidmuse</code> CLI 在本环境<strong>未安装</strong>（属付费 / 需授权安装）。
  因此官方的 <strong>Serve 实时预览</strong>与 <strong>Timeline UI 检查点无法执行</strong>——
  本片实时预览以本地 <code>hyperframes snapshot</code> + 内置预览面板替代，
  时间线正确性靠 <code>hyperframes check</code> 的 motion 通道（0 error）与逐帧抽检保证。
  如需官网 Serve / Timeline UI 检查，需要您先明确同意安装该 CLI。
</div>

<footer>
  生成器：<code>build-design-preview.js</code>（读 theme.js / plan.js，单源真相）·
  字幕系统：<code>build-subtitles.js</code> → <code>caption-plan.json</code> ·
  合成：<code>build-composition.js</code> → <code>public/index.html</code> ·
  检查报告：<code>ck10.json</code> · 参考片实测：<code>qa/ref/</code> · 成片抽检：<code>qa/sheet-A.jpg</code> / <code>qa/sheet-B.jpg</code>
</footer>

</div>
</body>
</html>
`;

fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, html, 'utf8');
console.log(`design-preview/index.html 已生成`);
console.log(`  样张 ${STILLS.length} 张 | 章节 ${P.SECTIONS.length} | 组合 ${combos.length} | b-roll ${P.BROLL_PLAN.length} | 音效 ${SFX_TOTAL}`);
