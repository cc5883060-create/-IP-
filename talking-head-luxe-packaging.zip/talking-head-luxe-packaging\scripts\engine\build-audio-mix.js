// build-audio-mix.js — 最终交付音轨的外挂混音器。
//
// 为什么需要它（第六轮实测结论，勿再踩）：
//   hyperframes render 对 <audio> 元素的混音**不可靠**——
//   单元素微测能混上，多元素场景下只有部分元素进混音器（实测：主合成 72 个
//   <audio> 里只有 source-audio 的人声进了成片，52 处音效全丢；v6 的 BGM 也丢）。
//   所以最终交付音轨改为渲染后用 ffmpeg 外挂混音：
//     人声(1.0) + BGM(0.14, 已预做首尾淡入淡出) + 70 处语义音效(adelay 卡点)
//   <audio> 元素仍保留在合成里（Serve/预览时能听到），但**成片音轨以本脚本为准**。
//
// 用法：node build-audio-mix.js  → 生成 scratch/mix-filter.txt + public/../scratch/final-mix.wav
//   然后：ffmpeg -y -i <成片.mp4> -i scratch/final-mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest <最终.mp4>
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const WORK = __dirname;
const P = require(path.join(WORK, 'plan.js'));
const T = require(path.join(WORK, 'theme.js'));
const cues = JSON.parse(fs.readFileSync(path.join(WORK, 'subtitles.timeline.json'), 'utf8'));

const BGM_VOL = 0.5; // 这条 preview 母带电平偏低（中段 RMS ≈ -29dB），0.5 ≈ 人声 RMS 下 12dB 的垫底
const plan = P.buildSfxPlan(cues);

// ffmpeg 输入：0=人声(原片音轨) 1=BGM 2..=音效
// ⚠ BGM 必须用 bgm.wav —— 本机旧 ffmpeg 的 libmp3lame 编码全静音，bgm.mp3 不可用。
const inputs = [
  path.join(WORK, 'public/input-video.mp4'),
  path.join(WORK, 'public/bgm.wav'),
  ...plan.map((n) => path.join(WORK, 'public/sfx', (T.SFX_ROLE[n.key] || 'pop') + '.mp3')),
];
const chains = [];
chains.push('[0:a]aresample=48000[voice]');
chains.push(`[1:a]aresample=48000,volume=${BGM_VOL}[bgm]`);
plan.forEach((n, i) => {
  const vol = T.SFX_VOL[n.key] != null ? T.SFX_VOL[n.key] : 0.16;
  const ms = Math.round(n.at * 1000);
  chains.push(`[${i + 2}:a]aresample=48000,volume=${vol},adelay=${ms}|${ms}[s${i}]`);
});
const mixIns = ['[voice]', '[bgm]', ...plan.map((_, i) => `[s${i}]`)].join('');
chains.push(`${mixIns}amix=inputs=${plan.length + 2}:normalize=0:dropout_transition=0,alimiter=limit=0.891:level=false,aresample=48000[mix]`);
fs.writeFileSync(path.join(WORK, 'scratch/mix-filter.txt'), chains.join(';\n'), 'utf8');

// 注意：本机 PATH 上的 ffmpeg（剪映自带旧版）不支持 -filter_complex_script，必须内联传参。
const args = ['-y', '-v', 'error'];
for (const f of inputs) args.push('-i', f);
args.push('-filter_complex', chains.join(';'),
  '-map', '[mix]', '-ac', '2', '-ar', '48000', '-c:a', 'pcm_s16le',
  '-t', String(T.DUR), path.join(WORK, 'scratch/final-mix.wav'));
execFileSync('ffmpeg', args, { stdio: 'inherit' });
console.log(`mix ok: voice + bgm(${BGM_VOL}) + ${plan.length} sfx → scratch/final-mix.wav`);
