// build-subtitles.js — 口播字幕引擎（v2）
//
// 设计依据（用户规范）：
//  1. 基础字幕一行不超过 10 个字；11–12 字且句意完整 → 缩小字号保一行；
//     超过则断句；若前后句意密不可分、必须同时出现才完整 → 走「字幕排版设计」。
//  2. 断句只能落在真实词边界（segmentit），拉丁词（B-roll / AI / skill）绝不拆开。
//  3. 每个字幕单元归类为 base(普通) / emphasis(重点词强调) / layout(字幕排版设计)。
//  4. 重点词强调很短的，给一点提前量（字幕与效果提前出现），
//     但「出点」正好落在说话的重音位置。
//
// 宽度口径：用「视觉宽度」而不是原始字符数 —— B-roll 占 3 个字宽，skill 占 3 个，
// 这样「一个自动找 B-roll 的 skill」= 12 字宽，正好落在可缩字号保一行的区间。
//
// 输出：transcript.json / subtitles.timeline.json / caption-plan.json
const fs = require('fs');
const path = require('path');
const { createRequire } = require('module');
const requireFromWorkspace = createRequire('C:/Users/Administrator/.workbuddy/binaries/node/workspace/index.js');
const { Segment, useDefault } = requireFromWorkspace('segmentit');
const segmenter = useDefault(new Segment());

const WORK = __dirname;
const SRT_SRC = 'E:/美业对标素材/陆总口播剪辑测试/b-roll skill分享.srt';
const MEDIA_DURATION = 160.277;

// ---- 阈值 ----
const MAX_VISUAL = 10;      // 一行上限（视觉宽度）
const SOFT_VISUAL = 12;     // 可缩小字号保一行的上限
const MIN_PART_VISUAL = 3;  // 拆分出的片段至少多宽
const LAYOUT_MIN_PARTS = 2;
const LAYOUT_MAX_PARTS = 3;
const LAYOUT_MAX_DUR_PER_PART = 1.75; // 编组内每段允许占用的时长
const LAYOUT_MAX_DUR_CAP = 4.2;       // 编组总时长上限
const LAYOUT_MAX_PART = 10; // 编组内每段单独占一行，因此与单行上限一致
const MIN_CUE_DUR = 0.62;   // 单条字幕最短展示时长，太短动画施展不开

// ---- 重点词表（决定 emphasis 与高亮词）----
// 刻意收紧：SOP 要求「不要处处加料、只挑重点」，高亮过半就失效了。
// 只留真正有信息量的专有名词与核心概念，日常词（素材/文案/下载）不进高亮。
const KEYWORDS = [
  'B-roll', 'b-roll', 'AI', 'ai', 'skill', 'Codex', 'codex', 'Pexels', 'MP4', '4K',
  '筛选', '路径', '审美', '逻辑', '经验', '工作流', '时间线',
];

// 断句时「不该甩到下一行开头」的字/词（虚词、副词、后置成分）
const HEAD_BAD_CHARS = new Set([...'的了是和与或就也都还很把被给让对从向再又更最而但且所因如只光净需']);
const HEAD_BAD_WORDS = ['全部', '直接', '重新', '自动', '基本', '大概', '主要', '一定', '千万', '真的', '其实', '特别', '非常', '找到', '然后', '这个', '那个'];

function headPenalty(head) {
  for (const w of HEAD_BAD_WORDS) if (head.startsWith(w)) return 14;
  if (head && HEAD_BAD_CHARS.has(head[0])) return 16;
  return 0;
}

// ---- 人工覆盖：自动化分不理想的（按 SRT 原句精确匹配）----
const OVERRIDES = {
  // 「一步一步」与「全部搓出来给你看」是两个意群
  '一步一步的全部搓出来给你看到': ['一步一步的', '全部搓出来给你看到'],
  // 「特别容易被忽略」是一个整体，不能从「特别」后断开
  '还有一个特别容易被忽略的细节啊': ['还有一个', '特别容易被忽略的细节啊'],
  // 「codex b-roll素材」是一个文件夹名，不能被拆成「codex b-roll」+「素材文件夹里」
  'codex b-roll素材文件夹里': ['codex b-roll素材', '文件夹里'],
  // 全片论点句（跨 SRT 边界合并后）：自动切分会在「AI」后断，读起来别扭
  '所以啊这才是我认为AI真正能改变剪辑工作流的地方': ['所以啊这才是', '我认为AI真正能', '改变剪辑工作流的地方'],
  // 「分析出来的」是一个动补结构，不能在「分析」后断
  '让它根据刚才分析出来的b-roll需求': ['让它根据刚才分析出来的', 'b-roll需求'],
  // 「如果…素材」是条件从句的主语，不能被拆到下一行
  '如果AI找出来素材不是我满意的': ['如果AI找出来素材', '不是我满意的'],
  // 「把自己的剪辑经验」是一个完整的动宾结构
  '而是我可以把自己的剪辑经验': ['而是我可以把自己的', '剪辑经验'],
  // 「下载的规则」与「全部写进一个skill里」是两个意群（与参考片一致）
  '下载的规则全部写进一个skill里': ['下载的规则', '全部写进一个skill里'],
};

// ---- 跨句合并 ----
// SRT 的切分是转写器的句子边界，不等于语义边界。但合并必须保守：
// 早期版本只要前句以「的」收尾就合并，结果把「做IP口播剪辑的」+「是不是经常不知道…」
// 粘成 22 字宽的长句，反而更糟。只合并「撑不住一拍」的短承接句。
//   例：「也避免」+「高清素材长期」→ 合成一拍，避免「也避免」单独占一行。
const MERGE_TAIL = /[的地得和与或把被对从向]$/;
const MERGE_HEAD_CONJ = /^[也就都还而但所因且又再更最然接]/;
const MERGE_MAX_PREV = 6; // 只有「短到撑不住一拍」的前句才合并

// 语义跨过 SRT 边界、且前句并不短的，单独列出来强制合并
// （转写器在这里断句了，但句子没说完）
const FORCED_MERGES = [
  ['所以啊这才是我认为AI真正能', '改变剪辑工作流的地方'], // 全片论点句
];

function mergeCues(cues) {
  const out = [];
  for (const c of cues) {
    const prev = out[out.length - 1];
    if (prev) {
      const gap = c.start - prev.end;
      const forced = FORCED_MERGES.some(([a]) => prev.text === a);
      const shortFragment = visWidth(prev.text) < MERGE_MAX_PREV;
      const needsNext = MERGE_TAIL.test(prev.text) || MERGE_HEAD_CONJ.test(prev.text);
      if (gap < 0.35 && (forced || (shortFragment && needsNext))) {
        prev.text += c.text;
        prev.end = c.end;
        continue;
      }
    }
    out.push({ start: c.start, end: c.end, text: c.text });
  }
  return out;
}

// ---------- 基础工具 ----------
function parseSrt(raw) {
  const cues = [];
  const blocks = raw.replace(/\r\n/g, '\n').trim().split('\n\n');
  for (const b of blocks) {
    const lines = b.split('\n').filter(Boolean);
    if (lines.length < 2) continue;
    const m = lines[1].match(/(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)/);
    if (!m) continue;
    const start = +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000;
    const end = +m[5] * 3600 + +m[6] * 60 + +m[7] + +m[8] / 1000;
    const text = lines.slice(2).join('').trim();
    if (text) cues.push({ start, end, text });
  }
  return cues;
}

const PUNCT = /^[，。、！？：；,.!?:;·…—－\-]$/;
const isLatinToken = (t) => /[A-Za-z]/.test(t) && /^[A-Za-z0-9][A-Za-z0-9\-.]*$/.test(t);

/** 视觉宽度：CJK=1，拉丁词≈0.52/字符，数字≈0.55/字符，空格 0.35，标点 0.5 */
// ---- 视觉宽度：改用**真实字体度量**（俊雅体 CJK 推进只有 0.75em，粗放的「CJK=1」会低估）
const TM = require('./type-metrics.js');
const { CAPTION: CAP } = require('./theme.js');

// 全角标点 ink 很窄（虽然 advance 是全角），断句时按视觉重量折算，否则「，」会误判成占满一个字
const CJK_PUNCT = /[\u3000-\u303f\uff01-\uff0f\uff1a-\uff20\uff3b-\uff40\uff5b-\uff65\u2018\u2019\u201c\u201d\u2026\u2014]/;

function visWidth(s) {
  let u = 0;
  for (const ch of s) {
    if (CJK_PUNCT.test(ch)) { u += 0.6; continue; }
    u += TM.charAdv(ch, 'JunYa') / TM.ADV.JunYa.cjk;   // 归一化到「一个俊雅体 CJK 字」= 1 单位
  }
  return Math.round(u * 10) / 10;
}

/** 该行按当前字号/字距渲染后的**实际像素宽度**（含重点词放大）—— 用于安全区硬校验 */
function renderPx(text, size, emphasis = []) {
  return TM.measure(text, {
    font: 'JunYa', size,
    letterSpacing: CAP.letterSpacing,
    emphasis, emphasisScale: 1.12,
  }).px;
}
const SAFE_PX = TM.safeWidth(1080, CAP.safeInset);

/** 切成词：CJK 单字 + 拉丁词整体（保证 B-roll 不会被拆） */
function tokenize(text) {
  const tokens = [];
  const re = /([A-Za-z][A-Za-z0-9\-.]*|\d+(?:\.\d+)?|[，。、！？：；,.!?:;\s])/gu;
  let last = 0, m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) for (const ch of text.slice(last, m.index)) tokens.push({ text: ch, w: 1 });
    const tok = m[0];
    if (/^\s+$/.test(tok)) tokens.push({ text: tok, w: 0.35 });
    else if (PUNCT.test(tok)) tokens.push({ text: tok, w: 0.5 });
    else tokens.push({ text: tok, w: Math.max(1, Math.round(tok.length * 0.52)) });
    last = m.index + tok.length;
  }
  if (last < text.length) for (const ch of text.slice(last)) tokens.push({ text: ch, w: 1 });
  return tokens;
}

/** 拼回文本：拉丁词之间的空格要保留（否则 "codex b-roll" 会变成 "codexb-roll"），其余空白丢弃 */
function joinTokens(toks) {
  let s = '';
  for (let i = 0; i < toks.length; i++) {
    const t = toks[i];
    if (/^\s+$/.test(t.text)) {
      const prev = toks[i - 1], next = toks[i + 1];
      if (prev && next && isLatinToken(prev.text) && isLatinToken(next.text)) s += ' ';
      continue;
    }
    s += t.text;
  }
  return s.trim();
}

/** 真实词边界（token 下标） */
function wordBoundaries(tokens) {
  const sanitized = tokens.map(t => (isLatinToken(t.text) ? '\u3007' : t.text)).join('');
  const segs = segmenter.doSegment(sanitized, { simple: true });
  const bounds = new Set();
  let idx = 0;
  for (const s of segs) { if (idx > 0) bounds.add(idx); idx += Array.from(s).length; }
  return bounds;
}

/** 标点边界（强断点） */
function punctBoundaries(tokens) {
  const b = new Set();
  tokens.forEach((t, i) => { if (PUNCT.test(t.text) && i > 0 && i < tokens.length - 1) b.add(i + 1); });
  return b;
}

// ---------- 主体 ----------
const srtCues = parseSrt(fs.readFileSync(SRT_SRC, 'utf8'));

// 1) 词级时序（在每条 SRT cue 内按权重比例分配）
const words = [];
for (const c of srtCues) {
  const toks = tokenize(c.text);
  const totalW = toks.reduce((s, t) => s + t.w, 0);
  const dur = Math.max(0.08, c.end - c.start);
  let t0 = c.start;
  for (const tok of toks) {
    const d = dur * tok.w / totalW;
    words.push({ text: tok.text, start: +t0.toFixed(3), end: +Math.min(t0 + d, MEDIA_DURATION).toFixed(3) });
    t0 += d;
  }
}

/** 在 cue 内做最优二分/三分 */
function splitParts(tokens, wordsHere, maxParts) {
  const bounds = new Set([...wordBoundaries(tokens)]);
  wordsHere.forEach((w, i) => {
    if (i > 0 && (isLatinToken(wordsHere[i - 1].text) || isLatinToken(w.text) || /^\s+$/.test(wordsHere[i - 1].text))) bounds.add(i);
  });

  // 先在「强断点（标点）」处贪心切；不足再补弱断点
  // 评估一个切点。注意：**不要求右半立刻合规** —— 长句需要切 3 刀，
  // 第一刀的右半必然还超宽，会由 rec() 继续切。早期在这里要求两边都 ≤10，
  // 导致 23 字宽的长句一刀都切不动，只能整条超宽输出。
  const tryCut = (start, end) => {
    let best = -1, bestScore = -1e9;
    for (let i = start + 1; i < end; i++) {
      if (!bounds.has(i)) continue;
      const a = visWidth(joinTokens(wordsHere.slice(start, i)));
      const b = visWidth(joinTokens(wordsHere.slice(i, end)));
      if (a < MIN_PART_VISUAL || b < MIN_PART_VISUAL) continue;
      if (i === start + 1 && b < MIN_PART_VISUAL * 2) continue;
      const gap = wordsHere[i].start - wordsHere[i - 1].end;
      const head = wordsHere[i].text;
      let score = 0;
      score += a <= MAX_VISUAL ? 16 : -8;          // 左半是否一次到位
      score += b <= MAX_VISUAL ? 16 : -8;          // 右半是否一次到位
      score += Math.min(a, Math.min(b, MAX_VISUAL)) * 2 - Math.abs(a - Math.min(b, MAX_VISUAL)) * 0.7;
      score += gap * 10;
      if (PUNCT.test(wordsHere[i - 1].text)) score += 14;      // 标点后断最自然
      score -= headPenalty(head);                              // 别把「的/是/就/全部」甩到下一行开头
      if (isLatinToken(wordsHere[i - 1].text) && !isLatinToken(head)) score += 6;
      const durA = wordsHere[i].start - wordsHere[start].start;
      const durB = wordsHere[end - 1].end - wordsHere[i].start;
      if (durA < 0.5) score -= 24;
      if (durB < 0.5) score -= 24;
      if (score > bestScore) { bestScore = score; best = i; }
    }
    return best;
  };

  // 递归切分：贪心一次切不动时继续对左右两半递归，保证长句一定被切开
  const rec = (start, end, depth) => {
    if (visWidth(joinTokens(wordsHere.slice(start, end))) <= MAX_VISUAL) return [[start, end]];
    if (depth > 4) return null;
    const cut = tryCut(start, end);
    if (cut < 0) return null;
    const left = rec(start, cut, depth + 1);
    const right = rec(cut, end, depth + 1);
    if (!left || !right) return null;
    return [...left, ...right];
  };

  const parts = rec(0, wordsHere.length, 0);
  if (!parts || parts.length > maxParts) return null;
  return parts;
}

/** 人工覆盖：把「切分后的文本数组」映射回 token 下标区间 */
const norm = (s) => s.replace(/\s+/g, '');
function overrideRanges(tokens, partsText) {
  const ranges = [];
  let ti = 0;
  for (const p of partsText) {
    const target = norm(p);
    const start = ti;
    let acc = '';
    while (ti < tokens.length && acc.length < target.length) {
      acc += tokens[ti].text.replace(/\s+/g, '');
      ti++;
    }
    if (acc !== target) return null; // 覆盖文本与原文对不上，放弃（回落到自动切分）
    ranges.push([start, ti]);
  }
  if (ti < tokens.length) ranges[ranges.length - 1][1] = tokens.length;
  return ranges;
}

// 2) 逐条（已合并的）SRT cue 处理
const mergedCues = mergeCues(srtCues);
const units = []; // 每个 unit 可含 1 段(base/emphasis) 或 2-3 段(layout)

for (const cue of mergedCues) {
  const tokens = tokenize(cue.text);
  const wordsHere = words.filter(w => w.start >= cue.start - 0.02 && w.end <= cue.end + 0.02);
  const vw = visWidth(cue.text);
  const dur = cue.end - cue.start;

  const mk = (text, start, end, kind, size, extras = {}) =>
    ({ text, start: +start.toFixed(3), end: +end.toFixed(3), kind, size, ...extras });

  if (wordsHere.length < 2) {
    units.push([mk(cue.text, cue.start, cue.end, 'base', vw > MAX_VISUAL ? 'small' : 'normal')]);
    continue;
  }

  // (a) 一行放得下
  if (vw <= MAX_VISUAL) {
    units.push([mk(cue.text, cue.start, cue.end, 'base', 'normal')]);
    continue;
  }
  // (b) 11–12 字宽且句意完整 → 缩字号保一行
  if (vw <= SOFT_VISUAL) {
    units.push([mk(cue.text, cue.start, cue.end, 'base', 'small')]);
    continue;
  }
  // (c) 需要断句（人工覆盖优先于自动切分）
  const forced = OVERRIDES[cue.text] ? overrideRanges(tokens, OVERRIDES[cue.text]) : null;
  const parts = forced || splitParts(tokens, wordsHere, LAYOUT_MAX_PARTS);

  if (!parts || parts.length < 2) {
    units.push([mk(cue.text, cue.start, cue.end, 'base', 'small', { cramped: true })]);
    continue;
  }

  const segs = parts.map(([a, b]) => ({
    text: joinTokens(wordsHere.slice(a, b)),
    start: wordsHere[a].start,
    end: wordsHere[b - 1].end,
    vw: visWidth(joinTokens(wordsHere.slice(a, b))),
  }));

  // 是否有标点把两段分开？有 → 是两个独立句子，各自单行即可
  const hasPunctSplit = parts.slice(0, -1).some(([, b]) => PUNCT.test(wordsHere[b - 1].text));

  // 编组时长上限随段数放宽：2 段 3.5s、3 段 5.25s→封顶 4.2s。
  // 早期用固定 2.9s，把 3.08s 的「下载的规则全部 / 写进一个skill里」误判成不能编组。
  const maxDur = Math.min(LAYOUT_MAX_DUR_CAP, segs.length * LAYOUT_MAX_DUR_PER_PART);
  const shortBalanced = segs.every(s => s.vw <= LAYOUT_MAX_PART)
    && segs.length <= LAYOUT_MAX_PARTS
    && dur <= maxDur;

  if (!hasPunctSplit && shortBalanced) {
    // 句意密不可分 → 字幕排版设计：同屏编组，按口播顺序逐行出现
    units.push(segs.map((s, i) =>
      mk(s.text, s.start, i === segs.length - 1 ? cue.end : segs[i + 1].start,
        'layout', 'normal', { partIndex: i, partCount: segs.length })));
  } else {
    units.push(segs.map((s, i) =>
      mk(s.text, s.start, i === segs.length - 1 ? cue.end : segs[i + 1].start, 'base',
        s.vw > MAX_VISUAL ? 'small' : 'normal')));
  }
}

// 3) 展平 + 重点词标注
const flat = [];
let gidSeq = 0;
for (const group of units) {
  const isLayout = group.length > 1 && group[0].kind === 'layout';
  const gid = isLayout ? 'g' + String(++gidSeq).padStart(3, '0') : null;
  for (const u of group) {
    u.groupId = gid;
    u.emphasis = KEYWORDS.filter(k => u.text.includes(k));
    // 注意：layout 是「结构身份」，emphasis 是「是否含高亮词」，两者可共存。
    // 早期版本在这里把 layout 覆盖成 emphasis，导致排版设计编组丢失，别再犯。
    if (u.kind !== 'layout' && u.emphasis.length) u.kind = 'emphasis';
    flat.push(u);
  }
}

// 4) 重点词时序 + 提前量
for (const u of flat) {
  if (!u.emphasis.length) continue;
  u.emphasisSpans = [];
  for (const kw of u.emphasis) {
    const ws = words.filter(w => w.start >= u.start - 0.05 && w.end <= u.end + 0.05);
    const hit = ws.find(w => w.text === kw) || ws.find(w => kw.includes(w.text) && w.text.length > 1);
    if (hit) u.emphasisSpans.push({ word: kw, start: hit.start, end: hit.end });
  }
  // 短重点词给提前量：字幕与效果提前出现，出点落在重音上
  const d = u.end - u.start;
  u.lead = (u.kind === 'emphasis' && d <= 1.15) ? 0.12 : 0;
}

// 5) 时间轴修正：不重叠、保证最短展示时长、避免仓促
for (let i = 0; i < flat.length; i++) {
  const u = flat[i];
  if (u.lead) u.start = Math.max(0, +(u.start - u.lead).toFixed(3));
  const prev = flat[i - 1];
  if (prev && u.start < prev.end + 0.02) u.start = +(prev.end + 0.02).toFixed(3);
  if (u.end <= u.start) u.end = +(u.start + 0.35).toFixed(3);
  const next = flat[i + 1];
  if (next) u.end = Math.min(u.end, next.start - 0.01);
  // 太短 → 允许往后撑（不侵入下一条），保证动画有施展空间
  if (u.end - u.start < MIN_CUE_DUR) {
    const cap = next ? next.start - 0.01 : MEDIA_DURATION;
    u.end = +Math.min(cap, u.start + MIN_CUE_DUR).toFixed(3);
  }
}
// layout 编组的行内次序修正：后出现的那行不应该早于前一行结束太多
for (let i = 1; i < flat.length; i++) {
  if (flat[i].groupId && flat[i].groupId === flat[i - 1].groupId && flat[i].start < flat[i - 1].start) {
    flat[i].start = flat[i - 1].start;
  }
}

// ---------- 输出 ----------
// 6) 安全区硬校验：按「真实字宽 + 字间距 + 中西文间隙 + 重点词放大」算出渲染宽度。
//    超出安全区就先降到小字号，再不行标记出来（用户明确要求：绝不允许字出画面）。
const SIZE_PX = { normal: CAP.sizeNormal, small: CAP.sizeSmall };
function emRanges(text, kws) {
  const chars = [...text];
  const out = [];
  for (const kw of kws || []) {
    const i = text.indexOf(kw);
    if (i < 0) continue;
    out.push({ start: [...text.slice(0, i)].length, end: [...text.slice(0, i + kw.length)].length });
  }
  return out;
}
for (const u of flat) {
  const em = emRanges(u.text, u.emphasis);
  let size = u.size || 'normal';
  let px = renderPx(u.text, SIZE_PX[size], em);
  if (px > SAFE_PX && size === 'normal') { size = 'small'; px = renderPx(u.text, SIZE_PX.small, em); }
  u.size = size;
  u.renderPx = Math.round(px);
  u.overflow = px > SAFE_PX;
}

const timeline = flat.map((u, i) => ({
  id: 'cue-' + String(i + 1).padStart(3, '0'),
  text: u.text,
  startTime: u.start,
  endTime: u.end,
  // 以下为渲染元数据
  kind: u.kind,
  size: u.size,
  visualWidth: visWidth(u.text),
  renderPx: u.renderPx,
  overflow: !!u.overflow,
  groupId: u.groupId,
  partIndex: u.partIndex ?? null,
  partCount: u.partCount ?? null,
  emphasis: u.emphasis,
  emphasisSpans: u.emphasisSpans || [],
  lead: u.lead || 0,
}));

fs.writeFileSync(path.join(WORK, 'transcript.json'), JSON.stringify(words, null, 1), 'utf8');
fs.writeFileSync(path.join(WORK, 'subtitles.timeline.json'), JSON.stringify(timeline, null, 1), 'utf8');
fs.writeFileSync(path.join(WORK, 'caption-plan.json'), JSON.stringify({
  thresholds: { MAX_VISUAL, SOFT_VISUAL, MIN_CUE_DUR, LAYOUT_MAX_DUR_PER_PART, LAYOUT_MAX_DUR_CAP, LAYOUT_MAX_PART },
  counts: {
    total: flat.length,
    base: flat.filter(u => u.kind === 'base').length,
    emphasis: flat.filter(u => u.kind === 'emphasis').length,
    layout: flat.filter(u => u.kind === 'layout').length,
    layoutGroups: new Set(flat.filter(u => u.groupId).map(u => u.groupId)).size,
    overLimit: flat.filter(u => visWidth(u.text) > SOFT_VISUAL).length,
    tooShort: flat.filter(u => u.end - u.start < MIN_CUE_DUR - 0.001).length,
  },
  timeline,
}, null, 1), 'utf8');

// ---------- 报告 ----------
const c = JSON.parse(fs.readFileSync(path.join(WORK, 'caption-plan.json'), 'utf8')).counts;
console.log('SRT 条数:', srtCues.length, '→ 合并后:', mergedCues.length, '| 输出字幕条数:', c.total);
console.log(`  普通 base: ${c.base} | 重点词强调 emphasis: ${c.emphasis} | 排版设计 layout: ${c.layout}（${c.layoutGroups} 组）`);
console.log(`  超 12 字宽: ${c.overLimit} | 短于 ${MIN_CUE_DUR}s: ${c.tooShort}`);
const over = timeline.filter(u => u.visualWidth > SOFT_VISUAL);
if (over.length) over.forEach(u => console.log('  ! 超宽', u.startTime.toFixed(2), u.visualWidth, u.text));
const short = timeline.filter(u => u.endTime - u.startTime < MIN_CUE_DUR - 0.001);
if (short.length) short.forEach(u => console.log('  ! 过短', u.startTime.toFixed(2), (u.endTime - u.startTime).toFixed(2), u.text));
const overPx = timeline.filter(u => u.overflow);
console.log(`  安全区: 可用宽 ${SAFE_PX}px（内边距 ${CAP.safeInset}×2）| 最宽一条 ${Math.max(...timeline.map(u => u.renderPx))}px | 越界 ${overPx.length} 条`);
overPx.forEach(u => console.log('  ! 出画', u.startTime.toFixed(2), u.renderPx + 'px', u.text));
const merged = mergedCues.filter((m, i) => i < mergedCues.length - 1 && m.end < (mergedCues[i + 1] ? mergedCues[i + 1].start : 0));
console.log('--- 跨句合并（共 ' + (srtCues.length - mergedCues.length) + ' 处）---');
const layouts = timeline.filter(u => u.groupId);
if (layouts.length) {
  console.log('--- 排版设计编组 ---');
  const seen = new Set();
  for (const u of layouts) {
    if (seen.has(u.groupId)) continue;
    seen.add(u.groupId);
    console.log('  ' + u.groupId, layoutText(u.groupId, timeline));
  }
}
function layoutText(gid, tl) { return tl.filter(x => x.groupId === gid).map(x => x.text).join(' / '); }
