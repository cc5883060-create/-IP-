#!/usr/bin/env bash
# Generate the semantic SFX set with ffmpeg (no external audio assets needed).
set -e
cd "$(dirname "$0")"
mkdir -p public/sfx

# soft airy whoosh — card entrances
ffmpeg -y -v error -f lavfi -i "anoisesrc=d=0.55:c=pink:a=0.9" \
  -af "highpass=f=260,lowpass=f=3800,afade=t=in:st=0:d=0.16,afade=t=out:st=0.26:d=0.29,volume=0.75" \
  -ac 2 -ar 44100 public/sfx/whoosh-soft.mp3

# deep whoosh — full-canvas collage takeovers
ffmpeg -y -v error -f lavfi -i "anoisesrc=d=0.7:c=brown:a=1.0" \
  -af "lowpass=f=1400,highpass=f=90,afade=t=in:st=0:d=0.2,afade=t=out:st=0.34:d=0.36,volume=0.9" \
  -ac 2 -ar 44100 public/sfx/whoosh-deep.mp3

# thin whoosh — arrows / connectors
ffmpeg -y -v error -f lavfi -i "anoisesrc=d=0.34:c=white:a=0.75" \
  -af "highpass=f=1200,lowpass=f=7200,afade=t=in:st=0:d=0.06,afade=t=out:st=0.12:d=0.22,volume=0.7" \
  -ac 2 -ar 44100 public/sfx/whoosh-thin.mp3

# ui tick — list item stagger
ffmpeg -y -v error -f lavfi -i "anoisesrc=d=0.08:c=white:a=0.85" \
  -af "highpass=f=2400,lowpass=f=9000,afade=t=out:st=0.012:d=0.068,volume=0.85" \
  -ac 2 -ar 44100 public/sfx/tick.mp3

# soft pop — numbers / confirmation
ffmpeg -y -v error -f lavfi -i "sine=f=430:d=0.16" -f lavfi -i "sine=f=860:d=0.12" \
  -filter_complex "[0:a]afade=t=out:st=0.02:d=0.14,volume=0.5[a];[1:a]afade=t=out:st=0.01:d=0.1,volume=0.28[b];[a][b]amix=inputs=2:duration=longest" \
  -ac 2 -ar 44100 public/sfx/pop.mp3

# paper flip — collage / quote reveals
ffmpeg -y -v error -f lavfi -i "anoisesrc=d=0.42:c=white:a=0.9" \
  -af "bandpass=f=2600:width_type=o:w=1.6,afade=t=in:st=0:d=0.02,afade=t=out:st=0.1:d=0.32,volume=0.6,atempo=1.0" \
  -ac 2 -ar 44100 public/sfx/paper-flip.mp3

# keyboard clicks — typewriter / path typing
ffmpeg -y -v error -f lavfi -i "anoisesrc=d=0.09:c=white:a=0.9" -f lavfi -i "anoisesrc=d=0.09:c=white:a=0.9" -f lavfi -i "anoisesrc=d=0.09:c=white:a=0.9" \
  -filter_complex "[0:a]highpass=f=1600,lowpass=f=7000,afade=t=out:st=0.015:d=0.075,volume=0.7,adelay=0[a];[1:a]highpass=f=1800,lowpass=f=6500,afade=t=out:st=0.015:d=0.075,volume=0.62,adelay=170[b];[2:a]highpass=f=1500,lowpass=f=7400,afade=t=out:st=0.015:d=0.075,volume=0.68,adelay=360[c];[a][b][c]amix=inputs=3:duration=longest:normalize=0,apad=pad_dur=0.3" \
  -ac 2 -ar 44100 -t 0.8 public/sfx/keyboard.mp3

# ding — conclusion accent
ffmpeg -y -v error -f lavfi -i "sine=f=1320:d=0.7" -f lavfi -i "sine=f=1980:d=0.5" \
  -filter_complex "[0:a]afade=t=out:st=0.05:d=0.65,volume=0.32[a];[1:a]afade=t=out:st=0.03:d=0.45,volume=0.16[b];[a][b]amix=inputs=2:duration=longest" \
  -ac 2 -ar 44100 public/sfx/ding.mp3

# ============================================================================
# 第二批：按用户提供的《动画音效搭配逻辑》脑图补齐 12 类动效的对应音源
#   位移(上下左右)   → 嗖 呼 唰 落地            move / move-fast / move-deep / land
#   缩放(放大缩小)   → 嘭 砰 咚 闪光            zoom-in / zoom-out / flash
#   模糊             → 水滴 魔法 综艺悬疑轻敲    blur(=magic) / suspense
#   折叠开屏收拢     → 纸张 纸张抖动 折扇展开     paper / paper-shake / fan
#   滚动类           → 钱相关 齿轮              coin / gear
#   波纹(晕开吸入)   → 水滴相关                 ripple
#   翻转翻动         → 抖动 啵                  wobble / flip
#   弹簧             → 咚咚                    spring
#   跃入             → 综艺开始系统提示音        jump-in
#   字幕歪到正       → 收音机声音               snap-upright
#   渐隐             → 水滴                    fade
#   生长             → 木质铃铛响一下           grow
# 全部用 ffmpeg lavfi/aevalsrc 合成（无外部素材），所以任何机器上都能重建。
# aevalsrc 表达式里**不能出现逗号**（会截断滤镜图），故全用 floor/exp 写法。
# ============================================================================

# 位移：落地（低闷沉底，用于片段落位）
ffmpeg -y -v error -f lavfi -i "aevalsrc=0.95*sin(2*PI*(96*t-18*t*t))*exp(-13*t):d=0.34:s=44100" \
  -ac 2 -ar 44100 public/sfx/land.mp3

# 缩放：嘭（放大 —— 215→60Hz 俯冲 + 极短冲击头）
ffmpeg -y -v error -f lavfi -i "aevalsrc=1.0*sin(2*PI*(215*t-195*t*t))*exp(-8.5*t):d=0.42:s=44100" \
  -f lavfi -i "anoisesrc=d=0.05:c=white:a=0.8" \
  -filter_complex "[0:a]volume=0.9[a];[1:a]lowpass=f=2400,afade=t=out:st=0.006:d=0.044,volume=0.45[b];[a][b]amix=inputs=2:duration=longest:normalize=0" \
  -ac 2 -ar 44100 public/sfx/boom.mp3

# 缩放：咚（缩小 / 收拢）
ffmpeg -y -v error -f lavfi -i "aevalsrc=0.9*sin(2*PI*(128*t-52*t*t))*exp(-15*t):d=0.30:s=44100" \
  -ac 2 -ar 44100 public/sfx/thud.mp3

# 缩放：闪光（三颗高音铃错峰上行）
ffmpeg -y -v error -f lavfi -i "sine=f=1760:d=0.34" -f lavfi -i "sine=f=2349:d=0.30" -f lavfi -i "sine=f=3136:d=0.26" \
  -filter_complex "[0:a]afade=t=out:st=0.01:d=0.33,volume=0.30,adelay=0[a];[1:a]afade=t=out:st=0.01:d=0.29,volume=0.22,adelay=55[b];[2:a]afade=t=out:st=0.01:d=0.25,volume=0.15,adelay=115[c];[a][b][c]amix=inputs=3:duration=longest:normalize=0" \
  -ac 2 -ar 44100 public/sfx/sparkle.mp3

# 波纹：水滴（晕开 / 吸入 —— 快速上滑 + 余韵）
ffmpeg -y -v error -f lavfi -i "aevalsrc=0.85*sin(2*PI*(600*t+2350*t*t))*exp(-9*t):d=0.60:s=44100" \
  -ac 2 -ar 44100 public/sfx/water-drop.mp3

# 渐隐：水滴（更轻更长，用于淡出与铺陈）
ffmpeg -y -v error -f lavfi -i "aevalsrc=0.55*sin(2*PI*(520*t+1500*t*t))*exp(-4.2*t):d=0.95:s=44100" \
  -ac 2 -ar 44100 public/sfx/water-soft.mp3

# 模糊：魔法（四音上行微光）
ffmpeg -y -v error -f lavfi -i "sine=f=1318:d=0.50" -f lavfi -i "sine=f=1661:d=0.45" \
  -f lavfi -i "sine=f=1975:d=0.40" -f lavfi -i "sine=f=2637:d=0.35" \
  -filter_complex "[0:a]afade=t=out:st=0.02:d=0.48,volume=0.22,adelay=0[a];[1:a]afade=t=out:st=0.02:d=0.43,volume=0.18,adelay=80[b];[2:a]afade=t=out:st=0.02:d=0.38,volume=0.15,adelay=160[c];[3:a]afade=t=out:st=0.02:d=0.33,volume=0.12,adelay=240[d];[a][b][c][d]amix=inputs=4:duration=longest:normalize=0" \
  -ac 2 -ar 44100 public/sfx/magic.mp3

# 模糊：综艺悬疑轻敲（软木鱼）
ffmpeg -y -v error -f lavfi -i "aevalsrc=0.7*sin(2*PI*820*t)*exp(-42*t):d=0.14:s=44100" \
  -ac 2 -ar 44100 public/sfx/tap-soft.mp3

# 折叠：纸张抖动（沙沙 + 颤音）
ffmpeg -y -v error -f lavfi -i "anoisesrc=d=0.34:c=white:a=0.9" \
  -af "bandpass=f=3200:width_type=o:w=1.8,tremolo=f=26:d=0.85,afade=t=in:st=0:d=0.02,afade=t=out:st=0.12:d=0.22,volume=0.45" \
  -ac 2 -ar 44100 public/sfx/paper-shake.mp3

# 折叠：折扇展开（上扫）
ffmpeg -y -v error -f lavfi -i "anoisesrc=d=0.30:c=white:a=0.85" \
  -af "highpass=f=1100,lowpass=f=6400,tremolo=f=9:d=0.5,afade=t=in:st=0:d=0.05,afade=t=out:st=0.10:d=0.20,volume=0.5" \
  -ac 2 -ar 44100 public/sfx/fan.mp3

# 滚动类：齿轮（每 40ms 一齿，指数衰减成拨齿声）
ffmpeg -y -v error -f lavfi -i "aevalsrc=0.6*sin(2*PI*1350*t)*exp(-46*(t-0.04*floor(t/0.04))):d=0.44:s=44100" \
  -ac 2 -ar 44100 public/sfx/gear.mp3

# 滚动类：钱相关（金属叮）
ffmpeg -y -v error -f lavfi -i "sine=f=2093:d=0.36" -f lavfi -i "sine=f=3160:d=0.30" \
  -filter_complex "[0:a]afade=t=out:st=0.01:d=0.35,volume=0.26[a];[1:a]afade=t=out:st=0.005:d=0.29,volume=0.16[b];[a][b]amix=inputs=2:duration=longest:normalize=0" \
  -ac 2 -ar 44100 public/sfx/coin.mp3

# 翻转：抖动（快速颤音）
ffmpeg -y -v error -f lavfi -i "aevalsrc=0.55*sin(2*PI*(430+95*sin(2*PI*26*t))*t)*exp(-11*t):d=0.34:s=44100" \
  -ac 2 -ar 44100 public/sfx/wobble.mp3

# 翻转：啵（上滑小爆破）
ffmpeg -y -v error -f lavfi -i "aevalsrc=0.8*sin(2*PI*(300*t+1500*t*t))*exp(-22*t):d=0.18:s=44100" \
  -ac 2 -ar 44100 public/sfx/bo.mp3

# 弹簧：咚咚（两次回弹）
ffmpeg -y -v error -f lavfi -i "aevalsrc=0.8*sin(2*PI*(150*t-30*t*t))*exp(-17*t):d=0.40:s=44100" \
  -f lavfi -i "aevalsrc=0.55*sin(2*PI*(190*t-10*t*t))*exp(-19*t):d=0.34:s=44100" \
  -filter_complex "[0:a]volume=0.85[a];[1:a]adelay=115,volume=0.7[b];[a][b]amix=inputs=2:duration=longest:normalize=0" \
  -ac 2 -ar 44100 public/sfx/spring.mp3

# 跃入：综艺开始系统提示音（明亮三音上行）
ffmpeg -y -v error -f lavfi -i "sine=f=1175:d=0.55" -f lavfi -i "sine=f=1568:d=0.50" -f lavfi -i "sine=f=2349:d=0.42" \
  -filter_complex "[0:a]afade=t=out:st=0.03:d=0.52,volume=0.26,adelay=0[a];[1:a]afade=t=out:st=0.03:d=0.47,volume=0.24,adelay=90[b];[2:a]afade=t=out:st=0.02:d=0.40,volume=0.22,adelay=180[c];[a][b][c]amix=inputs=3:duration=longest:normalize=0" \
  -ac 2 -ar 44100 public/sfx/variety-in.mp3

# 字幕歪到正：收音机声音（限带噪声 + 咔哒）
ffmpeg -y -v error -f lavfi -i "anoisesrc=d=0.26:c=white:a=0.9" \
  -f lavfi -i "aevalsrc=0.5*sin(2*PI*2400*t)*exp(-70*t):d=0.10:s=44100" \
  -filter_complex "[0:a]bandpass=f=1400:width_type=o:w=2.2,tremolo=f=34:d=0.7,highpass=f=380,afade=t=in:st=0:d=0.01,afade=t=out:st=0.14:d=0.12,volume=0.4[a];[1:a]volume=0.5[b];[a][b]amix=inputs=2:duration=longest:normalize=0" \
  -ac 2 -ar 44100 public/sfx/radio.mp3

# 生长：木质铃铛（马林巴：基音 + 2.8 倍泛音）
ffmpeg -y -v error -f lavfi -i "sine=f=880:d=0.60" -f lavfi -i "sine=f=2464:d=0.34" \
  -filter_complex "[0:a]afade=t=out:st=0.005:d=0.59,volume=0.30[a];[1:a]afade=t=out:st=0.004:d=0.33,volume=0.10[b];[a][b]amix=inputs=2:duration=longest:normalize=0" \
  -ac 2 -ar 44100 public/sfx/bell-wood.mp3

ls -la public/sfx/
