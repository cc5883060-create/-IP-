#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""post-process-draft.py — 给剪映草稿补上「可编辑字幕层 + 排版组合层 + 音效层」。

做四件事：
  1) 字幕轨重写：110 行字幕中，79 行基础/重点词写成原生富文本
     （白字 + 柔和黑投影，重点词独立金色区间，位置 y=-0.2 = 画面 0.600）。
  2) 排版组合层：31 行排版组合行（15 组：上下式6 / 前后式5 / 左右式4）不再平铺，
     而是按 jianying/combo-rows.json 的真实几何（与成片同源 comboRows）落到
     3 条独立文本轨上，用原生关键帧（KFTypePositionX/Y、KFTypeScaleX/Y）复现：
       - 上下式 up_down    ：前句锚在基础位置，后句落到下方，各行独立上滑入场
       - 前后式 front_back ：后句同位置覆盖（前句段在触发点让位截止），后句放大+金色
       - 左右式 left_right  ：后句触发的瞬间，前句左移、后句从左滑入右展开位
  3) 音效轨：70 个落点按 sfx-plan.json 铺设，音量分档。
  4) 校验：JSON 可解析、段数与时长自洽。

关键帧 schema（对齐开源 pyJianYingDraft / 实测草稿）：
  segment.common_keyframes = [{
      "id": <hex>, "material_id": "", "property_type": "KFTypePositionY" | ...,
      "keyframe_list": [{
          "curveType": "Line", "graphID": "",
          "left_control": {"x":0,"y":0}, "right_control": {"x":0,"y":0},
          "id": <hex>, "time_offset": <µs 相对段首>, "values": [<norm>]
      }]}]
  位置取值与 clip.transform 同单位：x = px/1080（右正），y = px/1920（上正）。
  文本段只支持位置/缩放类关键帧（不支持 alpha），入场用位移+缩放表达。

用法：
  python post-process-draft.py --draft-dir <草稿目录> --work <项目根>
"""
import argparse
import json
import os
import shutil
import sys
import uuid

from mutagen import File as MutaFile

FONT_PATH = "C:/Windows/Fonts/msyhl.ttc"
FONT_NAME = "Microsoft YaHei Light"
COMBO_FONT_PATH = "C:/Windows/Fonts/msyhbd.ttc"   # 排版组合用粗体（最接近思源粗宋的可 dependency 字体）
COMBO_FONT_NAME = "Microsoft YaHei"
CAPTION_Y = -0.2          # 画面 0.600 处（1.0 单位 = 画布高；上为正）
BASE_Y_PX = 1152          # 0.600 * 1920
SIZE_NORMAL = 12          # 72px
SIZE_SMALL = 11           # 66px（SOP：11–12 单位的小字档）
GOLD = [1.0, 0.8, 0.5098]  # theme C.gold #FFCC82
WHITE = [1.0, 1.0, 1.0]
BLACK = [0.0, 0.0, 0.0]

D_COMBO = 240_000         # 排版组合动效窗口 0.24s（theme MOTION.combo）
D_FRONT = 300_000         # 前后式后句入场 0.30s（MOTION.combo + 0.06）
PX = 1_000_000            # s → µs


def hexid():
    return uuid.uuid4().hex


def yn(px_y):
    """页面绝对 y（自顶向下 px）→ 剪映 transform 归一值。1152px ↔ -0.2（实测锚点）。"""
    return round(CAPTION_Y + (BASE_Y_PX - px_y) / 1920.0, 6)


def xn(px_x):
    """相对画布中心 x（右正 px）→ 剪映归一值。"""
    return round(px_x / 1080.0, 6)


def fill(color, alpha=1.0):
    return {"alpha": alpha, "content": {"render_type": "solid", "solid": {"alpha": alpha, "color": color}}}


def base_style(a, b, size, color, font_path):
    return {
        "fill": fill(color),
        "range": [a, b],
        "size": size,
        "bold": False,
        "italic": False,
        "underline": False,
        "strokes": [],
        "shadows": [{
            "diffuse": 0.016666666666666666,
            "alpha": 0.6,
            "distance": 5,
            "content": {"solid": {"color": BLACK}},
            "angle": 14,
        }],
        "font": {"path": font_path, "id": ""},
    }


def text_material(tmpl, text, styles, size_units, size_px, font_path, font_name, letter_spacing=0.0):
    mat = dict(tmpl)
    mat["id"] = hexid()
    mat["content"] = json.dumps({"styles": styles, "text": text}, ensure_ascii=False)
    mat["font_size"] = size_units
    mat["text_size"] = int(round(size_px))
    mat["text_color"] = "#FFFFFF"
    mat["text_alpha"] = 1
    mat["alignment"] = 1
    mat["background_style"] = 0
    mat["background_color"] = ""
    mat["background_alpha"] = 1
    mat["border_width"] = 0
    mat["border_color"] = ""
    mat["has_shadow"] = True
    mat["shadow_alpha"] = 0.6
    mat["shadow_distance"] = 5
    mat["shadow_angle"] = 14
    mat["shadow_smoothing"] = 0.1
    mat["shadow_color"] = "#000000"
    mat["font_path"] = font_path
    mat["font_name"] = font_name
    mat["font_resource_id"] = ""
    mat["font_id"] = ""
    mat["letter_spacing"] = letter_spacing
    mat["line_spacing"] = 0.02
    mat["line_max_width"] = 0.82
    mat["force_apply_line_max_width"] = False
    mat["is_rich_text"] = False
    mat["add_type"] = 2
    mat["layer_weight"] = 1
    mat["global_alpha"] = 1.0
    mat["group_id"] = ""
    mat["words"] = {"end_time": [], "start_time": [], "text": []}
    return mat


def build_caption(cue, tmpl, mat_idx):
    """构造一条基础字幕的 (material, segment)。"""
    text = cue["text"]
    size = SIZE_SMALL if cue.get("size") == "small" else SIZE_NORMAL
    styles = [base_style(0, len(text), size, WHITE, FONT_PATH)]
    # 重点词：独立金色区间（+1 号字），剪映里可单词改色
    for sp in cue.get("emphasisSpans") or []:
        w = sp.get("word") or ""
        if not w:
            continue
        i = text.find(w)
        if i < 0:
            continue
        styles.append(base_style(i, i + len(w), size + 1, GOLD, FONT_PATH))

    mat = text_material(tmpl, text, styles, size, size * 6, FONT_PATH, FONT_NAME)
    seg = {
        "id": hexid(),
        "material_id": mat["id"],
        "target_timerange": {"start": int(round(cue["startTime"] * PX)),
                             "duration": int(round((cue["endTime"] - cue["startTime"]) * PX))},
        "source_timerange": None,
        "speed": 1.0,
        "volume": 1.0,
        "visible": True,
        "clip": {"alpha": 1.0,
                 "flip": {"horizontal": False, "vertical": False},
                 "rotation": 0.0,
                 "scale": {"x": 1.0, "y": 1.0},
                 "transform": {"x": 0.0, "y": CAPTION_Y}},
        "common_keyframes": [],
        "render_index": 14000 + mat_idx,
        "track_render_index": 0,
    }
    return mat, seg


# ---------------- 排版组合 ----------------

def kf_item(offset_us, value):
    return {"curveType": "Line", "graphID": "",
            "left_control": {"x": 0.0, "y": 0.0}, "right_control": {"x": 0.0, "y": 0.0},
            "id": hexid(), "time_offset": int(round(offset_us)), "values": [round(float(value), 6)]}


def kf_list(prop, items):
    return {"id": hexid(), "keyframe_list": items, "material_id": "", "property_type": prop}


def build_combo_part(part, g, tmpl, idx):
    """排版组合单段 → (material, segment)。几何来自成片同源 comboRows。"""
    text = part["text"]
    px = part["size"] * part["scale"]                       # 放大倍率直接烘进字号
    size_units = round(px / 6.0, 1)                          # 12 单位 ↔ 72px
    color = GOLD if part["isHl"] else WHITE
    styles = [base_style(0, len(text), size_units, color, COMBO_FONT_PATH)]
    # 组合行内部的重点词：非强调行也保留金色区间
    if not part["isHl"]:
        for sp in part.get("emphasisSpans") or []:
            w = sp.get("word") or ""
            i = text.find(w) if w else -1
            if i >= 0:
                styles.append(base_style(i, i + len(w), size_units + 1, GOLD, COMBO_FONT_PATH))

    mat = text_material(tmpl, text, styles, size_units, px, COMBO_FONT_PATH, COMBO_FONT_NAME,
                        letter_spacing=0.02)

    gtype = g["type"]
    i = part["idx"]
    n = g["n"]
    start = part["start"]
    is_last = i == n - 1

    # 段落区间：up_down / left_right 各段活到组末；front_back 前句让位截止
    if gtype == "front_back" and not is_last:
        seg_start = start
        seg_end = g["parts"][i + 1]["start"] - 0.06         # 下一句触发的让位点
    elif i > 0 and gtype != "up_down":
        seg_start = start - 0.06                            # triggerLead：跟说话同步出现
    else:
        seg_start = start
    seg_end = g["gEnd"]

    y0 = yn(part["y"])
    x0 = xn(part["tx"])
    kfs = []

    if gtype == "up_down":
        # 后句落在下方：上滑入场（56px 下方 → 落定）
        kfs.append(kf_list("KFTypePositionY", [kf_item(0, yn(part["y"] + 56)), kf_item(D_COMBO, y0)]))
    elif gtype == "front_back":
        # 覆盖式：后句同位置放大进场（40px 下方 + 0.9 缩放 → 落定）
        kfs.append(kf_list("KFTypePositionY", [kf_item(0, yn(part["y"] + 40)), kf_item(D_FRONT, y0)]))
        if i > 0:
            kfs.append(kf_list("KFTypeScaleX", [kf_item(0, 0.9), kf_item(D_FRONT, 1.0)]))
            kfs.append(kf_list("KFTypeScaleY", [kf_item(0, 0.9), kf_item(D_FRONT, 1.0)]))
    else:  # left_right
        if i == 0:
            # 前句：先在基础位，后句触发的瞬间向左让位
            trig_off = (g["trig"] - seg_start) * PX
            kfs.append(kf_list("KFTypePositionX", [
                kf_item(0, 0.0), kf_item(trig_off, 0.0), kf_item(trig_off + D_COMBO, x0)]))
        else:
            # 后句：从左侧 110px 滑入右展开位 + 轻微缩放
            kfs.append(kf_list("KFTypePositionX", [kf_item(0, xn(part["tx"] - 110)), kf_item(D_COMBO, x0)]))
            kfs.append(kf_list("KFTypeScaleX", [kf_item(0, 0.94), kf_item(D_COMBO, 1.0)]))
            kfs.append(kf_list("KFTypeScaleY", [kf_item(0, 0.94), kf_item(D_COMBO, 1.0)]))

    seg = {
        "id": hexid(),
        "material_id": mat["id"],
        "target_timerange": {"start": int(round(max(0.0, seg_start) * PX)),
                             "duration": int(round((seg_end - max(0.0, seg_start)) * PX))},
        "source_timerange": None,
        "speed": 1.0,
        "volume": 1.0,
        "visible": True,
        "clip": {"alpha": 1.0,
                 "flip": {"horizontal": False, "vertical": False},
                 "rotation": 0.0,
                 "scale": {"x": 1.0, "y": 1.0},
                 "transform": {"x": x0, "y": y0}},
        "common_keyframes": kfs,
        "render_index": 14500 + idx,
        "track_render_index": 0,
    }
    return mat, seg


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--draft-dir", required=True)
    ap.add_argument("--work", required=True)
    a = ap.parse_args()

    draft_path = os.path.join(a.draft_dir, "draft_content.json")
    d = json.load(open(draft_path, encoding="utf-8"))
    cues = json.load(open(os.path.join(a.work, "subtitles.timeline.json"), encoding="utf-8"))
    cues.sort(key=lambda c: c["startTime"])
    combos = json.load(open(os.path.join(a.work, "jianying/combo-rows.json"), encoding="utf-8"))
    combo_groups = {g["group"] for g in combos}

    mats = d["materials"]
    text_tmpl = mats["texts"][0]
    audio_tmpl = mats["audios"][0]
    text_track = next(t for t in d["tracks"] if t["type"] == "text")
    audio_track_tmpl = next(t for t in d["tracks"] if t["type"] == "audio")

    # ---- 1. 字幕轨重写（排版组合行不进平铺轨，改走组合轨）
    mats["texts"] = []
    text_track["segments"] = []
    flat_idx = 0
    for cue in cues:
        if cue.get("kind") == "layout" and cue.get("groupId") in combo_groups:
            continue  # 由排版组合轨呈现
        mat, seg = build_caption(cue, text_tmpl, flat_idx)
        mats["texts"].append(mat)
        text_track["segments"].append(seg)
        flat_idx += 1
    print(f"[字幕] {flat_idx} 行平铺字幕（含重点词金色区间）")

    # ---- 2. 排版组合轨（3 条，按段序错开避免同轨重叠）
    combo_tracks = []
    for t in range(3):
        tr = dict(text_track)
        tr["id"] = hexid()
        tr["name"] = f"排版组合-{'ABC'[t]}"
        tr["segments"] = []
        combo_tracks.append(tr)
    idx = 0
    for g in combos:
        n = len(g["parts"])
        for i, part in enumerate(g["parts"]):
            part = dict(part)
            part["idx"] = i
            mat, seg = build_combo_part(part, {**g, "n": n}, text_tmpl, idx)
            mats["texts"].append(mat)
            combo_tracks[min(i, 2)]["segments"].append(seg)
            idx += 1
    pos = d["tracks"].index(text_track) + 1
    for k, tr in enumerate(combo_tracks):
        d["tracks"].insert(pos + k, tr)
    n_combo = sum(len(t["segments"]) for t in combo_tracks)
    n_kf = sum(len(s["common_keyframes"]) for t in combo_tracks for s in t["segments"])
    print(f"[排版] {len(combos)} 组 / {n_combo} 段 / {n_kf} 条关键帧轨（{sum(1 for g in combos if g['type']=='up_down')}上下 {sum(1 for g in combos if g['type']=='front_back')}前后 {sum(1 for g in combos if g['type']=='left_right')}左右）")

    # ---- 3. 音效轨
    plan = json.load(open(os.path.join(a.work, "jianying/sfx-plan.json"), encoding="utf-8"))
    sfx_dir = os.path.join(a.work, "public/sfx")
    assets_audio = os.path.join(a.draft_dir, "assets", "audios")
    os.makedirs(assets_audio, exist_ok=True)

    mat_by_file, new_audios, segs = {}, [], []
    for c in plan:
        src = os.path.join(sfx_dir, c["file"])
        if not os.path.isfile(src):
            print(f"[WARN] 缺音效文件 {src}")
            continue
        if c["file"] not in mat_by_file:
            dst = os.path.join(assets_audio, "sfx-" + c["file"])
            shutil.copy2(src, dst)
            dur = int(round(MutaFile(src).info.length * 1e6))
            mid = hexid()
            m = dict(audio_tmpl)
            m.update({
                "id": mid, "local_material_id": mid, "music_id": mid,
                "name": "sfx-" + c["file"], "path": dst, "duration": dur,
                "type": "extract_music", "category_name": "local", "wave_points": [],
            })
            mat_by_file[c["file"]] = {"id": mid, "dur": dur}
            new_audios.append(m)
        info = mat_by_file[c["file"]]
        segs.append({
            "id": hexid(),
            "material_id": info["id"],
            "target_timerange": {"start": int(round(c["at"] * 1e6)), "duration": info["dur"]},
            "source_timerange": None,
            "speed": 1.0,
            "volume": c["vol"],
            "visible": True,
            "clip": {"alpha": 1.0, "flip": {"horizontal": False, "vertical": False},
                     "rotation": 0.0, "scale": {"x": 1.0, "y": 1.0}, "transform": {"x": 0.0, "y": 0.0}},
            "common_keyframes": [],
            "render_index": 12000,
            "track_render_index": 0,
        })

    mats["audios"].extend(new_audios)
    sfx_track = dict(audio_track_tmpl)
    sfx_track["id"] = hexid()
    sfx_track["name"] = "音效"
    sfx_track["segments"] = segs
    d["tracks"].insert(d["tracks"].index(audio_track_tmpl), sfx_track)
    print(f"[音效] {len(segs)} 个落点 / {len(new_audios)} 个音源")

    # ---- 4. 写回 + 自检
    json.dump(d, open(draft_path, "w", encoding="utf-8"), ensure_ascii=False)
    chk = json.load(open(draft_path, encoding="utf-8"))
    n_text = sum(len(t["segments"]) for t in chk["tracks"] if t["type"] == "text")
    n_audio = sum(len(t["segments"]) for t in chk["tracks"] if t["type"] == "audio")
    n_video = sum(len(t["segments"]) for t in chk["tracks"] if t["type"] == "video")
    print(f"[自检] 文本段 {n_text} / 音频段 {n_audio} / 视频段 {n_video} / 总时长 {chk['duration']/1e6:.2f}s")


if __name__ == "__main__":
    sys.exit(main())
