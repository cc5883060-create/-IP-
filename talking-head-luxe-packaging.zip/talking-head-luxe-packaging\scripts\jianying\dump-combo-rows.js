#!/usr/bin/env node
/** dump-combo-rows.js — 把 15 组排版组合的真实几何导出为 jianying/combo-rows.json。
 *  数据源与成片完全同源（theme.comboRows + plan.assignComboTypes），
 *  剪映草稿侧按此落位，保证「上下式 / 前后式 / 左右式」与 v6 成片逐像素一致。
 */
const fs = require('fs');
const path = require('path');
const P = require('./plan.js');
const T = require('./theme.js');

const cues = JSON.parse(fs.readFileSync(path.join(__dirname, 'subtitles.timeline.json'), 'utf8'));
const DOWN = new Set(P.COMBO_DOWNGRADE);
const COMBOS = P.assignComboTypes(P.COMBO_PLAN);

const out = [];
for (const g of COMBOS) {
  if (DOWN.has(g.group)) continue;
  const parts = cues
    .filter((u) => u.groupId === g.group && u.kind === 'layout')
    .sort((a, b) => a.startTime - b.startTime);
  if (!parts.length) continue;
  const rows = T.comboRows(g.type, parts.map((u) => ({ text: u.text })));
  const n = parts.length;
  const gEnd = parts[n - 1].endTime;
  const gStart = parts[0].startTime;
  const lastAt = parts[n - 1].startTime;                 // 后半句开口时刻
  const trig = Math.max(0, lastAt - T.COMBO.triggerLead); // 让位/展开同步时刻
  out.push({
    group: g.group,
    type: g.type,
    gStart, gEnd, trig,
    parts: parts.map((u, i) => ({
      text: u.text,
      start: u.startTime,
      end: u.endTime,
      emphasisSpans: u.emphasisSpans || [],
      y: rows[i].y,          // 行中心（页面绝对 px，自顶向下）
      tx: rows[i].tx,        // 相对画布中心的水平位移 px（右为正）
      size: rows[i].size,    // 基准字号 px
      scale: rows[i].scale,  // 末段放大倍率（up_down 恒 1）
      isHl: g.type !== 'up_down' && i === n - 1, // 后半句金色强调
    })),
  });
}

fs.writeFileSync(path.join(__dirname, 'jianying/combo-rows.json'), JSON.stringify(out, null, 1), 'utf8');
console.log('groups:', out.length, '| parts:', out.reduce((s, g) => s + g.parts.length, 0));
for (const g of out) console.log(`  ${g.group} ${g.type.padEnd(11)} parts=${g.parts.length} y=[${g.parts.map((p) => Math.round(p.y)).join(',')}] tx=[${g.parts.map((p) => Math.round(p.tx)).join(',')}]`);
