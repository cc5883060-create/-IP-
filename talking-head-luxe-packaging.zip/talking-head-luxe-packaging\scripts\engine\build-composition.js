// build-composition.js — 生成 public/index.html
//
// 设计契约来自用户提供的参考片《字幕效果预览》（同一条源素材的包装版），
// 数值全部实测：基础字幕 y=0.600/字号12(72px)、标题斜切底板、金红奶油三色、
// cubic-bezier(0.42,0,0.58,1) 缓动、入场 0.18s / 排版组合 0.24s。
// 规划数据见 plan.js，设计令牌见 theme.js。
const fs = require('fs');
const path = require('path');
const T = require('./theme.js');
const P = require('./plan.js');

const WORK = __dirname;
const PUB = path.join(WORK, 'public');
const { W, H, FPS, DUR, C, F, CAPTION, EMPHASIS, TITLE, COMBO, MOTION, PUSH, BROLL, EASE_SRC, SFX_ROLE, SFX, px } = T;

const cues = JSON.parse(fs.readFileSync(path.join(WORK, 'subtitles.timeline.json'), 'utf8'));
const COMBOS = P.assignComboTypes(P.COMBO_PLAN);
const comboByGroup = new Map(COMBOS.map((c) => [c.group, c]));
const DOWN = new Set(P.COMBO_DOWNGRADE);

// ---------------------------------------------------------------- 工具
const s2 = (n) => n.toFixed(3);
const snap = (t) => Math.round(t * FPS) / FPS;
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const inBroll = (t) => P.BROLL_PLAN.find((b) => t >= b.t0 - 0.02 && t <= b.t1 + 0.02);

/** 把一行文案里的重点词包成 <em class="kw">，并带上字级起始时间（用于把放大卡在重音上） */
/** 把拉丁串包进 .lt —— 让拉丁内部不撑 CJK 式字距、中西文边界仍有间隔。
 *  这是「叫做Pexels」不再贴在一起、同时长英文行不超宽的关键（见 theme.js CAPTION 注释）。 */
const LATIN_RUN = /[0-9A-Za-z][0-9A-Za-z\-.'\u2010-\u2015]*/g;
function wrapLatin(text) {
  let out = '';
  let last = 0;
  for (const m of text.matchAll(LATIN_RUN)) {
    out += esc(text.slice(last, m.index)) + `<span class="lt">${esc(m[0])}</span>`;
    last = m.index + m[0].length;
  }
  out += esc(text.slice(last));
  return out;
}

function renderText(cue, partText) {
  const text = partText != null ? partText : cue.text;
  let spans = (cue.emphasisSpans || []).slice().sort((a, b) => a.start - b.start);
  if (partText != null && partText !== cue.text) {
    // 编组内每一段各自匹配自己包含的重点词
    spans = spans.filter((sp) => text.includes(sp.word));
  }
  let out = '';
  let rest = text;
  for (const sp of spans) {
    const i = rest.indexOf(sp.word);
    if (i < 0) continue;
    out += wrapLatin(rest.slice(0, i));
    out += `<em class="kw" data-ws="${s2(sp.start)}">${wrapLatin(sp.word)}</em>`;
    rest = rest.slice(i + sp.word.length);
  }
  out += wrapLatin(rest);
  return out;
}
/** 整条字幕是否含重点词 */
const hasKw = (cue) => (cue.emphasisSpans || []).length > 0;

// ================================================================ 1. 标题底板 + 章节标题
const PLATE_TOP = TITLE.top;
const PLATE_BOT = TITLE.top + TITLE.height;
/** 斜切平行四边形：用 SVG 描边填充，几何与参考片 标题底板.png 逐点一致 */
function plateSVG() {
  const xTL = TITLE.leftTop, xTR = TITLE.leftTop + TITLE.width;
  const xBL = TITLE.leftTop + TITLE.skewPx, xBR = TITLE.leftTop + TITLE.skewPx + TITLE.width;
  return `<svg class="plate" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" aria-hidden="true">
          <polygon points="${xTL},${PLATE_TOP} ${xTR},${PLATE_TOP} ${xBR},${PLATE_BOT} ${xBL},${PLATE_BOT}" fill="${C.plate}"></polygon>
          <polygon points="${xTL},${PLATE_TOP} ${xTL + TITLE.redBar},${PLATE_TOP} ${xBL + TITLE.redBar},${PLATE_BOT} ${xBL},${PLATE_BOT}" fill="${C.plateRed}"></polygon>
        </svg>`;
}

// ================================================================ 2. 排版动效组合
// 三种式样视觉上必须互相区分：
//   left_right 两侧对角舒展（左段偏上、右段偏下，绝不会横向撞车）
//   up_down    居中逐行落定、全部保留
//   front_back 同位置先后替换（新段进来时旧段缩小淡出 —— 参考片 7.16s 的写法）
function comboParts(groupId) {
  return cues.filter((u) => u.groupId === groupId && u.kind === 'layout').sort((a, b) => a.startTime - b.startTime);
}
function comboLayoutHTML(g) {
  const list = comboParts(g.group);
  const rows = T.comboRows(g.type, list.map((u) => ({ text: u.text })));
  const hl = g.type !== 'up_down';
  // 前后式是**刻意的同位置分层**（后半句覆盖在前句上、前句打透明度关键帧），必然同时在场
  const allow = g.type === 'front_back' ? ' data-layout-allow-overlap' : '';
  const inner = list.map((u, i) => {
    const isHl = hl && i === list.length - 1;
    return `        <div class="cpart cp-${i}" id="${g.group}-p${i}" style="top:${rows[i].y}px;"${allow}>`
      + `<span class="cptext${isHl ? ' hl' : ''}" style="font-size:${rows[i].size}px;"${allow}>${renderText(u)}</span></div>`;
  }).join('\n');
  return `      <div class="clip combo combo-${g.type}" id="combo-${g.group}" data-start="${s2(snap(list[0].startTime))}" data-duration="${s2(Math.max(0.3, snap(list[list.length - 1].endTime) - snap(list[0].startTime)))}" data-track-index="${8 + (COMBOS.indexOf(g) % 4)}">
        <div class="combo-anim" id="combo-${g.group}-anim">
${inner}
        </div>
      </div>`;
}

// 组合内每一段的动效（落位 top 与字号已写进 HTML，这里驱动相对位移、缩放与透明度）
// 三种式样的定义见 theme.js COMBO 注释。核心：**位移由后半句的出现触发**
// （用户：「是因为后半句的重点词才导致前句话让位发生位移」），
// 所以所有「让位 / 展开」类 tween 的起点都挂在**后段**的 startTime 上，而不是组合的开头。
function comboPartTweens(g) {
  const list = comboParts(g.group);
  const rows = T.comboRows(g.type, list.map((u) => ({ text: u.text })));
  const n = list.length;
  const out = [];
  const sel = (i) => `#combo-${g.group}-anim #${g.group}-p${i} .cptext`;
  const gStart = snap(list[0].startTime);
  const lastAt = snap(list[n - 1].startTime);                 // 后半句开始说出的时刻
  const trig = s2(Math.max(0, lastAt - COMBO.triggerLead));   // 让位 / 展开的同步时刻
  const D = MOTION.combo;

  if (g.type === 'up_down') {
    // 上下式：前句落在基础字幕位置，后句在其**下方**落下；两句共存，同尺同色不强调
    for (let i = 0; i < n; i++) {
      out.push(`          tl.fromTo('${sel(i)}', { opacity: 0, y: ${COMBO.gapPx.up_down} }, { opacity: 1, y: 0, duration: ${D}, ease: EASE }, ${s2(snap(Math.max(gStart, list[i].startTime)))});`);
    }
  } else if (g.type === 'front_back') {
    // 前后式：后半句覆盖在前句同一位置；前句打**透明度关键帧**淡出并轻微缩小（保留信息但让位）
    out.push(`          tl.fromTo('${sel(0)}', { opacity: 0, y: ${COMBO.gapPx.front_back} }, { opacity: 1, y: 0, duration: ${D}, ease: EASE }, ${s2(gStart)});`);
    for (let i = 1; i < n; i++) {
      const at = s2(Math.max(0, snap(list[i].startTime) - COMBO.triggerLead));
      out.push(`          tl.fromTo('${sel(i)}', { opacity: 0, scale: ${(rows[i].scale * 0.9).toFixed(3)}, y: ${COMBO.gapPx.front_back} }, { opacity: 1, scale: ${rows[i].scale}, y: 0, duration: ${D + 0.06}, ease: EASE }, ${at});`);
      out.push(`          tl.to('${sel(i - 1)}', { opacity: 0.18, scale: 0.86, duration: ${D}, ease: EASE }, ${at});`);
    }
  } else {
    // 左右式：前句先出现在基础位置；后半句向右展开出现的**同时**，前半句向左位移（点位同步）
    out.push(`          tl.fromTo('${sel(0)}', { opacity: 0 }, { opacity: 1, duration: ${D}, ease: EASE }, ${s2(gStart)});`);
    out.push(`          tl.to('${sel(0)}', { x: ${rows[0].tx}, duration: ${D}, ease: EASE }, ${trig});`);
    for (let i = 1; i < n; i++) {
      out.push(`          tl.fromTo('${sel(i)}', { opacity: 0, x: ${rows[i].tx - 110}, scale: ${(rows[i].scale * 0.94).toFixed(3)} }, { opacity: 1, x: ${rows[i].tx}, scale: ${rows[i].scale}, duration: ${D}, ease: EASE }, ${trig});`);
    }
  }
  // 组合整体退场
  const gEnd = snap(list[n - 1].endTime);
  out.push(`          tl.to('#combo-${g.group}-anim', { opacity: 0, duration: ${MOTION.exit + 0.06}, ease: EASE }, ${s2(Math.max(0, gEnd - MOTION.exit))});`);
  return { tweens: out, start: gStart, end: gEnd };
}

// ================================================================ 3. vox 拼贴 b-roll
// 每个片段都是整屏版面，绝不半挡人物；保留人物时用圆形 PIP（背景挖孔透出原视频）。
// 注意：背景层不透明，视频**只需要覆盖圆形孔所在的矩形**（不是整个画布）。
//
// ⚠ PIP 取景实测（tools/inkbox.js 在源画面上量头部边界）：
//     头顶 y=542 · 下巴 y=980 → 头高 438px，头部中心 (522, 761)；发际横向 322–725，头宽 403px
//   旧值 scale 1.15 + 中心对准 (530,800) 是错的：那对准的是**胸口**，且 1.15 把头放大到 504px，
//   比 460px 的圆孔还高 → 头被顶到边缘、挤满圆框、脸还偏（用户：「人头为什么这么大，一点也不 chill」）。
//   现取 scale 0.70：头高 307px = 圆孔直径的 67%，上下各留 76px 呼吸、左右各留 89px；
//   中心对准头部中心 (522,761)，脸自然居中。
const PIP = BROLL.pip;
// ── 圆形蒙版 = 两段式光圈（几何可行性已被 scratch/iris-sim.js 逐个 u 采样验证，全程 0px 露黑）
//
//  A 段（pipMoveSec）「跟头」：视频从 PIP 取景恢复全画幅，**孔半径按 1/scale 等比放大**
//     （r_pip → r_pip/scale），这样孔的取景比恒定、头始终占孔径 67%，不会出现「孔不动、头缩小/变大」；
//     孔心同步从圆孔位置 (cx,cy) 平移到头部在全画幅下的真实位置 (tx,ty)。
//  B 段（pipIrisSec）「光圈」：视频已全画幅、铺满画布，孔**原地**胀到盖住四角
//     → 蒙版整块不可见，于是退场**完全不需要淡出**，也就不存在「淡出到一半留下一个亮圆盘」的残影。
//
//  ⚠ 单段方案（孔一边平移一边张开）已用仿真证伪：u≈0.5 时孔越出视频元素边界 223px → 露黑。
const PIP_MOVE = BROLL.pipMoveSec;
const PIP_IRIS = BROLL.pipIrisSec;
// A 段末孔半径倍率 = 1/scale：视频放大 1/scale 倍，孔也放大 1/scale 倍 → 取景比不变
const PIP_HOLD = 1 / PIP.scale;
// B 段末孔半径倍率：从 (tx,ty) 到四个画布角的最远距离，再留 pipIrisPad 余量 → 画布全在孔内
const PIP_OPEN = (Math.hypot(Math.max(W - PIP.tx, PIP.tx), Math.max(H - PIP.ty, PIP.ty)) / PIP.r) * BROLL.pipIrisPad;
// 孔心绝对位移：PIP 圆孔位置 → 头部在全画幅下的位置（进场反向使用）
const PIP_MX = PIP.tx - PIP.cx;
const PIP_MY = PIP.ty - PIP.cy;
// 蒙版外扩量：元素比画布大 2×PIP_PAD，孔心与 transform-origin 都要按同一偏移换算
const PIP_PAD = BROLL.pipPad;
// 进出场总时长与片段前后各留的一点余量
const PIP_LEAD = PIP_MOVE + PIP_IRIS;   // 0.72s
/** 退场时序 —— brollTweens 与 pushEvents/sfx 必须共用同一份，否则蒙版与视频会错开
 *  （用户反馈的「圆圈还在、头已经回去了」就是两者各算一套时间的结果）。 */
function exitTiming(b) {
  const ex = b.exit || 'iris';
  // iris = 光圈胀满（0.34s）；fade = 蒙版整体淡出（0.30s）；slide-* = 暗层滑出（0.54s）
  const exB = ex === 'iris' ? PIP_IRIS : ex === 'fade' ? 0.30 : BROLL.exitSlideSec;
  const te = Math.max(0, snap(b.t1) - (PIP_MOVE + exB) - 0.06);   // A 段起点
  const te2 = te + PIP_MOVE + 0.01;                                // B 段起点（10ms 间隙消 overlapping 告警）
  return { te, te2, exB, ex };
}
function pipTransform() {
  const s = PIP.scale;
  const dx = (PIP.cx - 540) - s * (PIP.tx - 540);
  const dy = (PIP.cy - 960) - s * (PIP.ty - 960);
  return { s, dx, dy };
}
/**
 * 版面内容的「文字无关」副本 —— 用作 b-roll 的暗底素材纹理。
 *
 * 用户：「现在每次的背景有些寡淡，可以是黑色背景，但是可以模仿这种背景：相关对应文案的
 * b-roll 素材不透明度拉低，然后加上这种针点波纹效果的背景很有质感」。
 *
 * 做法：把**该版面自己的内容盒子**复制一份，抹掉 id（否则与真身 id 冲突、GSAP 选择器会选错）
 * 与全部文字节点（文字会触发 contrast 通道的低对比误报，而且重模糊后也读不出来），
 * 只留盒子几何 → 重模糊 + 低不透明度铺在纯黑底上 = 「这条文案对应的素材压暗做底」。
 */
function ghostHTML(b, body) {
  const strip = (s) => String(s || '')
    .replace(/\sid="[^"]*"/g, '')
    .replace(/\sdata-w="[^"]*"/g, '')
    .replace(/\sdata-layout-allow-overlap/g, '')
    .replace(/>[^<>]+</g, '><')
    .replace(/>[^<>]+$/, '>');
  const l = strip(body.left), r = strip(body.right);
  if (!l && !r) return '';
  const pad = b.pip ? PIP_PAD : 0;
  const top = contentTopOf(b);
  const bandH = CONTENT_BOT - top;
  const lw = body.lw || 964, rw = body.rw || 964;
  const rLeft = body.rLeft != null ? body.rLeft : 58;
  return `<div class="br-ghost" aria-hidden="true" style="inset:${pad}px;">`
    + (l ? `<div class="br-ghostc br-mid" style="top:${top}px; height:${bandH}px; left:58px; width:${lw}px;">${l}</div>` : '')
    + (r ? `<div class="br-ghostc br-mid" style="top:${top + (body.rightTop || 0)}px; height:${bandH - (body.rightTop || 0)}px; left:${rLeft}px; width:${rw}px;">${r}</div>` : '')
    + `</div>`;
}

/**
 * 针点波纹 —— 静态点阵 + 若干「点环」从中心一圈圈胀开又消失。
 *
 * ⚠ 只动 scale / opacity：这是 hyperframes 允许动画的属性集，而且逐帧 seek 安全。
 *   不能用 GSAP 的 repeat —— 那会破坏「时间轴 = 绝对时间」的前提（抽帧/渲染会在任意时刻 seek）。
 *   所以是「按版面时长铺满若干圈」，而不是无限循环。
 * ⚠ 每条环的 id 形如 `bN-rip0`，会命中 brollTweens 的内容错峰正则，必须在那里排除。
 */
function dotField(b) {
  const rings = [];
  for (let i = 0; i < BROLL.rippleMax; i++) rings.push(`<i class="br-rip" id="${b.id}-rip${i}"></i>`);
  const pad = b.pip ? PIP_PAD : 0;
  return `<div class="br-dots" aria-hidden="true" style="inset:${pad}px;">${rings.join('')}</div>`;
}

function brollBg(b, body) {
  const layers = `${ghostHTML(b, body)}${dotField(b)}`;
  if (!b.pip) return `<div class="br-bg" id="${b.id}-bg">${layers}</div>`;
  // 圆形 PIP：暗层改用 **mask-image**（而不是 background 的 radial-gradient）。
  // 原因：底纹与点阵要做成暗层的**子元素**，才不必为它们各建一套 x/y/scale 关键帧；
  // 而 background 渐变不会裁剪子元素，mask 会 —— 一处蒙版同时管住暗色、底纹、点阵。
  return `<div class="br-bg br-bg-pip" id="${b.id}-bg" style="inset:${-PIP_PAD}px;">${layers}</div>
        <div class="br-ring" id="${b.id}-ring" style="left:${PIP.cx - PIP.r - 5}px; top:${PIP.cy - PIP.r - 5}px; width:${PIP.r * 2 + 10}px; height:${PIP.r * 2 + 10}px;"></div>`;
}
/** 内容区上沿（brollShell 与 ghostHTML 必须用同一个，否则底纹与内容对不上） */
const contentTopOf = (b) => (b.pip ? 660 : (b.title ? 292 : 200));
/** 内容区下沿 = 基础字幕安全带起点。内容在这个区间内**垂直居中**，
 *  否则「4 行表格」这类矮版面会在下方留下半屏空白（用户反馈的「背景寡淡」有一半是留白造成的）。 */
const CONTENT_BOT = 1104;

/** 版面外壳：标题条 + 内容区 + 底部注脚
 *  落位约束（避免「元素自己压自己」与「内容压到字幕上」）：
 *    · 有圆形 PIP 时内容区从孔下沿（610px）之后开始 → 660px
 *    · 无 PIP 时标题条下沿 = 144+104 = 248 → 内容从 292 起；无标题则可从 200 起
 *    · 内容区底边必须留在基础字幕安全带（1104px 起）之上 —— 各版面按此预算压缩
 *  body 可覆盖左右两栏宽度与右栏起始 x（b1 用左右并排，而不是上下叠压）。 */
function brollShell(b, body) {
  const contentTop = contentTopOf(b);
  const lw = body.lw || 964;
  const rw = body.rw || 964;
  const rLeft = body.rLeft != null ? body.rLeft : 58;
  const titleHTML = b.title
    ? `<div class="br-title" id="${b.id}-title"><span class="br-tbar"></span><span class="br-ttext">${esc(b.title)}</span></div>`
    : '';
  // 取景框（用户给的参考片里「● REC + 四角框」的做法）：纯装饰叠加，不改内容布局。
  // 只给需要「逐条核对镜头」语义的版面用（b2）。框体贴住**内容本体**（内容在内容带里垂直居中，
  // 框再按 98px 内边距收一圈），否则矮版面的框里会有一大块空白。
  const frameHTML = b.frame
    ? `<div class="br-frame" aria-hidden="true" style="top:${contentTop + 98}px; height:${CONTENT_BOT - contentTop - 196}px;">
          <i class="br-fc"></i><i class="br-fc"></i><i class="br-fc"></i><i class="br-fc"></i>
          <span class="br-rec"><em></em>REC</span>
        </div>`
    : '';
  const bandH = CONTENT_BOT - contentTop;
  const leftHTML = body.left
    ? `<div class="br-body br-mid" id="${b.id}-bl" style="top:${contentTop}px; height:${bandH}px; left:58px; width:${lw}px;">${body.left}</div>` : '';
  const rightHTML = body.right
    ? `<div class="br-body br-mid" id="${b.id}-br" style="top:${contentTop + (body.rightTop || 0)}px; height:${bandH - (body.rightTop || 0)}px; left:${rLeft}px; width:${rw}px;">${body.right}</div>` : '';
  // 对话框插图（b3 专用，用户第六轮指定）：只显示对话框本体，圆角矩形蒙版（overflow:hidden）。
  const chatHTML = b.chat
    ? `<div class="br-chat" id="${b.id}-chat"><img src="chat-dialog.png" alt="" /></div>`
    : '';
  return `        ${brollBg(b, body)}
        ${leftHTML}
        ${rightHTML}
        ${titleHTML}
        ${frameHTML}
        <div class="br-note" id="${b.id}-note">${esc(b.note || '')}</div>
        ${chatHTML}`;
}

/** 各版面的内容盒子（纯 CSS/SVG，无外部图片） */
const BROLL_BODY = {
  // b1 素材网站搜索：左栏「手机样机里的网站界面」+ 右栏需求词条，左右并排（原先两栏同 x 会上下叠压）
  // 外壳用手机样机而不是浏览器窗口 —— 这一段讲的是「把素材网站告诉 AI」，装进手机框最贴合语义，
  // 也是用户参考片里的常见做法（手机样机 + 角落人像窗）。窄屏下缩略图改 2 列。
  search: (b) => ({
    left: `<div class="br-win${b.chrome === 'phone' ? ' br-phone' : ''}" id="${b.id}-win">
            <div class="br-winbar"><i></i><i></i><i></i><span class="br-url">${esc(b.site)}</span></div>
            <div class="br-search"><span class="br-caret"></span><span class="br-q" id="${b.id}-q">b-roll · 情绪 · 人物</span></div>
            <div class="br-grid">${[0, 1, 2, 3, 4, 5].map((i) => `<div class="br-tile" id="${b.id}-t${i}"></div>`).join('')}</div>
          </div>`,
    right: `<div class="br-terms">${b.terms.map((t, i) => `<div class="br-term" id="${b.id}-tm${i}">${esc(t)}</div>`).join('')}</div>`,
    lw: b.chrome === 'phone' ? 330 : 574, rLeft: b.chrome === 'phone' ? 430 : 656, rw: b.chrome === 'phone' ? 592 : 366, rightTop: 0,
  }),
  // b2 素材 ↔ 文案 对应表
  mapping: (b) => ({
    left: `<div class="br-tbl">${b.rows.map((r, i) => `
            <div class="br-row" id="${b.id}-r${i}">
              <span class="br-no">${esc(r[0])}</span>
              <span class="br-script">${esc(r[1])}</span>
              <span class="br-link">↔</span>
              <span class="br-file">${esc(r[2])}</span>
            </div>`).join('')}</div>`,
  }),
  // b3 筛选三档
  grades: (b) => ({
    left: `<div class="br-grades">${b.items.map((it, i) => `
            <div class="br-grade${i === b.items.length - 1 ? ' ok' : ''}" id="${b.id}-g${i}">
              <span class="br-mark">${esc(it.k)}</span>
              <span class="br-gtext">${esc(it.t)}</span>
              <span class="br-chip">${esc(it.s)}</span>
            </div>`).join('')}</div>`,
  }),
  // b4 剪辑逻辑 & 审美标准
  'two-col': (b) => ({
    left: `<div class="br-cols">
            <div class="br-col" id="${b.id}-c0">
              <div class="br-ch">${esc(b.left.h)}</div>
              ${b.left.l.map((t, i) => `<div class="br-li" id="${b.id}-l0-${i}">${esc(t)}</div>`).join('')}
            </div>
            <div class="br-col right" id="${b.id}-c1">
              <div class="br-ch">${esc(b.right.h)}</div>
              ${b.right.l.map((t, i) => `<div class="br-li" id="${b.id}-l1-${i}">${esc(t)}</div>`).join('')}
            </div>
          </div>`,
  }),
  // b5 格式与画质
  spec: (b) => ({
    left: `<div class="br-spec">${b.rows.map((r, i) => `
            <div class="br-srow" id="${b.id}-s${i}">
              <span class="br-big">${esc(r[0])}</span>
              <span class="br-smain">${esc(r[1])}</span>
              <span class="br-snote">${esc(r[2])}</span>
            </div>`).join('')}</div>`,
  }),
  // b6 下载路径与磁盘
  // ⚠ `.br-fill` 的宽度必须由 `used` 决定。旧版把宽度写成 100% + 只动 scaleX(0→1)，
  //   于是 92% 和 18% 都画成满格 —— 磁盘容量条整条失去意义（本轮修）。
  disk: (b) => ({
    left: `<div class="br-path" id="${b.id}-path">${esc(b.path)}</div>
          <div class="br-disks">${b.disks.map((d, i) => `
            <div class="br-disk" id="${b.id}-d${i}">
              <span class="br-dname">${esc(d.n)}</span>
              <span class="br-bar"><i class="br-fill${d.bad ? ' bad' : ''}" id="${b.id}-f${i}" style="width:${(d.used * 100).toFixed(0)}%"></i></span>
              <span class="br-dlabel${d.bad ? ' bad' : ''}">${esc(d.label)}</span>
            </div>`).join('')}</div>`,
  }),
  // b7 文件夹树
  tree: (b) => ({
    left: `<div class="br-tree">${b.tree.map((n, i) => `
            <div class="br-node br-d${n.d}" id="${b.id}-n${i}">
              <span class="br-ticon">${n.d === 0 ? '▸' : n.d === 1 ? '▸' : '·'}</span>
              <span class="br-tname">${esc(n.t)}</span>
              ${n.n ? `<span class="br-tnote">${esc(n.n)}</span>` : ''}
            </div>`).join('')}</div>`,
  }),
  // b8 经验 → 规则 管道（横向三段，竖向只占 660–907，绝不侵入字幕安全带）
  pipeline: (b) => ({
    left: `<div class="br-pipe">${b.steps.map((st, i) => `
            <div class="br-step" id="${b.id}-s${i}">
              <span class="br-sno">${String(i + 1).padStart(2, '0')}</span>
              <span class="br-stext">${esc(st.t)}</span>
              <span class="br-ssub">${esc(st.s)}</span>
            </div>
            ${i < b.steps.length - 1 ? `<div class="br-sarrow" id="${b.id}-a${i}">→</div>` : ''}`).join('')}</div>`,
  }),
};

function brollHTML(b) {
  const body = (BROLL_BODY[b.kind] || (() => ({})))(b);
  // ⚠ 片段的 data-start 必须**早于**入场过渡的起点。旧版 data-start = t0，而蒙版/视频的
  //   入场 tween 从 t0−0.40 就开始跑 —— 那 0.40s 全发生在片段被渲染之前，等于白跑；
  //   结果观众只看到「画面到 t0 突然切成黑底小孔」的一帧跳变（用户：过渡很割裂）。
  const lead = b.pip ? PIP_LEAD : 0.36;
  const t0 = snap(b.t0), t1 = snap(b.t1);
  const start = s2(Math.max(0, t0 - lead - 0.08)), dur = s2(t1 - 0.02 - Math.max(0, t0 - lead - 0.08));
  return `      <div class="clip broll" id="${b.id}" data-start="${start}" data-duration="${dur}" data-track-index="${2 + (P.BROLL_PLAN.indexOf(b) % 3)}">
        <div class="broll-anim" id="${b.id}-anim">
${brollShell(b, body)}
        </div>
      </div>`;
}

/** b-roll 入场动效：背景先铺，卡片错峰落位，并带极缓的持续漂移（「有动感」但不僵硬） */
// ⚠ 错峰落位必须**只作用于最外层卡片**。父子同时做 y 位移会叠加（34+34=68px），
//   子元素里的文字会瞬态溢出父容器 —— hyperframes check --at-transitions 会在
//   tween 边界采样时抓到（例：#b1-q「b-roll · 情绪 · 人物」是 <span>，溢出 .br-search 11.5px）。
//   下面的 idAncestors() 用 div 栈还原嵌套关系：**任何带 id 的元素**都记录祖先，
//   但只有 <div> 才是容器（模板里所有版面容器都是 div，span/i 是叶子）。
//   嵌套在另一张「会位移的卡片」里的元素只做淡入、不做位移。
function idAncestors(html) {
  const stack = [];
  const anc = new Map();
  const TAG = /<(\/?)([a-zA-Z][\w-]*)((?:"[^"]*"|[^>"])*)>/g;
  let m;
  while ((m = TAG.exec(html))) {
    const isClose = m[1] === '/';
    const tag = m[2].toLowerCase();
    const attrs = m[3];
    if (isClose) { if (tag === 'div') stack.pop(); continue; }
    const idm = /id="([^"]+)"/.exec(attrs);
    if (idm) anc.set(idm[1], stack.filter(Boolean).slice());
    const selfClose = /\/\s*$/.test(m[0]);
    if (tag === 'div' && !selfClose) stack.push(idm ? idm[1] : null);
  }
  return anc;
}
function brollTweens(b) {
  const out = [];
  const t0 = snap(b.t0), t1 = snap(b.t1);
  const dur = t1 - t0;
  const A = `#${b.id}-anim`;
  out.push(`          // ── b-roll ${b.id} [${t0.toFixed(2)}–${t1.toFixed(2)}] ${b.title || ''}`);
  // ⚠ 容器**不做** opacity 淡入。旧版有一条 `#bN-anim` 0.3s 淡入（t0−0.06 起），
  //   它会把整块蒙版一起变成半透明 → 过渡期画面是「半透明暗色叠在全画幅视频上」，
  //   而不是干净的暗底开孔，读起来就是用户说的「一点也不贴合、很割裂」。
  //   现在蒙版自己负责可见性（孔胀满画布 = 不可见），容器恒为 1；非 PIP 版面才走淡入。
  if (b.pip) {
    out.push(`          tl.set('${A}', { opacity: 1 }, 0);`);
  } else {
    out.push(`          tl.fromTo('${A}', { opacity: 0 }, { opacity: 1, duration: 0.34, ease: EASE }, ${s2(Math.max(0, t0 - 0.36))});`);
  }
  // ── 进场：B 段（光圈收拢到头部）→ A 段（视频收成 PIP、孔跟着头走） ──
  //  先 set 好「孔胀满画布」的初态，否则片段一渲染（t0−0.78）就会露出一个带小孔的黑框。
  const tIn0 = Math.max(0, t0 - PIP_LEAD - 0.04);           // 光圈起点
  // +0.01 间隙：B 段末与 A 段首若严格相接，lint 会报 `overlapping_gsap_tweens`
  //（同属性 scale 两条 tween 边界相触）。10ms 的保持帧肉眼不可见，但消掉告警。
  const tIn1 = tIn0 + PIP_IRIS + 0.01;                       // A 段起点
  if (b.pip) {
    // 用 set + to（而不是两条 fromTo）—— fromTo 默认 immediateRender，会在建时间轴时就把
    // from 值写死到元素上，第二条会把第一条的起点覆盖掉（老坑）。
    out.push(`          tl.set('${A} #${b.id}-bg', { scale: ${PIP_OPEN.toFixed(4)}, x: ${PIP_MX}, y: ${PIP_MY} }, 0);`);
    // B 段：孔原地从「盖满画布」收到「贴住头」
    out.push(`          tl.to('${A} #${b.id}-bg', { scale: ${PIP_HOLD.toFixed(4)}, duration: ${PIP_IRIS}, ease: EASE }, ${s2(tIn0)});`);
    // A 段：孔心从头部位置滑到 PIP 圆孔位置，同时等比收到 1（= 视频从全画幅收成 PIP）
    out.push(`          tl.to('${A} #${b.id}-bg', { x: 0, y: 0, scale: 1, duration: ${PIP_MOVE}, ease: EASE }, ${s2(tIn1)});`);
    out.push(`          tl.fromTo('${A} #${b.id}-ring', { opacity: 0, scale: 1.30 }, { opacity: 1, scale: 1, duration: ${PIP_MOVE}, ease: EASE }, ${s2(tIn1)});`);
  } else {
    out.push(`          tl.fromTo('${A} #${b.id}-bg', { opacity: 0 }, { opacity: 1, duration: 0.34, ease: EASE }, ${s2(Math.max(0, t0 - 0.36))});`);
  }
  if (b.title) {
    out.push(`          tl.fromTo('${A} #${b.id}-title', { opacity: 0, x: -54 }, { opacity: 1, x: 0, duration: ${MOTION.card}, ease: EASE }, ${s2(t0 + 0.10)});`);
  }
  if (b.note) {
    out.push(`          tl.fromTo('${A} #${b.id}-note', { opacity: 0, y: 26 }, { opacity: 1, y: 0, duration: ${MOTION.card}, ease: EASE }, ${s2(t0 + 0.26)});`);
  }
  // 对话框插图（b3）：note 让位早退 → 弹簧弹出（back.out 过冲 = 用户要的「动态一点」）。
  // 停留在字幕下方红框区，直到 B 段 fade 才跟着蒙版一起溶解（见下方退场）。
  if (b.chat) {
    out.push(`          tl.to('${A} #${b.id}-note', { opacity: 0, duration: 0.2, ease: EASE }, ${s2(b.chat.at - 0.13)});`);
    out.push(`          tl.fromTo('${A} #${b.id}-chat', { opacity: 0, scale: 0.55, y: 64 }, { opacity: 1, scale: 1, y: 0, duration: 0.5, ease: 'back.out(1.6)' }, ${s2(b.chat.at)});`);
  }
  // 内容元素错峰入场（0.10s 间隔，全部 ease-in-out）
  // 排除容器与单独驱动的元素：-bl/-br 走持续漂移，-f* 走 scaleX 生长
  const ids = [...(brollHTML(b).matchAll(/id="([a-z0-9]+-[a-z]+[0-9]*[a-z0-9-]*)"/g))]
    .map((m) => m[1])
    .filter((id) => !/-(anim|bg|ring|piptag|title|note|bl|br|chat|rip\d+)$/.test(id) && !/-f\d+$/.test(id));
  const stagger = b.kind === 'tree' || b.kind === 'mapping' ? 0.08 : 0.07;
  const anc = idAncestors(brollHTML(b));
  const listedId = new Set(ids);
  ids.forEach((id, i) => {
    const at = t0 + 0.14 + i * stagger;
    if (at > t1 - 0.25) return;
    // 嵌套在另一张「会位移的卡片」里的元素，只淡入 —— 否则位移叠加会把文字顶出容器
    const nested = (anc.get(id) || []).some((a) => listedId.has(a));
    if (nested) {
      out.push(`          tl.fromTo('${A} #${id}', { opacity: 0 }, { opacity: 1, duration: 0.26, ease: EASE }, ${s2(t0 + 0.16 + i * stagger)});`);
    } else {
      out.push(`          tl.fromTo('${A} #${id}', { opacity: 0, y: 34 }, { opacity: 1, y: 0, duration: 0.30, ease: EASE }, ${s2(at)});`);
    }
  });
  // 高亮条 / 进度条：横向生长（用 scaleX，属允许属性）
  (b.disks || []).forEach((d, i) => {
    out.push(`          tl.fromTo('${A} #${b.id}-f${i}', { scaleX: 0 }, { scaleX: 1, duration: 0.55, ease: EASE }, ${s2(t0 + 0.42 + i * 0.16)});`);
  });
  // 针点波纹：若干点环按 rippleGap 错峰胀开又消失（「针点波纹」质感的动态部分）。
  // 分两条 tween（生 → 灭）而不是一条，是因为要让 it「先现后隐」；from 态 opacity:0 保证
  // 在自己那一圈开始之前不显示（fromTo 的 immediateRender 会在建轴时就把 from 写死）。
  const rSpan = BROLL.rippleSpan, rRise = rSpan * 0.28;
  for (let i = 0; i < BROLL.rippleMax; i++) {
    const at = t0 + 0.30 + i * BROLL.rippleGap;
    if (at > t1 - rSpan * 0.5) break;
    const sel = `'${A} #${b.id}-rip${i}'`;
    out.push(`          tl.fromTo(${sel}, { scale: ${BROLL.rippleFrom}, opacity: 0 }, { scale: ${(BROLL.rippleFrom + (BROLL.rippleTo - BROLL.rippleFrom) * 0.34).toFixed(3)}, opacity: ${BROLL.rippleAlpha}, duration: ${rRise.toFixed(2)}, ease: EASE }, ${s2(at)});`);
    out.push(`          tl.to(${sel}, { scale: ${BROLL.rippleTo}, opacity: 0, duration: ${(rSpan - rRise).toFixed(2)}, ease: EASE }, ${s2(at + rRise + 0.01)});`);
  }
  // 持续极缓漂移：让版面「活着」而不是定格（内容块整体 24px 位移，全段缓入缓出）
  // 只在容器真的存在时才建 tween —— 否则 GSAP 会报 "target not found"
  const driftD = s2(Math.max(1, dur - 0.5));
  const bodies = (BROLL_BODY[b.kind] || (() => ({})))(b);
  out.push(`          tl.fromTo('${A} #${b.id}-bl', { y: 12 }, { y: -12, duration: ${driftD}, ease: EASE }, ${s2(t0 + 0.28)});`);
  if (bodies.right) out.push(`          tl.fromTo('${A} #${b.id}-br', { y: 12 }, { y: -12, duration: ${driftD}, ease: EASE }, ${s2(t0 + 0.28)});`);
  // ── 退场：A 段（视频长回全画幅、孔跟着头放大）→ B 段（暗层按版面轮换地收掉）──
  // 关键：蒙版与视频变换**必须同起同落**。用户反馈的「圆圈还在，头已经回去了」就是
  // 视频先归位、蒙版没跟上的结果（反例留存于 qa/round4b）。
  // B 段不再是永远的「光圈胀满」——用户：「每次都是这样展开放大也有点奇怪，可以换换其他方式丝滑出场」。
  //   iris       光圈原地胀满画布（蒙版自然消失、无需淡出）
  //   slide-*    暗层整块滑出画布（擦除式）。此时视频已全画幅，暗层滑走后露出的是完整人像，
  //              **不会露黑边**；滑出量按元素实际外扩量算（PIP 版面的暗层是 inset:-600 的 2280×3120）。
  const { te, te2, exB, ex } = exitTiming(b);
  // 滑出量必须足够让**缩放后**的暗层完全离场，否则会残留一大块黑：
  // 圆形蒙版元素是 inset:-600 的 2280×3120，A 段结束后 scale=PIP_HOLD(1.43)、
  // 孔心已平移到 (PIP_MX,PIP_MY)，此时元素在画布上的跨度约 x∈[−1492,1764] / y∈[−823,2433]，
  // 所以左/上要挪走 ≥2060、右要 ≥1492、下要 ≥3124。统一取 3400/3600 覆盖两个方向与两种尺寸。
  const OFFX = 3400, OFFY = 3600;
  out.push(`          tl.to('${A} #${b.id}-bl', { opacity: 0, duration: 0.18, ease: EASE }, ${s2(te)});`);
  if (bodies.right) out.push(`          tl.to('${A} #${b.id}-br', { opacity: 0, duration: 0.18, ease: EASE }, ${s2(te)});`);
  if (b.title) out.push(`          tl.to('${A} #${b.id}-title', { opacity: 0, duration: 0.16, ease: EASE }, ${s2(te)});`);
  if (b.note) out.push(`          tl.to('${A} #${b.id}-note', { opacity: 0, duration: 0.16, ease: EASE }, ${s2(te)});`);
  if (b.frame) out.push(`          tl.to('${A} .br-frame', { opacity: 0, duration: 0.16, ease: EASE }, ${s2(te)});`);
  // 对话框不跟 A 段内容退场 —— 多停 ~0.5s，跟 B 段蒙版 fade 一起溶解回全屏口播（用户：
  // 「停留个1-2秒，然后过渡回归到完整口播界面」）。A 段暗层仍盖满画布，观感干净。
  if (b.chat) out.push(`          tl.to('${A} #${b.id}-chat', { opacity: 0, duration: ${Math.max(0.2, exB - 0.04).toFixed(2)}, ease: EASE }, ${s2(te2 + 0.04)});`);
  // A 段：只有 PIP 版面需要把孔心从圆孔位置跟到头上、等比放大到 PIP_HOLD（取景比恒定）。
  // 此时视频同步长回全画幅（见 pushEvents）。这一段是用户明确认可的效果，保持不动。
  if (b.pip) {
    out.push(`          tl.to('${A} #${b.id}-ring', { opacity: 0, duration: 0.14, ease: EASE }, ${s2(te)});`);
    out.push(`          tl.to('${A} #${b.id}-bg', { x: ${PIP_MX}, y: ${PIP_MY}, scale: ${PIP_HOLD.toFixed(4)}, duration: ${PIP_MOVE}, ease: EASE }, ${s2(te)});`);
  }
  // B 段：暗层收掉。三种机制按版面轮换（用户：「每次都是这样展开放大也有点奇怪」）：
  //   iris       孔原地胀满画布 → 蒙版自然不可见（不需要淡出，也就没有残影）
  //   fade       蒙版整体淡出 = 与全画幅人像做交叉溶解（同样干净，观感完全不同）
  //   slide-*    暗层整块滑出画布 —— 此时视频已全画幅，滑走即露出人像（擦除式）
  if (ex === 'iris') {
    out.push(`          tl.to('${A} #${b.id}-bg', { scale: ${PIP_OPEN.toFixed(4)}, duration: ${PIP_IRIS}, ease: EASE }, ${s2(te2)});`);
  } else if (ex === 'fade') {
    // 交叉溶解。圆形版**一边化开一边把孔再张开一点**（scale ×1.5）：
    // 只做纯 opacity 的话，孔里的亮人像会在暗层里被读成「一个静止的亮圆盘在淡出」（旧版的毛病）；
    // 加上同步外扩，读起来就是「圆窗化开、人长回画面」。整屏版只淡出。
    const extra = b.pip ? `, scale: ${(PIP_HOLD * 1.5).toFixed(4)}` : '';
    out.push(`          tl.to('${A} #${b.id}-bg', { opacity: 0${extra}, duration: ${exB}, ease: EASE }, ${s2(te2)});`);
  } else {
    const v = ex === 'slide-up' ? `y: ${-OFFY}` : ex === 'slide-down' ? `y: ${OFFY}`
      : ex === 'slide-left' ? `x: ${-OFFX}` : `x: ${OFFX}`;
    out.push(`          tl.to('${A} #${b.id}-bg', { ${v}, duration: ${exB}, ease: EASE }, ${s2(te2)});`);
  }
  out.push(`          tl.to('${A}', { opacity: 0, duration: 0.02, ease: EASE }, ${s2(te2 + exB + 0.02)});`);
  return out;
}

// ================================================================ 4. 基础字幕层
const comboGroupIds = new Set(COMBOS.map((c) => c.group));
const capClips = [], capTweens = [];
let capIdx = 0;
for (const u of cues) {
  // 编组内字幕由组合层渲染（降级的 g007 除外，仍走普通字幕）
  const replacedByCombo = u.kind === 'layout' && u.groupId && comboGroupIds.has(u.groupId) && !DOWN.has(u.groupId);
  if (replacedByCombo) continue;
  capIdx++;
  const id = `cap-${String(capIdx).padStart(3, '0')}`;
  const start = snap(u.startTime), end = snap(u.endTime);
  const d = Math.max(0.2, end - start);
  const b = inBroll((start + end) / 2);
  const size = u.size === 'small' ? CAPTION.sizeSmall : CAPTION.sizeNormal;
  const kw = hasKw(u) && u.kind === 'emphasis';
  capClips.push(`      <div class="clip caption${b ? ' on-collage' : ''}" id="${id}" data-start="${s2(start)}" data-duration="${s2(d)}" data-track-index="20">
        <div class="cap-anim" id="${id}-in">
          <div class="cap-box"><span class="cap-text" style="font-size:${size}px;">${renderText(u)}</span></div>
        </div>
      </div>`);
  // 入场：短促 + 缓动（用户要求「加缓动但不要太慢」，参考片入场 0.18s）
  const inD = MOTION.entr, at = s2(start + 0.01);
  capTweens.push(`          tl.fromTo('#${id}-in .cap-box', { opacity: 0, y: 14 }, { opacity: 1, y: 0, duration: ${inD}, ease: EASE }, ${at});`);
  // 重点词强调：放大峰值卡在字级起始时间（重音）上，允许 ≤0.10s 提前量。
  // 静态基准交给 GSAP 的 fromTo（CSS 里不写 transform，避免被 GSAP 覆盖）
  if (kw) {
    (u.emphasisSpans || []).forEach((sp, i) => {
      const peak = snap(sp.start);
      const lead = Math.min(P.EMPHASIS_LEAD, Math.max(0, peak - start));
      const from = Math.max(start, peak - lead);
      const sel = `#${id}-in .kw:nth-of-type(${i + 1})`;
      const pulse = Math.max(0.08, peak - from);
      capTweens.push(`          tl.fromTo('${sel}', { scale: ${EMPHASIS.scale} }, { scale: ${(EMPHASIS.scale * 1.07).toFixed(3)}, duration: ${s2(pulse)}, ease: EASE }, ${s2(from)});`);
      capTweens.push(`          tl.to('${sel}', { scale: ${EMPHASIS.scale}, duration: 0.16, ease: EASE }, ${s2(from + pulse + 0.01)});`);
    });
  }
  // 基础字幕硬切出（参考片同款），只有长字幕才给一点缓出，避免与下一句交叠发糊
  if (d > 2.4) capTweens.push(`          tl.to('#${id}-in .cap-box', { opacity: 0, duration: 0.12, ease: EASE }, ${s2(Math.max(start + 0.4, end - 0.12))});`);
}

// ================================================================ 5. 标题层 / 组合层
const titleClips = [], titleTweens = [];
for (const s of P.SECTIONS) {
  const t0 = snap(s.t0), t1 = snap(s.t1);
  // 字号已按参考片实拍校准（theme.js PX）。校准后 ink 之间都有净空，但粗宋 em-box（1.44em）在
  // num↔main 与 开场 line1(124px 大字)↔line2 两处仍会交叠 —— 这是度量口径差异而非排版缺陷
  // （参考片实拍就是同一套中心坐标），故这两处显式声明 data-layout-allow-overlap。
  const AL = ' data-layout-allow-overlap';
  // 章节号有两种：纯数字序号 `1.` `2.` `3.`（配红色分隔斜杠），
  // 以及英文标识 `TIPS` `RULES`（金线徽标，**不带斜杠** —— 英文标识与标题之间不需要 `/`，
  // 而且 `TIPS` 的拉丁小字紧贴斜杠时视觉上会撞在一起）。
  const isTag = /^[A-Za-z][A-Za-z ]*$/.test(s.num);
  const inner = s.kind === 'open'
    ? `        <div class="tt-open"${AL}>
          <div class="tt-l1">
${s.line1.map((seg, i) => `            <span class="tt-seg tt-${seg.role} tt-s${i}">${esc(seg.t)}</span>`).join('\n')}
          </div>
          <div class="tt-l2"><span class="tt-l2text"${AL}>${esc(s.line2.t)}</span></div>
        </div>`
    : `        <div class="tt-sec"${AL}>
          <span class="tt-num${isTag ? ' lat' : ''}"${AL}>${esc(s.num)}</span>
${isTag ? '' : `          <span class="tt-slash"${AL}>/</span>\n`}          <span class="tt-main"${AL}>${esc(s.main)}</span>
          <span class="tt-sub"${AL}>${esc(s.sub)}</span>
        </div>`;
  titleClips.push(`      <div class="clip title" id="tb-${s.id}" data-start="${s2(t0)}" data-duration="${s2(t1 - t0)}" data-track-index="${5 + (P.SECTIONS.indexOf(s) % 3)}">
        <div class="title-anim" id="tb-${s.id}-anim">
${plateSVG().split('\n').map((l) => '  ' + l).join('\n')}
${inner}
        </div>
      </div>`);
  // 底板淡入（0.20s）；文字按参考片：大编号/斜杠「渐显」0.18s，主标题「向上滑动」0.18s，副说明 0.18s
  const A = `#tb-${s.id}-anim`;
  titleTweens.push(`          // ── 标题 ${s.id} [${t0.toFixed(2)}–${t1.toFixed(2)}]`);
  titleTweens.push(`          tl.fromTo('${A} .plate', { opacity: 0 }, { opacity: 1, duration: 0.20, ease: EASE }, ${s2(t0)});`);
  if (s.kind === 'open') {
    s.line1.forEach((seg, i) => {
      titleTweens.push(`          tl.fromTo('${A} .tt-s${i}', { opacity: 0, y: 18 }, { opacity: 1, y: 0, duration: ${MOTION.entr}, ease: EASE }, ${s2(t0 + i * 0.06)});`);
    });
    titleTweens.push(`          tl.fromTo('${A} .tt-l2text', { opacity: 0, y: 22 }, { opacity: 1, y: 0, duration: ${MOTION.entr}, ease: EASE }, ${s2(t0 + 0.28)});`);
  } else {
    titleTweens.push(`          tl.fromTo('${A} .tt-num', { opacity: 0 }, { opacity: 1, duration: ${MOTION.entr}, ease: EASE }, ${s2(t0)});`);
    // 英文标识版没有斜杠元素 —— 不加这条 tween，否则 GSAP 会报 target not found
    if (!/^[A-Za-z][A-Za-z ]*$/.test(s.num)) {
      titleTweens.push(`          tl.fromTo('${A} .tt-slash', { opacity: 0 }, { opacity: 1, duration: ${MOTION.entr}, ease: EASE }, ${s2(t0 + 0.04)});`);
    }
    titleTweens.push(`          tl.fromTo('${A} .tt-main', { opacity: 0, y: 18 }, { opacity: 1, y: 0, duration: ${MOTION.entr}, ease: EASE }, ${s2(t0 + 0.08)});`);
    titleTweens.push(`          tl.fromTo('${A} .tt-sub', { opacity: 0 }, { opacity: 1, duration: ${MOTION.entr}, ease: EASE }, ${s2(t0 + 0.22)});`);
  }
  titleTweens.push(`          tl.to('${A}', { opacity: 0, duration: 0.18, ease: EASE }, ${s2(Math.max(0, t1 - 0.16))});`);
}

const comboClips = [], comboTweenList = [];
for (const g of COMBOS) {
  if (DOWN.has(g.group)) continue;
  comboClips.push(comboLayoutHTML(g));
  comboTweenList.push(...comboPartTweens(g).tweens);
}

// ================================================================ 6. 画面推近 / 缩进圆形 PIP
const videoTweens = [];
const { s: PIPS, dx: PIPDX, dy: PIPDY } = pipTransform();
const pushEvents = [];
// talking-head 段的缓慢推近（克制：仅 3 处）
for (const p of P.PUSH_PLAN) {
  pushEvents.push({ at: snap(p.t0), to: p.to, dx: 0, dy: 0, dur: PUSH.inSec });
  pushEvents.push({ at: snap(p.t1), to: PUSH.from, dx: 0, dy: 0, dur: PUSH.outSec });
}
// b-roll 段：把视频推进到「人脸进圆」的取景，并在拼贴退场时拉回全画幅。
// ⚠ 回正事件必须与圆形蒙版的 **A 段**严格同源（同起点、同时长、同缓动），
//   否则孔和视频各自演化 → 孔里要么露出视频边缘、要么人跑出孔（用户反馈的
//   「圆圈还在，头已经回去了」）。两处时间统一由 exitTiming() 给出，别再各算一套。
for (const b of P.BROLL_PLAN) {
  if (!b.pip) continue;
  const t0 = snap(b.t0);
  pushEvents.push({ at: t0 - PIP_LEAD - 0.04 + PIP_IRIS + 0.01, to: PIPS, dx: PIPDX, dy: PIPDY, dur: PIP_MOVE });
  pushEvents.push({ at: exitTiming(b).te, to: PUSH.from, dx: 0, dy: 0, dur: PIP_MOVE });
}
pushEvents.sort((a, b) => a.at - b.at);
let prevTo = PUSH.from, prevDx = 0, prevDy = 0;
for (const e of pushEvents) {
  if (e.to === prevTo && e.dx === prevDx && e.dy === prevDy) continue;
  videoTweens.push(`          tl.fromTo('#video-wrap', { scale: ${prevTo}, x: ${prevDx}, y: ${prevDy} }, { scale: ${e.to}, x: ${e.dx}, y: ${e.dy}, duration: ${e.dur}, ease: EASE }, ${s2(Math.max(0, e.at))});`);
  prevTo = e.to; prevDx = e.dx; prevDy = e.dy;
}

// ================================================================ 7. 语义音效
// 音效计划由 plan.js buildSfxPlan() 依据**真实动效事件**产出（见其注释与脑图映射）。
const sfxPlan = P.buildSfxPlan(cues);
const sfxClips = sfxPlan.map((n, i) => {
  const file = T.SFX_ROLE[n.key] || 'pop';
  const vol = T.SFX_VOL[n.key] != null ? T.SFX_VOL[n.key] : 0.16;
  return `      <audio id="sfx-${String(i + 1).padStart(2, '0')}" src="sfx/${file}.mp3" data-start="${s2(n.at)}" data-duration="${SFX[file]}" data-track-index="${30 + (i % 3)}" data-volume="${vol}" data-sfx-key="${n.key}"></audio>`;
}).join('\n');
const sfxStats = sfxPlan.reduce((a, e) => { a[e.key] = (a[e.key] || 0) + 1; return a; }, {});

// ================================================================ 7. 组装
const FACE = `
      @font-face { font-family: "JunYa"; src: url("fonts/JunYa.woff2") format("woff2"); font-weight: 400; font-display: block; }
      @font-face { font-family: "TitleHeavy"; src: url("fonts/TitleHeavy.woff2") format("woff2"); font-weight: 400; font-display: block; }
      @font-face { font-family: "HuaGuang"; src: url("fonts/HuaGuang.woff2") format("woff2"); font-weight: 400; font-display: block; }
      @font-face { font-family: "BodySong"; src: url("fonts/BodySong.woff2") format("woff2"); font-weight: 400; font-display: block; }
      @font-face { font-family: "XiTi"; src: url("fonts/XiTi.woff2") format("woff2"); font-weight: 400; font-display: block; }
      @font-face { font-family: "TeHei"; src: url("fonts/TeHei.woff2") format("woff2"); font-weight: 400; font-display: block; }
      @font-face { font-family: "YanSong"; src: url("fonts/YanSong.woff2") format("woff2"); font-weight: 400; font-display: block; }
      @font-face { font-family: "Inter"; src: url("fonts/Inter-400-latin.woff2") format("woff2"); font-weight: 400; font-display: block; }
`;

const CSS = `
      :root {
        --gold: ${C.gold}; --red: ${C.red}; --cream: ${C.cream}; --white: ${C.white};
        --ink: ${C.ink}; --paper: ${C.paper}; --paper2: ${C.paper2}; --paper3: ${C.paper3};
        --mark: ${C.mark}; --teal: ${C.teal};
      }
      * { box-sizing: border-box; }
      html, body { margin: 0; padding: 0; width: 100%; height: 100%; overflow: hidden; background: #000; }
      #stage { position: relative; width: 100%; height: 100%; overflow: hidden; }
      .clip { position: absolute; left: 0; top: 0; width: ${W}px; height: ${H}px; overflow: hidden; }
      #video-wrap { position: absolute; left: 0; top: 0; width: ${W}px; height: ${H}px; overflow: hidden;
                    will-change: transform; }
      #video-wrap video { width: 100%; height: 100%; object-fit: cover; object-position: 50% 34%; }

      /* ── 基础字幕（参考片：居中 y=0.600、白字、无描边、阴影 60%/模糊 10）──
         letter-spacing 0.22em 是**补偿俊雅体**：它的 CJK 推进只有 0.75em（常规中文 1.0em），
         不补字距就会又小又挤。末尾多出的一格字距会让整行视觉左偏 ls/2，用 margin-left 抵消。 */
      .caption { pointer-events: none; }
      .cap-anim { position: absolute; left: 0; right: 0; top: ${Math.round(CAPTION.centerY * H)}px;
                  margin-top: -${(CAPTION.sizeNormal * CAPTION.lineHeight / 2).toFixed(1)}px;
                  display: flex; justify-content: center; }
      .cap-box { display: inline-block; max-width: 1040px; text-align: center; }
      .cap-text { display: inline-block; font-family: ${F.base}, ${F.tech}, sans-serif; font-weight: 400;
                  color: ${CAPTION.color}; line-height: ${CAPTION.lineHeight};
                  letter-spacing: ${CAPTION.letterSpacing}em; margin-left: ${CAPTION.letterSpacing}em;
                  text-shadow: ${CAPTION.shadow}; white-space: pre-wrap; }
      /* 拉丁串：内部不加 CJK 式字距，右侧补回一格间隔 —— 中西文之间才不会贴在一起 */
      .lt { letter-spacing: 0; }
      .cap-text .lt { margin-right: ${CAPTION.letterSpacing}em; }
      /* 重点词：颜色与倍率由 GSAP 驱动（CSS 不写 transform，否则会被 GSAP 整段覆盖） */
      .cap-text .kw { display: inline-block; font-style: normal; color: ${EMPHASIS.color};
                      transform-origin: 50% 62%; }
      /* b-roll 段落上给字幕一层极淡压暗，保证白字在纸色版面上仍清楚（参考片无此层，因为无 b-roll） */
      .caption.on-collage .cap-box { padding: 10px 46px 12px; border-radius: 8px;
        background: linear-gradient(90deg, rgba(16,13,11,0) 0%, rgba(16,13,11,.58) 14%, rgba(16,13,11,.58) 86%, rgba(16,13,11,0) 100%); }

      /* ── 章节标题（参考片 标题底板.png：斜切平行四边形 + 红边）──
         四件套几何与参考片 ASS 逐值一致：
           大编号 \fs216 pos(237.6,288) / 红斜杠 \fs186 pos(361.8,289.92)
           主标题 \fs150 pos(642.6,236.16) / 副说明 \fs63 pos(658.8,360.96)
         四者是**按中心定位的刻意构图**，字面 ink 之间有 30px+ 净空（主标题 ink 172–301，
         副说明 ink 334–388），但字体 em-box（1.44em）会互相交叠 —— 这是度量口径差异，
         不是排版缺陷，故显式声明 data-layout-allow-overlap。 */
      .title { pointer-events: none; }
      .title-anim { position: absolute; inset: 0; }
      .title .plate { position: absolute; left: 0; top: 0; }
      .tt-sec, .tt-open { position: absolute; inset: 0; }
      .tt-num   { position: absolute; left: ${(TITLE.num.x * W).toFixed(1)}px; top: ${(TITLE.num.y * H).toFixed(1)}px; transform: translate(-50%, -50%);
                  font-family: ${F.heavy}; font-size: ${TITLE.num.size}px; color: ${C.gold}; line-height: 1; white-space: nowrap; }
      /* 英文标识版（TIPS / RULES）：不再是「大编号」，而是一枚金线小徽标。
         换成拉丁字体的中号字，避免大字号的粗宋把 4–5 个字母撑得比红斜杠还宽（会撞）。 */
      .tt-num.lat { font-family: ${F.num}; font-size: 56px; font-weight: 600; letter-spacing: .05em;
                    padding: 12px 24px; border: 3px solid rgba(255,204,130,.52); border-radius: 8px; }
      .tt-slash { position: absolute; left: ${(TITLE.slash.x * W).toFixed(1)}px; top: ${(TITLE.slash.y * H).toFixed(1)}px; transform: translate(-50%, -50%);
                  font-family: ${F.thin}; font-size: ${TITLE.slash.size}px; color: ${C.redSlash}; line-height: 1; white-space: nowrap; }
      .tt-main  { position: absolute; left: ${(TITLE.main.x * W).toFixed(1)}px; top: ${(TITLE.main.y * H).toFixed(1)}px; transform: translate(-50%, -50%);
                  font-family: ${F.heavy}; font-size: ${TITLE.main.size}px; color: ${C.white}; line-height: 1; letter-spacing: .02em; white-space: nowrap; }
      .tt-sub   { position: absolute; left: ${(TITLE.sub.x * W).toFixed(1)}px; top: ${(TITLE.sub.y * H).toFixed(1)}px; transform: translate(-50%, -50%);
                  font-family: ${F.base}; font-size: ${TITLE.sub.size}px; color: ${C.cream}; line-height: 1; letter-spacing: .06em; white-space: nowrap; }
      /* 开场主旨：三段（小字 / 大字重音 / 小字）用 flex 行排，结构性杜绝横向撞字。
         align-items:baseline —— 三段字号不同（73/124/73），不按基线对齐时金字底边会低 15px，
         看起来「0–1 掉下去了」（用户指出的「不是居中水平对齐」就是这个）。 */
      .tt-l1 { position: absolute; left: 0; right: 0; top: ${(0.115 * H).toFixed(1)}px; transform: translateY(-50%);
               display: flex; justify-content: center; align-items: baseline; gap: ${TITLE.open.gap}px; }
      .tt-seg { white-space: nowrap; }
      .tt-base  { font-family: ${F.base};  font-size: ${TITLE.open.base}px; color: ${C.white}; line-height: 1; }
      .tt-heavy { font-family: ${F.heavy}; font-size: ${TITLE.open.heavy}px; color: ${C.gold}; line-height: 1; }
      .tt-l2 { position: absolute; left: 0; right: 0; top: ${(0.180 * H).toFixed(1)}px; transform: translateY(-50%); display: flex; justify-content: center; }
      .tt-l2text { white-space: nowrap; font-family: ${F.heavy}; font-size: ${TITLE.open.line2}px; color: ${C.white}; line-height: 1; letter-spacing: .02em; }

      /* ── 排版组合（三种式样；落位/字号/位移由 theme.js comboRows() 按真实字宽算出后内联）── */
      .combo { pointer-events: none; }
      .combo-anim { position: absolute; inset: 0; }
      .cpart { position: absolute; left: 0; right: 0; display: flex; justify-content: center; }
      .cptext { display: inline-block; white-space: nowrap; line-height: 1.2; margin-top: -0.6em;
                font-family: ${F.heavy}; font-size: ${COMBO.size.up_down}px; color: ${C.white};
                letter-spacing: ${COMBO.letterSpacing}em; text-shadow: ${CAPTION.shadow}; }
      .cptext .lt { margin-right: ${COMBO.letterSpacing}em; }
      /* 后半句是重点 → 放大 1.20× 并改金色（教学视频面板实测「缩放 120%」）。
         倍率用 GSAP 的 scale 驱动，这里只定色。上下式不强调，两句同尺同色。 */
      .cptext.hl { color: ${C.gold}; }

      /* ── vox 拼贴 b-roll ── */
      .broll { pointer-events: none; }
      .broll-anim { position: absolute; inset: 0; }
      /* 圆形蒙版的 transform-origin 必须落在孔心上：进场/退场时缩放的是「孔」而不是整张背景，
         这样过渡读起来是「圆窗张开放大 / 收拢成圆」，而不是突兀的交叉溶解。 */
      .br-bg { position: absolute; inset: 0; background: ${BROLL.bg}; }
      /* 圆形蒙版：用 mask-image（而不是 background 渐变），这样底纹与点阵可以作为暗层的
         子元素被同一处蒙版一起裁剪 —— 否则它们会盖在圆孔上，把视频挡住。 */
      .br-bg-pip {
        background: ${BROLL.bg};
        -webkit-mask-image: radial-gradient(circle at ${PIP.cx + PIP_PAD}px ${PIP.cy + PIP_PAD}px, rgba(0,0,0,0) 0px, rgba(0,0,0,0) ${PIP.r}px, #000 ${PIP.r + BROLL.pipSoft}px);
        mask-image: radial-gradient(circle at ${PIP.cx + PIP_PAD}px ${PIP.cy + PIP_PAD}px, rgba(0,0,0,0) 0px, rgba(0,0,0,0) ${PIP.r}px, #000 ${PIP.r + BROLL.pipSoft}px);
        transform-origin: ${PIP.cx + PIP_PAD}px ${PIP.cy + PIP_PAD}px;
      }
      /* ── 背景质感（用户：「背景有些寡淡…相关对应文案的 b-roll 素材不透明度拉低，
            然后加上这种针点波纹效果的背景很有质感」）── */
      /* 第一层：该版面自己的内容盒子（去 id、去文字）重模糊压暗 —— 「这条文案的素材做了个暗底」 */
      .br-ghost { position: absolute; opacity: ${BROLL.ghostOpacity}; pointer-events: none;
                  filter: blur(${BROLL.ghostBlur}px) saturate(.55);
                  transform: scale(${BROLL.ghostScale}); transform-origin: 50% 46%; }
      .br-ghostc { position: absolute; }
      /* 第二层：静态针点点阵 */
      .br-dots { position: absolute; pointer-events: none;
        background-image: radial-gradient(circle, rgba(242,230,206,${BROLL.dotAlpha}) 0 ${BROLL.dotR}px, rgba(0,0,0,0) ${(BROLL.dotR + 0.7).toFixed(1)}px);
        background-size: ${BROLL.dotPitch}px ${BROLL.dotPitch}px; background-position: 50% 50%; }
      /* 第三层：一圈圈胀开的点环（dotted 圆边框 = 点环）。只用 scale / opacity，逐帧 seek 安全。 */
      .br-rip { position: absolute; left: 50%; top: 50%; width: ${BROLL.rippleSize}px; height: ${BROLL.rippleSize}px;
                margin: ${-BROLL.rippleSize / 2}px 0 0 ${-BROLL.rippleSize / 2}px; border-radius: 50%;
                border: 5px dotted rgba(242,230,206,${BROLL.rippleAlpha}); opacity: 0; }
      .br-ring { position: absolute; border: 5px solid ${BROLL.ring}; border-radius: 50%; }
      /* 取景框（b2）：四角 L 角标 + 右上 REC —— 用户参考片里「逐条核对镜头」的做法。
         top/height 由 brollShell 按内容带算好（贴住内容，不留半屏空白）。 */
      .br-frame { position: absolute; left: 40px; width: 1000px; pointer-events: none; }
      .br-fc { position: absolute; width: 62px; height: 62px; border: 6px solid rgba(122,214,160,.86); }
      .br-fc:nth-child(1) { left: 0; top: 0; border-right: 0; border-bottom: 0; }
      .br-fc:nth-child(2) { right: 0; top: 0; border-left: 0; border-bottom: 0; }
      .br-fc:nth-child(3) { left: 0; bottom: 0; border-right: 0; border-top: 0; }
      .br-fc:nth-child(4) { right: 0; bottom: 0; border-left: 0; border-top: 0; }
      .br-rec { position: absolute; right: 4px; top: -74px; display: flex; align-items: center; gap: 14px;
                font-family: ${F.tech}; font-size: 34px; color: rgba(122,214,160,.92); letter-spacing: .2em; }
      .br-rec em { display: block; width: 22px; height: 22px; border-radius: 50%; background: #e2705a; }
      .br-title { position: absolute; left: 58px; top: ${PIP.cy - PIP.r - 6}px; height: 104px; padding: 0 34px 0 40px;
                  display: flex; align-items: center; background: ${C.paper}; color: ${C.ink}; }
      .br-title { position: absolute; left: 58px; top: ${PIP.cy - PIP.r - 6}px; height: 104px; padding: 0 34px 0 40px;
                  display: flex; align-items: center; background: ${C.paper}; color: ${C.ink}; }
      .br-tbar { position: absolute; left: 0; top: 0; width: 14px; height: 100%; background: ${C.plateRed}; }
      .br-ttext { font-family: ${F.heavy}; font-size: 66px; color: ${C.ink}; letter-spacing: .02em; }
      .br-note { position: absolute; left: 58px; top: 1460px; font-family: ${F.base}; font-size: 46px; color: ${C.paper};
                 border-left: 8px solid ${C.red}; padding-left: 20px; }
      /* 对话框插图（b3）：圆角矩形蒙版 = border-radius + overflow:hidden；
         位于基础字幕(≈1152)下方红框区，90–990px × 1352–1537px，不碰字幕与三档卡 */
      .br-chat { position: absolute; left: 90px; top: 1352px; width: 900px;
                 border-radius: 40px; overflow: hidden; box-shadow: 0 22px 70px rgba(0, 0, 0, .55); }
      .br-chat img { display: block; width: 100%; }
      .br-body { position: absolute; }
      /* 内容在「上沿 → 基础字幕安全带」之间垂直居中。矮版面（4 行表 / 两栏卡）如果不居中，
         下方会留下半屏空白 —— 那本身就是用户说的「背景寡淡」的一部分。 */
      .br-mid { display: flex; flex-direction: column; justify-content: center; }

      /* b1 搜索（左栏 574px + 右栏 366px，内容底边 ≤1070，基础字幕安全带 1104 起） */
      .br-win { background: ${C.paper}; padding: 0 0 20px; }
      /* 手机样机外壳（b1 专用）：讲「把素材网站告诉 AI」，装进手机框比浏览器窗口更贴语义，
         也是用户参考片的常见做法。刘海与底部横条用伪元素画，不进 DOM（ghost 副本里也在）。
         高度锁死 440 = 内容带（660→1104）整高，内部超出部分按「页面被滚动」裁掉。 */
      .br-phone { position: relative; border: 14px solid #2b251e; border-radius: 58px; overflow: hidden;
                  height: 440px; padding: 0 0 18px; box-shadow: 0 18px 46px rgba(0,0,0,.45); }
      .br-phone::before { content: ''; position: absolute; left: 50%; top: 16px; width: 132px; height: 34px;
                          margin-left: -66px; border-radius: 20px; background: #2b251e; z-index: 2; }
      .br-phone::after { content: ''; position: absolute; left: 50%; bottom: 10px; width: 140px; height: 8px;
                         margin-left: -70px; border-radius: 5px; background: rgba(43,37,30,.42); z-index: 2; }
      .br-phone .br-winbar { padding: 50px 18px 12px; gap: 10px; background: ${C.paper2}; }
      .br-phone .br-winbar i { display: none; }   /* 手机上没有浏览器窗口控制圆点 */
      .br-phone .br-url { font-size: 30px; margin-left: 6px; }
      .br-phone .br-search { margin: 14px 18px 0; height: 64px; padding: 0 14px; border-width: 3px; }
      .br-phone .br-caret { width: 5px; height: 32px; }
      .br-phone .br-q { font-size: 24px; white-space: nowrap; }
      .br-phone .br-grid { grid-template-columns: repeat(2, 1fr); gap: 10px; padding: 14px 18px 0; }
      .br-phone .br-tile { height: 74px; }
      .br-winbar { display: flex; align-items: center; gap: 14px; padding: 14px 20px; background: ${C.paper2}; }
      .br-winbar i { width: 18px; height: 18px; border-radius: 50%; background: ${C.paper3}; display: block; }
      .br-url { font-family: ${F.tech}; font-size: 30px; color: ${C.ink}; margin-left: 12px; letter-spacing: .04em; }
      .br-search { margin: 16px 20px 0; height: 76px; background: #fff; border: 4px solid ${C.ink}; display: flex; align-items: center; padding: 0 20px; gap: 10px; }
      .br-caret { width: 6px; height: 40px; background: ${C.red}; display: block; }
      .br-q { font-family: ${F.tech}; font-size: 36px; color: ${C.ink}; }
      .br-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; padding: 18px 20px 0; }
      .br-tile { height: 88px; background: ${C.paper3}; }
      .br-tile:nth-child(1) { background: #cdd8dc; } .br-tile:nth-child(2) { background: #e2d3bb; }
      .br-tile:nth-child(3) { background: #cfd9c6; } .br-tile:nth-child(4) { background: #e6cfc4; }
      .br-tile:nth-child(5) { background: #d3cee0; } .br-tile:nth-child(6) { background: #d6dee6; }
      .br-terms { display: flex; flex-direction: column; gap: 14px; }
      .br-term { background: ${C.ink2}; border-left: 10px solid ${C.gold}; padding: 16px 20px;
                 font-family: ${F.base}; font-size: 44px; color: ${C.paper}; white-space: nowrap; }

      /* b2 对应表 */
      .br-tbl { display: flex; flex-direction: column; gap: 16px; }
      .br-row { display: flex; align-items: center; gap: 20px; background: ${C.ink2}; padding: 20px 24px; border-left: 10px solid ${C.gold}; }
      .br-no { font-family: ${F.num}; font-size: 40px; color: ${C.red}; width: 74px; }
      .br-script { font-family: ${F.base}; font-size: 50px; color: ${C.paper}; flex: 1; }
      .br-link { font-family: ${F.tech}; font-size: 40px; color: ${C.gold}; }
      .br-file { font-family: ${F.tech}; font-size: 42px; color: ${C.gold}; width: 380px; text-align: right; }

      /* b3 三档 */
      .br-grades { display: flex; flex-direction: column; gap: 20px; }
      .br-grade { display: flex; align-items: center; gap: 22px; background: ${C.paper2}; padding: 24px 26px; }
      .br-grade.ok { background: ${C.paper}; border-left: 14px solid ${C.red}; }
      .br-mark { font-family: ${F.techH}; font-size: 52px; color: ${C.ink}; width: 56px; text-align: center; }
      .br-grade.ok .br-mark { color: ${C.plateRed}; }
      .br-gtext { font-family: ${F.base}; font-size: 52px; color: ${C.ink}; flex: 1; }
      .br-chip { font-family: ${F.tech}; font-size: 34px; color: ${C.paper}; background: ${C.ink2}; padding: 8px 20px; }

      /* b4 两栏（内容底边 ≤1070；两栏卡本身较矮，靠内容带垂直居中 + 加大内边距撑满观感） */
      .br-cols { display: flex; gap: 20px; align-items: flex-start; }
      .br-col { flex: 1; background: ${C.paper}; padding: 34px 30px 42px; }
      .br-col.right { background: ${C.paper2}; }
      .br-ch { font-family: ${F.heavy}; font-size: 74px; color: ${C.ink}; border-bottom: 6px solid ${C.plateRed}; padding-bottom: 14px; }
      .br-li { font-family: ${F.base}; font-size: 54px; color: ${C.ink}; padding: 22px 0 0; }

      /* b5 格式 */
      .br-spec { display: flex; flex-direction: column; gap: 18px; }
      .br-srow { display: flex; align-items: center; gap: 26px; background: ${C.ink2}; padding: 26px 28px; border-left: 10px solid ${C.gold}; }
      .br-big { font-family: ${F.num}; font-size: 62px; color: ${C.gold}; width: 220px; }
      .br-smain { font-family: ${F.heavy}; font-size: 58px; color: ${C.paper}; flex: 1; }
      .br-snote { font-family: ${F.base}; font-size: 42px; color: ${C.paper3}; }

      /* b6 磁盘 */
      .br-path { font-family: ${F.tech}; font-size: 62px; color: ${C.gold}; background: ${C.ink2}; padding: 24px 30px;
                 border-left: 12px solid ${C.red}; margin-bottom: 34px; }
      .br-disks { display: flex; flex-direction: column; gap: 30px; }
      .br-disk { display: flex; align-items: center; gap: 24px; }
      .br-dname { font-family: ${F.num}; font-size: 52px; color: ${C.paper}; width: 90px; }
      .br-bar { flex: 1; height: 62px; background: ${C.ink2}; border: 4px solid ${C.paper3}; display: block; overflow: hidden; }
      .br-fill { display: block; height: 100%; transform-origin: 0 50%;
                 background: repeating-linear-gradient(45deg, #4d8296 0 14px, ${C.teal} 14px 28px); }
      .br-fill.bad { background: repeating-linear-gradient(45deg, #d8543d 0 14px, #b8351f 14px 28px); }
      .br-dlabel { font-family: ${F.heavy}; font-size: 46px; color: ${C.teal}; width: 300px; }
      .br-dlabel.bad { color: #e2705a; }

      /* b7 文件夹树 */
      .br-tree { background: ${C.ink2}; padding: 32px 34px; }
      .br-node { display: flex; align-items: center; gap: 18px; padding: 16px 0; }
      .br-ticon { font-family: ${F.num}; font-size: 36px; color: ${C.gold}; width: 30px; }
      .br-tname { font-family: ${F.tech}; font-size: 46px; color: ${C.paper}; }
      .br-tnote { font-family: ${F.base}; font-size: 38px; color: ${C.paper3}; margin-left: auto; }
      .br-d0 { border-bottom: 4px solid ${C.paper3}; }
      .br-d1 { padding-left: 34px; } .br-d2 { padding-left: 72px; }
      .br-d2 .br-tname { color: ${C.cream}; }

      /* b8 管道（横向三段，竖高 ≈247 → 660–907） */
      .br-pipe { display: flex; flex-direction: row; align-items: stretch; gap: 10px; }
      .br-step { display: flex; flex-direction: column; justify-content: center; gap: 10px;
                 flex: 1 1 0; min-width: 0; background: ${C.paper}; padding: 22px 18px; }
      .br-sno { font-family: ${F.num}; font-size: 34px; color: ${C.plateRed}; }
      .br-stext { font-family: ${F.heavy}; font-size: 40px; color: ${C.ink}; line-height: 1.18; }
      .br-ssub { font-family: ${F.base}; font-size: 30px; color: #6b6152; line-height: 1.2; }
      .br-sarrow { flex: 0 0 34px; display: flex; align-items: center; justify-content: center;
                   font-family: ${F.num}; font-size: 38px; color: ${C.gold}; }
`;

const html = `<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <title>陆总口播 · 自动找 B-roll 的 skill（参考片排版系统 + vox 拼贴 b-roll）</title>
    <style>
${FACE}${CSS}    </style>
  </head>
  <body>
    <div id="stage" data-composition-id="broll-skill-recut" data-start="0" data-duration="${DUR}" data-fps="${FPS}" data-width="${W}" data-height="${H}">
      <!-- Layer 1：原视频全屏（不再深底接管；b-roll 段才推近并缩进圆形 PIP） -->
      <div id="video-wrap">
        <video id="bg-video" src="input-video.mp4" muted playsinline data-start="0" data-duration="${DUR}" data-track-index="1"></video>
      </div>
      <audio id="source-audio" src="input-video.mp4" data-start="0" data-duration="${DUR}" data-track-index="10" data-volume="1"></audio>
      <!-- BGM：Chill HipHop Background 04 / NORDICREC（剪映曲库，用户指定）。已预做片头 1s 淡入、
           片尾 3.7s 淡出并裁到片长；0.12 垫底 ≈ 人声下 -18dB，不抢口播。
           ⚠ 本机 PATH 上的旧 ffmpeg libmp3lame 是坏的（mp3 编码全静音），故用 WAV。
           ⚠ 成片音轨不走渲染器（多 <audio> 元素会被丢，见 build-audio-mix.js 头部注释），
             此元素仅供 Serve/浏览器预览。 -->
      <audio id="bgm" src="bgm.wav" data-start="0" data-duration="${DUR}" data-track-index="20" data-volume="0.12"></audio>

      <!-- Layer 2：vox 纸拼贴 b-roll（整屏版面，圆形 PIP 透出原视频） -->
${P.BROLL_PLAN.map(brollHTML).join('\n')}

      <!-- Layer 3：章节标题（斜切底板 + 金编号 + 红斜杠 + 奶油副说明） -->
${titleClips.join('\n')}

      <!-- Layer 4：排版动效组合（左右式 / 上下式 / 先后式） -->
${comboClips.join('\n')}

      <!-- Layer 5：基础字幕（居中 y=0.600，白字无描边，重点词金色 + 1.12 倍） -->
${capClips.join('\n')}

      <!-- Layer 6：语义音效（只落重点节点） -->
${sfxClips}

      <script src="vendor/gsap.min.js"></script>
      <script>
        (function () {
          var tl = window.gsap.timeline({ paused: true });
${EASE_SRC}
          // ── 字幕入场 + 重点词重音卡点 ──
${capTweens.join('\n')}

          // ── 章节标题 ──
${titleTweens.join('\n')}

          // ── 排版组合 ──
${comboTweenList.join('\n')}

          // ── b-roll 拼贴 ──
${P.BROLL_PLAN.map(brollTweens).flat().join('\n')}

          // ── 画面推近 / 缩进圆形 PIP ──
          tl.set('#video-wrap', { scale: ${PUSH.from}, x: 0, y: 0 }, 0);   // 稳定基准：任何时刻 seek 都不会停在上一段的取景上
${videoTweens.join('\n')}

          window.__timelines = window.__timelines || {};
          window.__timelines["broll-skill-recut"] = tl;
        })();
      </script>
    </body>
</html>
`;

fs.mkdirSync(path.join(PUB, 'cards'), { recursive: true });
fs.writeFileSync(path.join(PUB, 'index.html'), html, 'utf8');

const comboStats = COMBOS.reduce((a, c) => { a[c.type] = (a[c.type] || 0) + 1; return a; }, {});
console.log('字幕:', capClips.length, '(编组内', cues.filter((u) => u.kind === 'layout' && comboGroupIds.has(u.groupId) && !DOWN.has(u.groupId)).length, '条改由组合层渲染)');
console.log('章节标题:', titleClips.length, '| 排版组合:', comboClips.length, JSON.stringify(comboStats));
console.log('b-roll 版面:', P.BROLL_PLAN.length, '| 音效:', sfxPlan.length, '| 推近关键帧:', videoTweens.length);
console.log('音效构成:', JSON.stringify(sfxStats));
console.log('缓动 tween 合计:', capTweens.length + titleTweens.length + comboTweenList.length + P.BROLL_PLAN.map(brollTweens).flat().length + videoTweens.length);
