// plan.js — 章节标题 / 排版动效组合 / vox 拼贴 b-roll / 画面推近 / 语义音效 的规划数据
//
// 说明：参考片与本次素材是**同一条源视频**（SRT sha256 一致），因此章节时间点、
// 排版组合的落点、画面推近窗口都可直接沿用参考片的判断，只把视觉实现换成可渲染的
// HyperFrames 版本，并按用户反馈修正（动效加缓动、标题下移避开裁切、人不再被半挡）。
const { COMBO } = require('./theme.js');

// ---------------------------------------------------------------- 1. 章节标题
// 每个章节都在「口播念到该步骤的那一刻」才开始，绝不预铺后续步骤
// （用户反馈：第一步还没说就提前出现 → 已修正）
const SECTIONS = [
  {
    id: 's0', t0: 0.04, t1: 12.90, kind: 'open',
    line1: [
      { t: '如何从', role: 'base', size: 15, color: 'white' },
      { t: '0–1', role: 'heavy', size: 30, color: 'gold' },
      { t: '手搓一个', role: 'base', size: 15, color: 'white' },
    ],
    line2: { t: '自动找 B-roll 的 Skill', role: 'heavy', size: 18, color: 'white' },
  },
  { id: 's1', t0: 13.18, t1: 19.90, num: '1.', main: '逐句分析', sub: '哪些需要 · 哪些不需要' },
  { id: 's2', t0: 20.12, t1: 29.86, num: '2.', main: '判断类型', sub: '人物 / 场景 / 情绪 / 概念' },
  { id: 's3', t0: 30.02, t1: 40.40, num: '3.', main: '搜索素材', sub: '把素材网站告诉 AI' },
  // s4/s5 不再是「序号 + 句点」：`＋.` / `!.` 里的句点会紧贴后面的红色分隔斜杠，看起来像
  // 「. 与 / 重叠」（用户指出）。这两节不是 1-2-3 的序号而是**旁注型小标题**，改用英文标识
  // TIPS / RULES 以金线徽标呈现，并把分隔斜杠去掉（英文标识与标题之间不需要「/」）。
  { id: 's4', t0: 51.06, t1: 58.10, num: 'TIPS', main: '筛选标准', sub: '让素材符合你的审美' },
  { id: 's5', t0: 74.38, t1: 83.44, num: 'RULES', main: '下载规则', sub: '先确认 · 再下载 · 统一管理' },
];

// ---------------------------------------------------------------- 2. 排版动效组合
// 编组由 build-subtitles.js 按「句意密不可分」产出；这里给每组选一个式样并写下语意理由。
// 式样定义来自用户口述（见 theme.js COMBO 的注释）：
//   up_down    上下式：前句在基础字幕位置，后句落在其**下方**，两句同屏共存
//   front_back 前后式：后半句**覆盖**前句同位置，前句透明度关键帧淡出；后半句缩放 1.20× + 金色
//   left_right 左右式：同样是上下结构，后半句**向右展开**时前半句**向左位移**（点位同步）
// prefer 的排序原则：后半句如果是「重点内容 / 结论 / 指令」→ 覆盖式；两句是「对照 / 并置 / 让位」→ 左右式；
// 只是「补充 / 递进」→ 上下式。
const COMBO_PLAN = [
  { group: 'g001', t0: 1.25,   prefer: ['up_down', 'front_back'],    note: '设问递进，后句落在下方' },
  { group: 'g003', t0: 16.09,  prefer: ['up_down', 'front_back'],    note: '动词与宾语密不可分，上下相承' },
  { group: 'g004', t0: 33.49,  prefer: ['front_back', 'up_down'],    note: '前半句只是铺垫，Pexels 才是重点 → 覆盖式' },
  { group: 'g006', t0: 51.07,  prefer: ['front_back', 'up_down'],    note: '「细节特别的重要」是重点 → 覆盖式' },
  { group: 'g007', t0: 53.49,  prefer: ['left_right', 'front_back'], note: '反例对照：找到的素材 ↔ 我不满意，左右展开' },
  { group: 'g008', t0: 64.27,  prefer: ['left_right', 'front_back'], note: '两句并置对照，左右拉开' },
  { group: 'g009', t0: 74.39,  prefer: ['front_back', 'up_down'],    note: '「一定要提前告诉 AI」是重点指令 → 覆盖式' },
  { group: 'g010', t0: 79.15,  prefer: ['up_down', 'front_back'],    note: '场合与动作，上下相承' },
  { group: 'g011', t0: 94.02,  prefer: ['up_down', 'front_back'],    note: '设问递进' },
  { group: 'g012', t0: 112.46, prefer: ['up_down', 'left_right'],    note: '旧流程陈述，上下相承' },
  { group: 'g013', t0: 128.99, prefer: ['left_right', 'front_back'], note: '半句换行接「剪辑经验」，左右展开（用户指定此式样正确）' },
  { group: 'g014', t0: 133.55, prefer: ['left_right', 'front_back'], note: '规则与归置，左右展开（用户指定此式样正确）' },
  { group: 'g015', t0: 141.61, prefer: ['front_back', 'up_down'],    note: '全片论点，三句累积后末句覆盖落定' },
  { group: 'g016', t0: 152.39, prefer: ['up_down', 'front_back'],    note: '过程与呈现，上下相承' },
  { group: 'g017', t0: 157.91, prefer: ['up_down', 'front_back'],    note: '收尾互动，上下相承' },
];
// 降级的编组：密度约束下（任意连续 60 秒内同式样 ≤2 组）0–60 秒区间会挤进 7 组而无解，
// 这两组的后半句本身语义完整、单独成行也读得通，退回基础字幕层。
const COMBO_DOWNGRADE = ['g002', 'g005'];

// 「任意连续 60 秒内同类型 ≤2 组」——回溯求解，偏好度决定优先顺序
function assignComboTypes(plan) {
  const items = plan.map((p) => ({ ...p, type: null }));
  const violates = (list) => {
    for (let i = 0; i < list.length; i++) {
      if (!list[i].type) continue;   // 未赋值项不参与计数（否则 null 会被当成同一类型）
      let n = 0;
      for (let j = 0; j < list.length; j++) {
        if (!list[j].type || list[i].type !== list[j].type) continue;
        const dt = list[j].t0 - list[i].t0;
        if (dt >= -1e-6 && dt < COMBO.windowSec) n++;
      }
      if (n > COMBO.maxPerWindow) return true;
    }
    return false;
  };
  const solve = (i) => {
    if (i >= items.length) return true;
    // 先按内容偏好试，偏好都不行再退回其余式样（保证有解）
    const order = [...items[i].prefer, ...COMBO.types.filter((t) => !items[i].prefer.includes(t))];
    for (const t of order) {
      const prev = items[i].type;
      items[i].type = t;
      if (!violates(items) && solve(i + 1)) return true;
      items[i].type = prev;
    }
    items[i].type = null;
    return false;
  };
  if (!solve(0)) throw new Error('排版组合式样分配失败：密度约束无解');
  return items;
}

// ---------------------------------------------------------------- 3. vox 拼贴 b-roll
// 判据（用户 SOP）：口播本身讲得清的不加；需要视觉补充说明的才加。
// 每个片段都是**整屏**拼贴，绝不半挡人物；需要保留人物时用圆形 PIP 透出原视频。
// ---------------------------------------------------------------- 3. b-roll 版面
// 「不要一直都是圆窗」——按**画面匹配度 + 文字内核**给每个版面选形态（用户给的 11 条多元化
// 口播包装参考片里的做法，取其中贴合本片文案的几种，不照搬）：
//   pip:true  → 人像进圆窗；pip:false → 该段以版面为主体、人像不出镜
//   chrome    → 外壳（'phone' 手机样机：讲网站/工具界面时才用）
//   frame     → 取景框 + REC 角标（讲「逐条核对镜头」这类拍摄/审片语义时才用）
//   exit      → 出场方式，逐版面轮换，相邻不同款（用户：「每次都是展开放大也有点奇怪」）
// 分配与理由：
//   b1 Pexels 素材网站 → **手机样机**（讲网站，装进手机最贴）+ slide-left
//   b2 素材↔文案 对应表 → **取景框**（逐条核对镜头）+ slide-up
//   b3 筛选标准三档 → 圆窗（用户已认可的式样）+ iris
//   b4 剪辑逻辑 / 审美标准 → **人像不出镜**（两栏卡面本身就是主体，再叠圆窗是冗余）+ slide-down
//   b5 格式与画质 → 整屏 + slide-right
//   b6 下载路径 / 磁盘 → 整屏 + slide-up
//   b7 文件夹树 → 整屏 + iris
//   b8 经验→规则管道 → 圆窗（收尾呼应）+ slide-left
const BROLL_PLAN = [
  {
    id: 'b1', t0: 41.0, t1: 45.2, pip: true, title: '去素材网站找',
    kind: 'search', site: 'pexels.com', chrome: 'phone', exit: 'iris',
    terms: ['人物 · 动作', '情绪特写', '概念画面', '场景 · 空镜'],
    note: 'AI 按需求自己去搜',
  },
  {
    id: 'b2', t0: 46.3, t1: 50.6, pip: false, title: '自动整理：素材 ↔ 文案',
    kind: 'mapping', frame: true, exit: 'slide-up',
    rows: [
      ['01', '打开电脑先看一眼', 'smile-desk.mp4'],
      ['02', '把文案丢给 AI', 'typing-ai.mp4'],
      ['03', '它会去找素材', 'search-web.mp4'],
      ['04', '统一存到 D 盘', 'folder-d.mp4'],
    ],
    note: '这个素材，对应哪一句文案',
  },
  {
    id: 'b3', t0: 58.6, t1: 63.3, pip: true, title: '筛选标准',
    kind: 'grades', exit: 'fade',
    // 用户第六轮指定：口播讲到「我会直接跟他说这句话」(61.74–63.44) 时，
    // 在字幕下方弹出真实聊天对话框截图（圆角矩形蒙版、弹簧入场），
    // 随版面 fade 退场一起溶解回全屏口播。at = 入场起点（领先说话 0.2s）。
    chat: { at: 61.55 },
    items: [
      { k: '✕', t: '能看清人但构图歪', s: '放弃' },
      { k: '△', t: '画质够但与文案不搭', s: '备选' },
      { k: '✓', t: '情绪对 · 构图稳 · 画质足', s: '采用' },
    ],
    note: '不是找素材，是照你的标准选',
  },
  {
    id: 'b4', t0: 68.0, t1: 73.5, pip: false, title: '',
    kind: 'two-col', exit: 'slide-down',
    left: { h: '剪辑逻辑', l: ['哪个镜头该停', '哪里该换景', '节奏怎么给'] },
    right: { h: '审美标准', l: ['色调对不对', '画面干不干净', '情绪到不到位'] },
    note: '重新选择，而不是随机抓取',
  },
  {
    id: 'b5', t0: 84.0, t1: 91.0, pip: false, title: '格式与画质',
    kind: 'spec', exit: 'slide-right',
    rows: [
      ['MP4', '只收 MP4', '.mov 一律不要'],
      ['4K', '4K 优先', '1080p 只在无 4K 时用'],
      ['16:9', '横屏原片', '竖屏裁切会丢画质'],
    ],
    note: '规则写死在 skill 里，每次都一样',
  },
  {
    id: 'b6', t0: 96.6, t1: 103.4, pip: false, title: '下载路径',
    kind: 'disk', exit: 'slide-left',
    path: 'D:\\素材\\b-roll\\',
    disks: [
      { n: 'C:', used: 0.92, label: '系统盘 · 爆满', bad: true },
      { n: 'D:', used: 0.18, label: '素材盘 · 清爽', bad: false },
    ],
    note: '路径提前固定，不然越攒越乱',
  },
  {
    id: 'b7', t0: 105.6, t1: 111.4, pip: false, title: '不管多少 B-roll 都放得下',
    kind: 'tree', exit: 'slide-up',
    tree: [
      { d: 0, t: 'b-roll/', n: '' },
      { d: 1, t: '2026-09-30/', n: '按日期' },
      { d: 2, t: '01_打开电脑.mp4', n: '按文案顺序编号' },
      { d: 2, t: '02_丢给AI.mp4', n: '' },
      { d: 2, t: '03_找素材.mp4', n: '' },
      { d: 1, t: '_未采用/', n: '审核掉的单独放' },
    ],
    note: '命名即顺序，拖进时间线不用再找',
  },
  {
    id: 'b8', t0: 146.2, t1: 151.8, pip: true, title: '',
    kind: 'pipeline', exit: 'iris',
    steps: [
      { t: '你的剪辑经验', s: '口播里怎么说' },
      { t: '写成判断规则', s: '什么该要 / 什么该扔' },
      { t: 'AI 可执行', s: '每次自动照做' },
    ],
    note: '不是让 AI 替你剪',
  },
];

// ---------------------------------------------------------------- 4. 画面推近（talking-head 段落，克制使用）
const PUSH_PLAN = [
  { t0: 0.8, t1: 4.4, to: 1.06 },
  { t0: 21.0, t1: 29.0, to: 1.08 },
  { t0: 118.2, t1: 124.6, to: 1.06 },
];

// ---------------------------------------------------------------- 5. 语义音效
// 依据：用户提供的《动画音效搭配逻辑》脑图（12 类动效 → 音效词，见 theme.js SFX_ROLE）。
// **不是**按固定间隔撒点：有动效才有音，动效是什么就用什么音。
//
//   位移(上下左右) → 嗖/呼/唰/落地 | 缩放(放大缩小) → 嘭/咚/闪光 | 模糊 → 魔法/悬疑轻敲
//   折叠开屏收拢   → 纸张/纸张抖动/折扇 | 滚动类 → 钱/齿轮 | 波纹(晕开吸入) → 水滴
//   翻转翻动 → 抖动/啵 | 弹簧 → 咚咚 | 跃入 → 综艺系统提示音 | 字幕歪到正 → 收音机
//   渐隐 → 水滴 | 生长 → 木质铃铛
//
// 四类事件源：
//   A 章节标题  开场主旨铺开 → move-deep(嗖)；章节标题条上滑 → move-fast(唰)
//   B 排版组合  上下式后半句落定 → land(落地)；前后式后半句放大覆盖 → zoom-in(嘭)；
//               左右式后半句向右展开 / 前半句向左让位 → move-fast(唰)
//   C b-roll    圆形 PIP：圆窗收拢 → zoom-out(咚) · 圆环晕开 → ripple(水滴)
//               整屏跃入 → jump-in(综艺系统提示音)
//               内容：逐行/逐格滚出 → gear(齿轮) · 条状生长 → grow(木质铃铛) · 卡片铺开 → paper(纸张)
//               长版面退场 → fade(水滴)
//   D 内容重音  重点词里真正扛论点的几处 → flash(闪光)
//
// 密度控制（SOP：不要过于频繁、只挑重点）：同一时刻只留一个音（优先级高者胜），
// 全局最小间隔 SFX_MIN_GAP，过密的低优先级事件被丢弃。
const SFX_MIN_GAP = 0.45;
// 全片真正扛论点的重音（时间 = 该重点词的**说话起点**，不是整句起点）
// 第六轮按参考片《B-roll教学_舒展排版》开头的搭配逻辑扩充：
// 金色重点词落定时给一记闪光音（密度仍由 SFX_MIN_GAP 把关，撞车的低优先级事件让路）。
const SFX_CONTENT_ACCENTS = [
  { at: 8.14,   kw: 'AI',       note: '主旨转折：现在直接让 AI 帮你' },
  { at: 12.26,  kw: 'B-roll',   note: '点题：自动找 B-roll 的 skill' },
  { at: 15.89,  kw: 'AI',       note: '动作揭示：直接丢给 AI' },
  { at: 35.04,  kw: 'Pexels',   note: '素材网站点名' },
  { at: 59.91,  kw: 'b-roll',   note: '筛选标准主语落定' },
  { at: 77.02,  kw: 'AI',       note: '规则前置：一定要提前告诉 AI' },
  { at: 82.13,  kw: 'MP4',      note: '格式规则落点' },
  { at: 88.02,  kw: '4K',       note: '画质规则落点' },
  { at: 119.99, kw: 'AI',       note: '旧流程 → 丢文案给 AI 的转折揭示' },
  { at: 149.08, kw: 'AI',       note: '全片论点：AI 可执行的规则' },
  { at: 157.49, kw: 'b-roll',   note: '收尾互动：评论区打出 b-roll' },
];

function buildSfxPlan(cues) {
  const ev = [];
  const push = (at, key, why, prio) => {
    if (at == null || Number.isNaN(at)) return;
    ev.push({ at: Math.max(0, Math.round(at * 1000) / 1000), key, why, prio });
  };

  // ── A 章节标题
  for (const s of SECTIONS) {
    if (s.kind === 'open') push(s.t0 + 0.02, 'move-deep', '开场主旨铺开（整层推入）', 6);
    else push(s.t0 + 0.04, 'move-fast', `${s.id} 标题条上滑进入`, 6);
  }

  // ── B 排版组合（式样由 assignComboTypes 决定，音效随之变化）
  for (const c of assignComboTypes(COMBO_PLAN)) {
    const parts = cues
      .filter((u) => u.groupId === c.group && u.kind === 'layout')
      .sort((a, b) => a.startTime - b.startTime);
    if (!parts.length) continue;
    const last = parts[parts.length - 1];
    const label = parts.map((u) => u.text).join(' / ');
    // 前半句入场给一记轻响（参考片逻辑：每一行字幕入场都有声音，重的那记留给落定）
    push(parts[0].startTime + 0.02, 'confirm', `${c.group} 前半句入场（轻响）`, 4);
    if (c.type === 'up_down') {
      push(last.startTime, 'land', `${c.group} 上下式：后句落定到前句下方（${label}）`, 8);
    } else if (c.type === 'front_back') {
      push(last.startTime - 0.06, 'zoom-in', `${c.group} 前后式：后句放大覆盖前句（${label}）`, 8);
    } else {
      push(last.startTime - 0.06, 'move-fast', `${c.group} 左右式：后句向右展开 · 前句向左让位（${label}）`, 8);
    }
  }

  // ── C b-roll 版面
  for (const b of BROLL_PLAN) {
    if (b.pip) {
      push(b.t0 - 0.32, 'zoom-out', `${b.id} 圆窗收拢到人脸上（缩放→咚）`, 9);
      // 圆环 scale 1.30→1 在 t0+0.18 落定 —— 水滴落在环收拢完成的那一刻，间隔 0.48s 不与入场挤
      push(b.t0 + 0.16, 'ripple', `${b.id} 圆环晕开落定（波纹→水滴）`, 5);
    } else {
      push(b.t0 - 0.04, 'jump-in', `${b.id} 整屏拼贴跃入（跃入→综艺系统提示音）`, 10);
    }
    // 内容音一律落在入场音之后（有圆形 PIP 的版面入场音更多，故整体后移），
    // 保证相邻音效间隔 ≥ SFX_MIN_GAP，且都还落在元素真正动起来的窗口里。
    const cAt = b.t0 + (b.pip ? 0.88 : 0.55);
    if (b.kind === 'search' || b.kind === 'mapping' || b.kind === 'tree') {
      push(cAt, 'gear', `${b.id} 条目逐行滚出（滚动→齿轮）`, 5);
    }
    if (b.kind === 'disk') push(cAt, 'grow', `${b.id} 占用条横向生长（生长→木质铃铛）`, 5);
    // 折叠 / 开屏 / 收拢 三兄弟按展开方式分别配：三档并开=折扇、两栏铺纸=纸张、三段连抖=纸张抖动
    if (b.kind === 'grades') push(cAt, 'fan', `${b.id} 三档卡片折扇式展开（折叠→折扇展开）`, 5);
    if (b.kind === 'two-col') push(cAt, 'paper', `${b.id} 左右两栏铺纸（折叠→纸张）`, 5);
    if (b.kind === 'pipeline') push(cAt, 'paper-shake', `${b.id} 三段管道连续抖出（折叠→纸张抖动）`, 5);
    if (b.frame) push(cAt + 0.48, 'snap-upright', `${b.id} 取景框咔一下对上（字幕歪到正→收音机声）`, 4);
    // 对话框插图（b3）：先敲键盘（输入语义）再弹簧弹出（弹簧→咚咚）。
    // 两音间隔必须 ≥ SFX_MIN_GAP，否则密度控制会把弹簧音丢掉。
    if (b.chat) {
      push(b.chat.at - 0.55, 'text', `${b.id} 对话框：打字输入（键盘声）`, 6);
      push(b.chat.at + 0.04, 'spring', `${b.id} 对话框弹簧弹出（弹簧→咚咚）`, 6);
    }
    // 退场音按**该版面的出场方式**配（出场方式逐版面轮换，见 BROLL_PLAN[].exit）：
    //   iris      光圈原地胀满  → 放大类 → 嘭
    //   fade      蒙版淡出交叉溶解 → 渐隐 → 水滴
    //   slide 纵  暗层上下擦出  → 快速位移 → 嗖
    //   slide 横  暗层左右擦出  → 位移 → 呼
    const ex = b.exit || 'iris';
    const exB = ex === 'iris' ? 0.34 : ex === 'fade' ? 0.30 : 0.54;
    const exAt = Math.max(0, b.t1 - exB - 0.05);          // = exitTiming().te2
    if (ex === 'iris') push(exAt, 'zoom-in', `${b.id} 光圈胀满收场（放大→嘭）`, 6);
    else if (ex === 'fade') push(exAt, 'fade', `${b.id} 蒙版淡出交叉溶解（渐隐→水滴）`, 6);
    else if (ex === 'slide-left' || ex === 'slide-right') push(exAt, 'move', `${b.id} 暗层横向擦出（位移→呼）`, 6);
    else push(exAt, 'move-fast', `${b.id} 暗层纵向擦出（位移→嗖）`, 6);
  }

  // ── D 内容重音
  for (const a of SFX_CONTENT_ACCENTS) {
    push(a.at, 'flash', `重音「${a.kw}」：${a.note}（缩放峰值→闪光）`, 7);
  }

  // 密度控制：先按优先级挑，再按时间排序
  ev.sort((a, b) => b.prio - a.prio || a.at - b.at);
  const kept = [];
  for (const e of ev) {
    if (kept.some((k) => Math.abs(k.at - e.at) < SFX_MIN_GAP)) continue;
    kept.push(e);
  }
  kept.sort((a, b) => a.at - b.at);
  return kept;
}

// ---------------------------------------------------------------- 6. 重点词强调（行内，不换行）
// 参考片写法：{\c&H82CCFF&\fs80.64}最爽{\c&HFFFFFF&\fs72} —— 同色位 + 1.12 倍，
// 由 build-subtitles.js 的 emphasisSpans 提供字级时间，用于把放大卡在说话重音上。
const EMPHASIS_LEAD = 0.10; // 提前量上限（秒），出点正好落在强调音节

module.exports = { SECTIONS, COMBO_PLAN, COMBO_DOWNGRADE, assignComboTypes, BROLL_PLAN, PUSH_PLAN, SFX_MIN_GAP, SFX_CONTENT_ACCENTS, buildSfxPlan, EMPHASIS_LEAD };
