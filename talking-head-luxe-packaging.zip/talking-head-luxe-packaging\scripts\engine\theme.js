// theme.js — 设计令牌（参照用户提供的《字幕效果预览》参考片，数值为实测）
//
// 参考片 = 同一条源素材（SRT sha256 一致）的包装版，因此以下数值可直接沿用：
//   · 基础字幕  居中 x=0.500 / y=0.600，字号 12（1080×1920 下 72px），白字无描边，阴影 60%/模糊 10
//   · 标题底板  斜切平行四边形 ±34px/297px 高，宽 868px，深色 #1C1716 @74.5% + 红边 #AF422E @96%
//   · 配色      金 #FFCC82 / 红 #D15C47 / 奶油 #EDDEC7 / 白 #FFFFFF
//   · 缓动      cubic-bezier(0.42, 0, 0.58, 1)（参考工程关键帧 curveType=Bezier，控制点 0.42/0 / 0.58/1）
//   · 时长      入场动画 0.18s；排版组合位移 0.24s；画面推近 ≈3.8s
//
// 被 build-composition.js / build-caption-review.js 共用，保证「审阅看到的 = 成片渲染的」。
const TM = require('./type-metrics.js');   // 真实字宽度量（排版落位靠它算可用位移量）

const W = 1080, H = 1920, FPS = 50, DUR = 160.277;

// 参考片的字号单位换算：设计稿 size 15 → ASS \fs90，即 1 单位 = 6px（1080×1920 画布）
const U = 6;
const px = (size) => Math.round(size * U);

// ---- 调色（实测参考片色值）----
const C = {
  gold: '#FFCC82',      // 重点词 / 大编号（参考 [1.00,0.80,0.51]）
  red: '#D15C47',       // 红斜杠 / 强调线（参考 [0.82,0.36,0.28]）
  redSlash: '#DE6A55',  // 标题红斜杠专用：在 74.5% 深底板上 #D15C47 对比度只有 2.84:1
                        // （WCAG AA 大字要求 3:1），提亮 4% 后为 3.2:1，肉眼无差别
  cream: '#EDDEC7',     // 副说明小字（参考 [0.93,0.87,0.78]）
  white: '#FFFFFF',
  plate: 'rgba(28,23,22,0.745)',    // 标题底板填充
  plateRed: 'rgba(175,66,46,0.96)', // 标题底板红边
  // vox 拼贴 b-roll 用（对应用户另一条参考片：深底 + 奶油纸双色地）
  ink: '#14110E',
  ink2: '#221D17',
  paper: '#EDE6D6',
  paper2: '#DFD5BE',
  paper3: '#C9BC9E',
  mark: '#E8A33D',      // 马克笔黄高亮条
  teal: '#35707F',
  muted: '#8C8474',
};

// ---- 字体角色（母版见 assets-src/fonts/，子集化见 subset-fonts.js，一键替换见 FONTS.md）----
const F = {
  base: '"JunYa"',        // 基础字幕 —— 造字工房俊雅体（用户指定）
  heavy: '"TitleHeavy"',  // 标题主字 / 重点花字 —— 思源粗宋（用户指定）
  thin: '"HuaGuang"',     // 细体装饰 / 红斜杠 —— 青鸟华光中长宋（用户指定）
  body: '"BodySong"',     // 正文/副说明 —— 思源宋体 Regular
  tech: '"XiTi"',         // 专业科普细体 —— 思源黑体7号（用户指定「细体」）
  techH: '"TeHei"',       // 专业科普粗体 —— 思源黑体1号（用户指定「特黑体」）
  yan: '"YanSong"',       // 备用宋 —— Aa研宋（用户指定「研宋体」）
  num: '"Inter"',         // 数字 / 拉丁
};

// ---- 基础字幕 ----
// ⚠ 字体度量实测（tools/fontmetrics.js）：造字工房俊雅体的 CJK 推进宽度是 **0.75 em**
//   （思源粗宋等常规中文字体是 1.00 em）—— 同样是「字号 12」，俊雅体渲染出来只有常规字体的
//   75% 宽，而且字与字天然贴得很近。这就是用户反馈「过于紧凑、不够舒展」的字体内因。
//   参考片基准（同一句 10 字实测）：ink 宽 769px（占画布 71%）、ink 高 67px、advance/ink高 = 1.16。
//   用俊雅体复现该基准 → 解 (6.75 + 9L)·F = 756（10 字占 70%）与 advance/ink高 ≈ 1.1：
//     F = 80px、letter-spacing L = 0.22em  →  10 字行 752px（69.6%），ink 高 72.5px
//   中西文间隙：参考片里「哪里该加 B-roll」中西文之间是留空的，而源 SRT 没有空格，
//   必须由排版补上，否则「叫做Pexels」会贴在一起。实现是把拉丁串包进 `.lt`
//   （letter-spacing:0 + margin-right:letterSpacing）—— 拉丁内部不撑字距、边界仍有间隔，
//   这样长英文行才不会超宽（早期给所有字都加 0.22em，导致「codex b-roll素材文件夹里」超宽 1066px）。
//   letter-spacing 会在最后一个字后多留一格、使居中视觉左偏 ls/2，用 margin-left 抵消。
const CAPTION = {
  centerX: 0.500,
  centerY: 0.600,             // 1152px：嘴巴(0.47)之下、平台标题区(0.86)之上
  sizeNormal: 80,             // 正文行（≤10 视觉字）
  sizeSmall: 78,              // 11–12 视觉字、句意完整 —— 只微缩 2.5%，保持整层一致性
  letterSpacing: 0.22,        // em；补偿俊雅体 0.75em 的窄推进
  lineHeight: 1.22,
  color: C.white,
  shadow: '0 3px 6px rgba(0,0,0,.60), 0 2px 14px rgba(0,0,0,.42)', // 60% / 模糊 10
  maxVisual: 12,              // 视觉宽度上限（拉丁按 0.5 计）
  safeInset: 44,              // 左右安全内边距，字幕 ink 不得越过
};
// 重点词强调：参考片内联写法 {\c&H82CCFF&\fs80.64} —— 同色位金色 + 1.12 倍放大
const EMPHASIS = { color: C.gold, scale: 1.12 };

// ---- 标题底板（实测 标题底板.png）----
// ⚠ 参考片实拍校准：ASS 里的 \fs 值是**设计规格**，参考片实拍（540×960 预览逐像素测量、
//   按已知不变的 868×297 底板对齐换算到 1080 空间）比规格小一档。逐元素实拍靶值：
//     大编号   规格 \fs216 → 实拍 ink 122×116  ✓ 156px 命中（我 122×121，比 1.00/1.04）
//     主标题   规格 \fs150 → 实拍 ink 408×96   → 102px（我 108px 时 434×103，仍大 6%）
//     副说明   规格 \fs63  → 实拍 ink 520×44   → 47px（我 45px 时 365×41，偏小）
//     开场小字 规格 \fs90  → 实拍 ink「如何从」204 /「手搓一个」278（均推得 73px）
//     开场大字 规格 \fs180 → 实拍 ink「0–1」160×98 → 124px
//     开场 line2 规格 \fs108 → 实拍 ink 760（我 108px 时 1130）→ 73px
//   基础字幕层与之相反：参考片「做IP口播剪辑的」\fs72 实拍 382px，同字体同字号渲染 389px（0.98）
//   → **基础字幕不缩放**，只校准标题/花字层。用户要求「参考我这个视频」，故以实拍为准。
//   校准后粗宋 em-box（1.44em）在 num↔main、开场 l1↔l2 之间仍会交叠，但 ink 均已有净空，
//   这两处声明为 data-layout-allow-overlap（见 build-composition.js）。
const PX = {
  num: 156, slash: 134, main: 102, sub: 47,          // 章节标题四件套（实拍靶值）
  openBase: 73, openHeavy: 124, openLine2: 73,       // 开场两段式主旨（实拍靶值）
};

const TITLE = {
  top: 138,                 // 实测 125，下移 13px 避开平台顶部状态栏裁切
  height: 297,
  width: 868,
  leftTop: 110,             // 顶边左端 x（底边 = 76）
  skewPx: -34,              // 高度区间内的左右位移 → 6.5°
  redBar: 11,
  // 四件套几何（x=中心，y=中心，取自参考片 ASS pos，位置不受字号缩放影响）
  num:   { x: 0.220, y: 0.150, size: PX.num },   // 大编号（粗宋/金）
  slash: { x: 0.335, y: 0.151, size: PX.slash }, // 红斜杠（华光中长宋/红）
  main:  { x: 0.595, y: 0.123, size: PX.main },  // 主标题（粗宋/白）
  sub:   { x: 0.610, y: 0.188, size: PX.sub },   // 副说明（底字/奶油）
  // 开场两段式主旨（flex 行排，gap 由实拍总跨度 778px 反解）
  open: { base: PX.openBase, heavy: PX.openHeavy, line2: PX.openLine2, gap: 46 },
};

// ---- 排版动效组合 ----
// 三种式样以**用户口述的定义**为准（此前我按参考片 ASS 反解出的「左右式=对角舒展」是错的，
// 用户明确纠正：「同样是上下的结构，在后半句向右展开出现的时候，让前半句向左位移」）：
//
//   上下式 up_down   前句出现在**基础字幕位置**（y=1152 居中），后句用位置关键帧出现在**前句的下方**
//                    —— 两句同屏共存，不影响空间感。两段同为白字同尺。
//   前后式 front_back 后半句**覆盖**在前句的字幕上（同一位置、同一 y），给前句打**透明度关键帧**淡出。
//                    后半句缩放 1.20× + 金色（教学视频面板实测「缩放 120%」），突出后句重点。
//   左右式 left_right 同样是上下的结构，利用位置关键帧做左右位移：后半句**向右展开**出现的**同时**
//                    前半句**向左位移**（关键帧点位同步）。后半句放大 + 金色。
//
// 两条硬约束（用户明确要求）：
//   ① 位移必须由**后半句的重点词**触发 —— 不能提前。所以位移 tween 的起点挂在后段的出现时刻上。
//   ② 绝不出画。每段的横向位置不再拍百分比，而是用 type-metrics.js 的**真实字宽**算出可用位移量，
//      并把 ink 夹在 safeInset 之内；宽度不够时自动降该段字号。
// 行距收紧到 1.30em，让两段读起来是一个整体（用户：「要稍微紧凑一些，不要过于分离」）。
const COMBO = {
  types: ['left_right', 'up_down', 'front_back'],
  windowSec: 60,
  maxPerWindow: 2,
  baseY: 0.600,             // 1152px —— 前句锚在基础字幕位置
  lineGapEm: 1.30,          // 行间距（× 段字号）
  letterSpacing: 0.02,      // em，花字轻微加距
  size: { left_right: 80, up_down: 84, front_back: 86 },   // 各段基准字号
  emphasisScale: 1.20,      // 后半句放大倍率（实测 120%）
  xShiftMax: 118,           // 左右式横向位移上限（避免「过于分离」）
  safeInset: 46,            // ink 安全内边距
  triggerLead: 0.06,        // 后半句重点词触发前句让位的提前量
  gapPx: { up_down: 56, front_back: 40, left_right: 0 },   // 入场位移
};

/**
 * 组合内每一段的落位。宽度来自真实字宽，位置夹在安全区内。
 * @returns {{y:number, tx:number, size:number, scale:number, w:number}[]}
 *   y    = 行中心（页面绝对 px）   tx = 相对画布中心的水平位移
 *   size = 该段自适应后的字号     scale = 该段放大倍率（仅末段 >1）
 */
function comboRows(type, parts, canvasW = 1080) {
  const list = parts.map((p) => (typeof p === 'string' ? { text: p } : p));
  const n = list.length;
  const baseY = COMBO.baseY * 1920;
  const F = COMBO.size[type] || 84;
  const inset = COMBO.safeInset;
  const avail = canvasW - inset * 2;
  const gap = Math.round(COMBO.lineGapEm * F);
  const scaleOf = (i) => (i === n - 1 && type !== 'up_down' ? COMBO.emphasisScale : 1);

  // ① 逐段自适应字号：在基准字号下量出真实宽度（含放大），超过可用宽度就等比降字号
  const fitted = list.map((p, i) => {
    const raw = TM.measure(p.text, { font: 'TitleHeavy', size: F, letterSpacing: COMBO.letterSpacing }).px;
    const need = raw * scaleOf(i);
    const k = need > avail ? avail / need : 1;
    const size = Math.max(48, Math.round(F * k));
    const w = TM.measure(p.text, { font: 'TitleHeavy', size, letterSpacing: COMBO.letterSpacing }).px * scaleOf(i);
    return { size, scale: scaleOf(i), w };
  });

  // ② 纵向：前句锚在基础字幕位置，后句落在下方
  const yOf = (i) => (type === 'front_back' ? baseY : baseY + i * gap);
  // ③ 横向：只有左右式做位移，且由后段触发（这里只算静态终态位置）。
  //    两段位移在**时间上同步**，幅度各自取「不越界的最大值」——教学视频里前半句向左的幅度
  //    本来就大于后半句向右的幅度（后半句往往是长句，向右空间有限），强行等幅反而会出画。
  const shiftL = fitted.length ? Math.max(0, Math.min(canvasW / 2 - inset - fitted[0].w / 2, COMBO.xShiftMax)) : 0;
  const shiftR = fitted.length
    ? Math.max(0, Math.min(canvasW - inset - canvasW / 2 - fitted[n - 1].w / 2, COMBO.xShiftMax)) : 0;
  const txOf = (i) => {
    if (type !== 'left_right') return 0;
    if (i === 0) return -shiftL;
    if (i === n - 1) return shiftR;
    return 0;
  };

  return fitted.map((f, i) => ({ y: yOf(i), tx: txOf(i), size: f.size, scale: f.scale, w: f.w, gap }));
}

// ---- 动效（参考工程关键帧：Bezier 0.42,0 / 0.58,1）----
const MOTION = {
  entr: 0.18,               // 渐显 / 向上滑动（剪映入场动画实测 180000µs）
  combo: 0.24,              // 排版组合位移窗口（参考 动态排版.json 实测）
  card: 0.30,               // b-roll 拼贴层入场
  exit: 0.14,
  lead: 0.10,               // 重点词/组合提前量上限（SOP：不能太多）
  // 两点之间留空间：入点与出点之间至少保留该倍率 × 时长，避免「很慢」的观感
  spaceRatio: 1.0,
};

// ---- 画面运动（参考 画面运动.json：缓慢推近）----
const PUSH = { from: 1.0, to: 1.10, inSec: 3.6, outSec: 2.0 };

// ---- vox 拼贴 b-roll（用户另一条参考片：深底 + 奶油纸双色地）----
const BROLL = {
  bg: C.ink,
  plate: C.paper,
  ring: C.gold,
  // 圆形 PIP 几何 —— 唯一真相，build-composition.js 直接读这里（别再各写一份）
  //   cx/cy/r  圆孔圆心与半径（画布 px）
  //   scale    源视频缩放；tx/ty 取景对准的源画面点（= 头部中心，逐像素实测）
  //   soft     孔边缘柔化宽度
  pip: { cx: 810, cy: 380, r: 230, scale: 0.70, tx: 522, ty: 761 },
  // 蒙版元素要比画布**外扩**这么多 px。因为蒙版既要缩放（最大 5.8×）又要平移（孔心跟头），
  // 只留 inset:0 的话，缩放+平移之后元素盖不满画布，边缘会露出没被蒙版遮住的原始视频。
  pipPad: 600,
  // 圆形蒙版的进出场 = **两段式光圈**（几何可行性见 scratch/iris-sim.js，全程 0px 露黑）
  //   A 段 pipMoveSec：视频从 PIP 取景恢复全画幅；孔半径按 1/scale 等比放大（取景比恒定，
  //                    头恒定占孔径 67%），孔心从圆孔位置跟到头部在全画幅下的真实位置。
  //   B 段 pipIrisSec：视频已全画幅，孔**原地**胀到盖住四角 → 蒙版整块不可见，
  //                    因此退场**不需要淡出**，也就没有「暗角残影」（旧版 2.0× 只放大到
  //                    半径 460，盖不满画布，淡出时留下一个清晰可见的亮圆盘）。
  //   ⚠ 单段「边平移边张开」已证伪：中段孔会越出视频元素边界 223px → 露黑。
  pipMoveSec: 0.38,
  pipIrisSec: 0.34,
  pipIrisPad: 1.06,   // 覆盖四角的余量系数
  pipSoft: 10,

  // ── 背景质感（用户：「现在每次的背景有些寡淡，可以是黑色背景，但是可以模仿这种背景：
  //    相关对应文案的 b-roll 素材不透明度拉低，然后加上这种针点波纹效果的背景很有质感」）──
  //   三层结构（自下而上）：纯黑底 → 该版面内容的模糊剪影（ghost）→ 静态针点点阵 + 扩散点环。
  //   剪影用**同一份版面内容的去文字副本**（文字会触发 contrast 通道误报，故只留盒子几何），
  //   重模糊 + 低不透明度 → 读起来就是「这条文案对应的素材做了个暗底」。
  ghostOpacity: 0.17,
  ghostBlur: 30,
  ghostScale: 1.10,
  dotPitch: 26,       // 点阵步距 px
  dotR: 1.7,          // 点半径 px
  dotAlpha: 0.13,     // 点的不透明度（黑底上要很淡，只出质感不抢内容）
  // 针点波纹：若干「点环」（dotted 圆边框）从中心一圈圈胀开又消失。
  // ⚠ 只能动 scale / opacity —— 这是 hyperframes 允许动画的属性集，且逐帧 seek 安全。
  //   用 GSAP 的 repeat 会破坏「时间轴 = 绝对时间」的前提，所以是「按版面时长铺满若干圈」而不是循环。
  rippleSize: 620,    // 点环基准直径 px（再乘 scale）
  rippleFrom: 0.30,
  rippleTo: 1.55,
  rippleSpan: 2.20,   // 单圈从生到灭的时长
  rippleGap: 0.85,    // 圈与圈的错峰
  rippleMax: 5,
  rippleAlpha: 0.42,

  // ── 出场方式轮换 ──
  // 用户：「出场效果现在不错，但是每次都是这样展开放大也有点奇怪，可以换换其他方式丝滑出场」。
  // 所有出场都是**两段式**：
  //   A 段（pipMoveSec）人像窗归位、视频长回全画幅、内容淡出；
  //   B 段（pipIrisSec / exitSlideSec）把暗层收掉，按版面轮换：
  //     iris        光圈原地胀满画布（蒙版自然消失，无需淡出）
  //     slide-*     暗层整块滑出画布（擦除式）—— 此时视频已全画幅，滑走后自然露出人像，不会露黑边
  // 排列取自 plan.js 各版面的 exit 字段，保证相邻版面不同款。
  exitSlideSec: 0.54,
};

// ---- 缓动：cubic-bezier(0.42, 0, 0.58, 1) ----
// 生成到合成脚本里的源码（GSAP 接受函数型 ease，可精确复刻剪映贝塞尔）
const EASE_SRC = `
      function cubicBezier(x1, y1, x2, y2) {
        var A = function (a, b) { return 1 - 3 * b + 3 * a; };
        var B = function (a, b) { return 3 * b - 6 * a; };
        var Cc = function (a) { return 3 * a; };
        var calc = function (t, a, b) { return ((A(a, b) * t + B(a, b)) * t + Cc(a)) * t; };
        var slope = function (t, a, b) { return 3 * A(a, b) * t * t + 2 * B(a, b) * t + Cc(a); };
        return function (x) {
          if (x <= 0) return 0;
          if (x >= 1) return 1;
          var t = x;
          for (var i = 0; i < 10; i++) {
            var e = calc(t, x1, x2) - x;
            if (Math.abs(e) < 1e-6) break;
            var s = slope(t, x1, x2);
            if (Math.abs(s) < 1e-6) break;
            t -= e / s;
          }
          return calc(t, y1, y2);
        };
      }
      var EASE = cubicBezier(0.42, 0, 0.58, 1);   // 参考工程 curveType=Bezier 控制点复刻
      var EASE_IN = cubicBezier(0.42, 0, 1, 1);   // 出点
`;

// ---- 语义音效 ----
// 音源全部由 build-sfx.sh 用 ffmpeg lavfi/aevalsrc 合成（无外部素材，任何机器可重建）。
// 数值 = 音源实际时长（ffprobe format.duration），必须与文件一致，否则 <audio data-duration> 会截断。
const SFX = {
  'whoosh-soft': 0.55, 'whoosh-deep': 0.70, 'whoosh-thin': 0.34,
  tick: 0.08, pop: 0.16, 'paper-flip': 0.42, keyboard: 0.75, ding: 0.70,
  // 第二批 —— 对应脑图《动画音效搭配逻辑》的 12 类动效
  land: 0.34, boom: 0.42, thud: 0.30, sparkle: 0.37,
  'water-drop': 0.60, 'water-soft': 0.95, magic: 0.59, 'tap-soft': 0.14,
  'paper-shake': 0.34, fan: 0.30, gear: 0.44, coin: 0.36,
  wobble: 0.34, bo: 0.18, spring: 0.45, 'variety-in': 0.60,
  radio: 0.26, 'bell-wood': 0.60,
};

// 动效语义 → 音源。键名 = 脑图里的动效类别，注释里的「」= 脑图给出的音效词。
// 这是全片音效的唯一真相：build-composition.js 只认 key，不直接写文件名。
const SFX_ROLE = {
  // ── 位移（上下左右）→ 嗖、呼、唰、落地
  move: 'whoosh-soft',        // 「呼」常规位移（元素上滑落位）
  'move-fast': 'whoosh-thin', // 「唰」快速 / 轻扫位移（左右展开、标题条滑入）
  'move-deep': 'whoosh-deep', // 「嗖」大幅位移 / 整层推入
  land: 'land',               // 「落地」位移落定（后半句落定的那一记）
  // ── 缩放（放大缩小）→ 嘭、砰、咚、闪光
  'zoom-in': 'boom',          // 「嘭」放大（圆形蒙版张开、后半句放大覆盖）
  'zoom-out': 'thud',         // 「咚」缩小 / 收拢（圆窗收拢到人脸上）
  flash: 'sparkle',           // 「闪光」缩放峰值（重点词强调）
  // ── 模糊 → 水滴、魔法、综艺悬疑轻敲
  blur: 'magic',              // 「魔法」虚化 / 柔化
  suspense: 'tap-soft',       // 「综艺悬疑轻敲」
  // ── 折叠、开屏、收拢 → 纸张、纸张抖动、折扇展开
  paper: 'paper-flip',        // 「纸张」卡片铺开
  'paper-shake': 'paper-shake', // 「纸张抖动」
  fan: 'fan',                 // 「折扇展开」
  // ── 滚动类 → 钱相关、齿轮
  coin: 'coin',               // 「钱相关」
  gear: 'gear',               // 「齿轮」逐行滚动 / 列表错峰
  // ── 波纹（晕开、吸入）→ 水滴相关
  ripple: 'water-drop',       // 「水滴」波纹晕开
  // ── 翻转、翻动 → 抖动、啵
  wobble: 'wobble',           // 「抖动」
  flip: 'bo',                 // 「啵」
  // ── 弹簧 → 咚咚
  spring: 'spring',
  // ── 跃入 → 综艺开始系统提示音
  'jump-in': 'variety-in',
  // ── 字幕歪到正 → 收音机声音
  'snap-upright': 'radio',
  // ── 渐隐 → 水滴
  fade: 'water-soft',
  // ── 生长 → 突然敲得木质铃铛响一下
  grow: 'bell-wood',
  // ── 兼容旧语义
  structure: 'whoosh-soft', emphasis: 'ding', counter: 'pop',
  text: 'keyboard', confirm: 'tick', open: 'whoosh-deep', lift: 'whoosh-thin',
};

// 音效音量：越「重」的动效越响。SOP：不要过于频繁、只挑重点 —— 所以重的音只在
// 跃入 / 缩放 / 章节切换出现，铺陈类（水滴、渐隐）压低到人声之下。
const SFX_VOL = {
  'jump-in': 0.21, 'zoom-in': 0.21, 'zoom-out': 0.19, flash: 0.16,
  land: 0.18, 'move-fast': 0.16, move: 0.15, 'move-deep': 0.18,
  structure: 0.17, open: 0.20, lift: 0.14,
  ripple: 0.14, fade: 0.12, grow: 0.15, gear: 0.14, coin: 0.15,
  paper: 0.15, 'paper-shake': 0.14, fan: 0.16,
  emphasis: 0.22, counter: 0.17, confirm: 0.14, text: 0.15,
};

module.exports = { W, H, FPS, DUR, U, px, PX, C, F, CAPTION, EMPHASIS, TITLE, COMBO, comboRows, MOTION, PUSH, BROLL, EASE_SRC, SFX, SFX_ROLE, SFX_VOL };
