#!/usr/bin/env node
/** cut-segments.js — 按 jianying/cut-plan.json 批量切视频段（4 路并行写 4 个 sh）。 */
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const DUR = 160.28;
const cp = require(path.join(ROOT, 'jianying/cut-plan.json'));

const fwd = (p) => p.replace(/\\/g, '/');
const cmds = cp.map((s) => {
  const start = s.start.toFixed(3);
  const end = Math.min(s.end + 0.08, DUR).toFixed(3); // 尾巴垫 80ms 防露黑
  return `ffmpeg -y -v error -ss ${start} -to ${end} -i "${fwd(s.src)}" -c:v libx264 -preset veryfast -crf 18 -r 50 -c:a aac -b:a 192k -ar 48000 "${fwd(s.out)}"`;
});

for (let k = 0; k < 4; k++) {
  fs.writeFileSync(path.join(ROOT, `jianying/cut-${k}.sh`), cmds.filter((_, i) => i % 4 === k).join('\n') + '\n');
}
console.log(`4 scripts written, ${cmds.length} cmds`);
