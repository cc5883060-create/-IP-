#!/usr/bin/env node
/**
 * build-jianying-plan.js — 把 v6 剪辑方案编译成 jianying-assistant 的输入。
 *
 * 产出（写到 jianying/）：
 *   cut-plan.json    —— 每段从哪个源文件切哪段（供 ffmpeg 批量切条）
 *   storyboard.json  —— 分镜 + 字幕（每镜一条原生字幕；b-roll 镜不挂，字幕已烧在画面里）
 *   materials.json   —— 每镜素材（本机占位 URL）
 *
 * 规则：
 *   - 时间线切点 = 字幕行(base/layout)入出点 ∪ b-roll 窗口 ∪ {0, DUR}
 *   - b-roll 窗口 = 单镜（画面取自 render-v6-video-only，含烧入字幕与包装设计）
 *   - b-roll 之外：每条字幕行一镜；行间隔 < 0.4s 并入前镜（字幕稍拖尾，行业常态）；
 *     ≥ 0.4s 的间隔 = 无字幕镜
 *   - 字幕行跨 b-roll 边界时在边界处断开，b-roll 侧并入 b-roll 镜
 */
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const OUT = path.join(ROOT, 'jianying');
fs.mkdirSync(OUT, { recursive: true });

const DUR = 160.28;
const GAP_MERGE = 0.4;
// a-roll 与 b-roll 都切自「无字幕包装版」：
//   · 口播段保留章节标题/斜切底板（口播画面包装）
//   · b-roll 段保留版面设计但**不含字幕**（字幕交给剪映原生文本轨）
const SRC_MAIN = path.join(ROOT, 'scratch/render-v7-clean-noaudio.mp4');
const SRC_BROLL = path.join(ROOT, 'scratch/render-v7-clean-noaudio.mp4');

const cues = require('./subtitles.timeline.json')
  .filter((c) => c.kind === 'base' || c.kind === 'layout')
  .map((c) => ({ start: c.startTime, end: c.endTime, text: c.text }))
  .sort((a, b) => a.start - b.start);

const P = require('./plan.js');
const brolls = P.BROLL_PLAN.map((b) => ({ id: b.id, t0: b.t0, t1: b.t1 })).sort((a, b) => a.t0 - b.t0);

// ── 1. 切点
const pts = new Set([0, DUR]);
for (const b of brolls) { pts.add(b.t0); pts.add(b.t1); }
for (const c of cues) { pts.add(c.start); pts.add(c.end); }
const cuts = [...pts].filter((t) => t >= 0 && t <= DUR).sort((a, b) => a - b);

// ── 2. 基本区间 → 属性
const inBroll = (t) => brolls.find((b) => t >= b.t0 && t < b.t1);
const lineAt = (s, e) => cues.find((c) => s >= c.start - 1e-6 && e <= c.end + 1e-6);

let intervals = [];
for (let i = 0; i < cuts.length - 1; i++) {
  const s = cuts[i], e = cuts[i + 1];
  if (e - s < 0.02 && intervals.length) { intervals[intervals.length - 1].end = e; continue; } // 零头并入前段，防累计漂移
  const br = inBroll((s + e) / 2);
  if (br) {
    intervals.push({ start: s, end: e, type: 'broll', broll: br.id, text: '' });
  } else {
    const ln = lineAt(s, e);
    intervals.push({ start: s, end: e, type: ln ? 'caption' : 'gap', text: ln ? ln.text : '' });
  }
}
if (intervals.length) intervals[intervals.length - 1].end = DUR; // 尾段顶到片长

// ── 3. 合并：相邻同 b-roll 合一；gap<0.4 并入前 caption 镜；其余 gap 独立
let shots = [];
for (const iv of intervals) {
  const prev = shots[shots.length - 1];
  if (iv.type === 'broll' && prev && prev.type === 'broll' && prev.broll === iv.broll) {
    prev.end = iv.end; continue;
  }
  if (iv.type === 'gap' && prev && prev.type === 'caption' && iv.end - iv.start < GAP_MERGE) {
    prev.end = iv.end; continue;
  }
  if (iv.type === 'gap' && prev && prev.type === 'gap') { prev.end = iv.end; continue; }
  shots.push({ ...iv });
}

// ── 4. 编号 + 切条清单 + storyboard/materials
const segDir = path.join(OUT, 'segments');
fs.mkdirSync(segDir, { recursive: true });
const localURL = (p) =>
  'http://local.asset.invalid/__LOCAL__/' +
  p.replace(/\\/g, '/').split('/').map(encodeURIComponent).join('/');

const cutPlan = [];
const sbShots = [];
const mtShots = [];
shots.forEach((sh, i) => {
  const id = i + 1;
  const isB = sh.type === 'broll';
  const name = isB
    ? `broll-${sh.broll}-${sh.start.toFixed(2)}-${sh.end.toFixed(2)}.mp4`
    : `seg-${String(id).padStart(3, '0')}.mp4`;
  const file = path.join(segDir, name);
  cutPlan.push({ shot_id: id, src: isB ? SRC_BROLL : SRC_MAIN, start: sh.start, end: sh.end, out: file });
  const dur = +(sh.end - sh.start).toFixed(3);
  sbShots.push({
    shot_id: id,
    duration: dur,
    visual_desc: isB ? `b-roll 包装段 ${sh.broll}（画面含烧入字幕与设计，字幕不在文本轨）` : (sh.text ? `口播：${sh.text}` : '口播（语句间隙，无字幕）'),
    subtitle: { start: 0, end: dur, text: isB ? '' : sh.text },
  });
  mtShots.push({
    shot_id: id,
    video_url: localURL(file),
    image_url: null,
    fallback: false,
    video_engine: 'user',
    image_engine: 'user',
  });
});

const total = sbShots.reduce((a, s) => a + s.duration, 0);
fs.writeFileSync(path.join(OUT, 'cut-plan.json'), JSON.stringify(cutPlan, null, 2));
fs.writeFileSync(path.join(OUT, 'storyboard.json'), JSON.stringify({
  aspect_ratio: '9:16', resolution: '1080p', tts_enabled: false, shots: sbShots,
}, null, 2));
fs.writeFileSync(path.join(OUT, 'materials.json'), JSON.stringify({
  shots: mtShots, image_engine: 'user', video_engine: 'user',
  resolution: '1080p', ratio: '9:16', fallback_count: 0,
}, null, 2));

const nB = shots.filter((s) => s.type === 'broll').length;
const nC = shots.filter((s) => s.type === 'caption').length;
const nG = shots.filter((s) => s.type === 'gap').length;
console.log(`shots: ${shots.length} (caption=${nC} broll=${nB} gap=${nG})  total=${total.toFixed(2)}s (target ${DUR})`);
