# talking-head-luxe-packaging

**口播视频「轻奢质感」自动包装管线** —— 输入一支粗剪好的真人出镜口播视频（MP4）+ SRT 字幕稿，输出带完整包装的竖屏成片（1080×1920），并可一键转换成**剪映（JianyingPro）可继续编辑的原生草稿**。

```text
粗剪口播 MP4 + SRT
        │
        ▼
 ① 源素材审计（构图 / 帧率 / 音频电平）
 ② 字幕层：断句 → 基础字幕 / 重点词强调 / 排版组合 三层体系
 ③ 包装计划（plan.js）：章节标题 · 排版组合 · b-roll 版面 · 音效落点
 ④ HTML 合成构建（GSAP 时间线 + 针点波纹背景 + 圆窗/手机样机/REC 取景框）
 ⑤ 门禁校验（layout / overflow / tween 冲突）
 ⑥ 渲染 + 外挂混音（人声 + BGM + 语义音效）
        │
        ├──▶ 成片 MP4（烧入字幕版）
        │
        └──▶ ⑦ 剪映草稿：无字幕包装版切段 → 原生字幕轨
                + 排版组合轨（三种式样的原生关键帧）
                + 音效轨 + BGM 轨
```

## 它能做什么

| 层 | 能力 |
| --- | --- |
| 字幕 | 黑底白字三层体系：基础字幕（y=0.600，12 号=72px）/ 重点词金色强调（逐词可改色）/ 排版设计组合 |
| 排版组合 | **上下式**（后句落前句下方）、**前后式**（后句覆盖放大+金色）、**左右式**（后句右展、前句左让），位移由后半句重点词触发 |
| 章节标题 | 拉丁徽标（TIPS/RULES）+ 斜切底板 + 金色描边 |
| b-roll | 圆窗 PIP / 手机样机 / REC 取景框 / 纯内容四种形态，出场方式逐版面轮换（iris / slide / fade） |
| 背景 | 深色底 + 内容低透明度底纹 + 针点波纹 |
| 音频 | 语义音效（位移=嗖、缩放=重音、打字=键盘声…只挑重点）、BGM 垫乐、片头淡入片尾淡出 |
| 剪映交付 | 96 镜视频轨 + 110 行原生富文本字幕 + 31 段排版组合（原生关键帧）+ 70 点音效轨，全部可在剪映里继续编辑 |

## 快速开始

### 依赖

- Node.js ≥ 20（构建脚本）
- Python ≥ 3.10 + `mutagen`（剪映草稿后处理）
- FFmpeg（切段 / 混音 / 验证）
- [HyperFrames CLI](https://www.npmjs.com/package/hyperframes)（渲染）：`npm i -g hyperframes`
- 剪映（JianyingPro）桌面版 + [jianying-assistant](https://github.com/) 技能（仅剪映草稿交付需要，走云端组装服务）

### 跑一遍

```bash
# 1) 建项目并放素材
mkdir -p videos/my-video && cd videos/my-video
cp <skill根>/scripts/engine/*.js .
cp -r <skill根>/assets/{sfx,vendor} public/
cp -r <skill根>/assets/fonts-master assets-src/fonts/

# 2) 字幕层（SRT → subtitles.timeline.json）
node build-subtitles.js my.srt

# 3) 写本片的 plan.js（参照 scripts/engine/plan.template.js，
#    填 SECTIONS / COMBO_PLAN / BROLL_PLAN / SFX_CONTENT_ACCENTS）

# 4) 构建 + 字体子集化 + 设计预览
node build-composition.js
node subset-fonts.js
node build-design-preview.js

# 5) 门禁
hyperframes lint public
hyperframes check public --at-transitions

# 6) 渲染（只出画面）+ 外挂混音（音频必须外挂，渲染器会丢多音轨）
hyperframes render public -o out.mp4 -q delivery --video-bitrate 9500k -f 50
node build-audio-mix.js
```

### 转剪映草稿

```bash
# 画面必须切自「无字幕包装版」（保留章节标题/b-roll，去掉字幕层）
HIDE_CAPTIONS=1 node build-composition.js && hyperframes render public -o clean.mp4 ...
node build-jianying-plan.js     # 分镜与切点
node cut-segments.js            # 4 路并行切段
node dump-combo-rows.js         # 排版组合几何导出（成片同源）
# jianying-assistant: assemble_draft → download_draft（临时目录）
python post-process-draft.py --draft-dir <临时草稿> --work .
# 复制到剪映草稿目录并递归重写素材路径（详见 WORKBUDDY_SKILL.md）
```

## 目录结构

```text
├── README.md                  本文件
├── LICENSE                    MIT（代码与文档）
├── WORKBUDDY_SKILL.md         WorkBuddy 技能清单（本仓库同时是一个可安装的 skill）
├── scripts/
│   ├── engine/                合成引擎：theme / build-subtitles / build-composition /
│   │                          build-audio-mix / subset-fonts / type-metrics / patch-dsl …
│   └── jianying/             剪映交付链：build-jianying-plan / cut-segments /
│                              dump-combo-rows / post-process-draft / build-sfx-sheet
├── references/
│   ├── pipeline.md            管线操作手册（环境坑 / 命令 / 门禁 / QA）
│   └── design-system.md       设计系统契约（六轮返工沉淀的审美硬规则）
└── assets/
    ├── sfx/                   26 个语义音效（FFmpeg lavfi 合成，可自由分发）
    ├── vendor/gsap.min.js     GSAP（见其官方许可）
    └── fonts-master/          思源宋体 Heavy / Regular（SIL OFL 1.1，附许可证）
```

## 字体说明（重要）

本管线设计基准的另外几款字体（俊雅体、华光中长宋、特黑、细体、研宋等）为**商业授权字体，不随仓库分发**。若你的工作流需要同款效果：

1. 把已获授权的字体文件放进 `assets/fonts-master/`；
2. 或修改 `scripts/engine/theme.js` 的字体令牌指向你机器上已有的字体；
3. 剪映草稿侧默认使用 Windows 自带的微软雅黑（Light / Bold），无需额外字体。

## 设计口径摘录

完整契约见 `references/design-system.md`，几条硬规则：

- 每行字幕 10–15 字（≤16 硬限制）；CJK 字宽**必须读字体度量**（俊雅体推进仅 0.75em，按 1em 估会宽 33%）。
- 排版组合的位移由**后半句的重点词**触发，不能提前。
- 音效「不要过于频繁，只挑重点」；越重的动效越响（0.12–0.21 分档）。
- iris 出场只能用于带圆孔的 PIP 版面；fade 必须同步 scale×1.5。
- 导出 1080p / H.264 / ≈9500kbps / 帧率与拍摄一致。

## License

- 代码与文档：[MIT](LICENSE)
- 思源宋体：SIL OFL 1.1（见 `assets/fonts-master/OFL-LICENSE.txt`）
- GSAP：遵循其[官方许可](https://gsap.com/pricing/)
