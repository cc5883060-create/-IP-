"""Validate structural invariants; never certifies semantic or visual quality."""
import argparse,json,math
from pathlib import Path

PROPS={'position_x','position_y','uniform_scale','rotation','alpha'}
def validate(p,check_files=False):
 errors=[]
 if not isinstance(p,dict):return ['Plan must be an object']
 def number(v):return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v)
 def need(ok,message):
  if not ok:errors.append(message)
 allowed={'name','duration','canvas','baseline','fonts','media','texts','layouts','notes'}
 need(not set(p)-allowed,'Unsupported top-level fields: '+str(set(p)-allowed))
 duration=p.get('duration',0);need(number(duration) and duration>0,'duration must be positive')
 if not number(duration) or duration<=0:return errors
 name=p.get('name');need(isinstance(name,str) and bool(name.strip()) and name not in ['.','..'] and not name.endswith(('.', ' ')) and all(c not in name for c in '/\\:*?"<>|'),'name must be a safe folder name')
 for section in ['media','texts','layouts']:
  if not isinstance(p.get(section,[]),list):return errors+[section+' must be an array']
 for section,keys in [('canvas',{'width','height','fps'}),('baseline',{'confirmed','x','y'})]:
  if not isinstance(p.get(section,{}),dict):return errors+[section+' must be an object']
  need(not set(p.get(section,{}))-keys,'Unsupported '+section+' fields')
 for v in p.get('canvas',{}).values():need(number(v) and v>0,'canvas values must be positive numbers')
 base=p.get('baseline',{});need(base.get('confirmed') is True,'Baseline must already be confirmed')
 need(base.get('x',.5)==.5,'Base horizontal center must be 0.5')
 fonts=p.get('fonts',{});tracks={}
 if not isinstance(fonts,dict):return errors+['fonts must be an object']
 for section in ['media','texts']:
  for i,row in enumerate(p.get(section,[])):
   if not isinstance(row,dict):errors.append(section+' entries must be objects');continue
   prefix=f'{section}[{i}]';a=row.get('start',-1);b=row.get('end',-1)
   if not(number(a) and number(b) and 0<=a<b<=duration):errors.append(prefix+' invalid time range');continue
   if section=='texts':
    valid={'text','start','end','track','render_index','role','font','size','x','y','color','highlight','highlight_color','intro','intro_duration','keyframes','source_ids','original','layout_group'}
    need(row.get('font') in fonts,prefix+' unresolved font')
    need(bool(row.get('text')),prefix+' empty text')
    if row.get('role')=='base':need(row.get('x',.5)==.5,prefix+' base text is off center')
    if row.get('highlight'):need(row['highlight'] in row['text'],prefix+' highlight is absent')
   else:
    valid={'path','type','start','end','source_start','speed','volume','track','render_index','transform','crop','keyframes','fade_in','fade_out'}
    need(row.get('type') in ['video','image','audio'],prefix+' unsupported media type')
    if check_files:need(Path(row.get('path','')).is_file(),prefix+' missing media')
    if row.get('type')=='audio':need(not row.get('keyframes'),prefix+' audio keyframes not supported by this adapter')
    need(number(row.get('speed',1)) and row.get('speed',1)>0,prefix+' invalid speed')
    transform=row.get('transform',{})
    if not isinstance(transform,dict):errors.append(prefix+' transform must be an object');continue
    need(not set(transform)-{'x','y','scale','rotation','alpha'},prefix+' unsupported transform fields')
    need(all(number(v) for v in transform.values()),prefix+' invalid transform number')
    crop=row.get('crop')
    if crop is not None:
     if not isinstance(crop,dict):errors.append(prefix+' crop must be an object');continue
     need(row.get('type')!='audio',prefix+' audio cannot be cropped')
     need(set(crop)=={'left','top','right','bottom'},prefix+' crop requires left/top/right/bottom')
     need(all(number(v) for v in crop.values()),prefix+' invalid crop number')
     if set(crop)=={'left','top','right','bottom'} and all(number(v) for v in crop.values()):need(0<=crop['left']<crop['right']<=1 and 0<=crop['top']<crop['bottom']<=1,prefix+' invalid crop bounds')
   need(not set(row)-valid,prefix+' unsupported fields: '+str(set(row)-valid))
   track=row.get('track',prefix);tracks.setdefault(track,[]).append((a,b,prefix))
   for k in row.get('keyframes',[]):
    if not isinstance(k,dict):errors.append(prefix+' keyframe must be an object');continue
    need(not set(k)-{'property','times','values','easing'},prefix+' unsupported keyframe fields')
    need(k.get('property') in PROPS,prefix+' unsupported keyframe property')
    need(k.get('easing')=='ease_in_out',prefix+' adapter requires explicit eased keyframes')
    ts=k.get('times',[]);vs=k.get('values',[])
    need(len(ts)==len(vs) and len(ts)>=2,prefix+' keyframe list length mismatch')
    need(all(number(t) and a<=t<=b for t in ts) and all(number(x) and number(y) and x<y for x,y in zip(ts,ts[1:])),prefix+' keyframes out of range/order')
    need(all(number(v) for v in vs),prefix+' invalid keyframe value')
 for track,rows in tracks.items():
  rows.sort()
  for x,y in zip(rows,rows[1:]):need(x[1]<=y[0]+1e-6,f'overlap on track {track}: {x[2]}, {y[2]}')
 for key,f in fonts.items():
  if not isinstance(f,dict):errors.append('font must be an object');continue
  need(not set(f)-{'name','path'},'unsupported font fields')
  if check_files:need(Path(f.get('path','')).is_file(),'Missing font '+key)
 groups=p.get('layouts',[])
 for g in groups:
  if not isinstance(g,dict):return errors+['layout must be an object']
  need(g.get('type') in ['up_down','front_back','left_right'],'Unsupported layout type')
  need(number(g.get('start')),'layout start must be a number')
 for kind in ['up_down','front_back','left_right']:
  ts=[g['start'] for g in groups if g.get('type')==kind and number(g.get('start'))]
  for t in ts:need(sum(t<=u<t+60 for u in ts)<=2,f'{kind} exceeds 2 groups within rolling 60 seconds at {t}')
 return errors

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('plan');ap.add_argument('--check-files',action='store_true');args=ap.parse_args()
 errors=validate(json.loads(Path(args.plan).read_text(encoding='utf-8')),args.check_files)
 print(json.dumps({'structure_passed':not errors,'errors':errors,'visual_verified':False,'speech_verified':False,'native_app_verified':False},ensure_ascii=False,indent=2))
 raise SystemExit(1 if errors else 0)
