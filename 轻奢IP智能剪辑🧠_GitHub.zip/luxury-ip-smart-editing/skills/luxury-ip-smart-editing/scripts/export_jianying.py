"""Optional JyWrapper adapter. Does not install runtime or update app indexes."""
import argparse,hashlib,json,os,sys,time,uuid
from pathlib import Path
from validate_plan import validate

def write(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('plan');ap.add_argument('--output',required=True);ap.add_argument('--runtime-root',default=os.getenv('JY_SKILL_ROOT',''));args=ap.parse_args()
 plan=json.loads(Path(args.plan).read_text(encoding='utf-8'));errors=validate(plan,True)
 if errors:raise SystemExit('\n'.join(errors))
 runtime=Path(args.runtime_root)/'scripts'
 if not (runtime/'jy_wrapper.py').is_file():raise SystemExit('Provide a compatible JyWrapper skill directory through --runtime-root or JY_SKILL_ROOT.')
 sys.path.insert(0,str(runtime));from jy_wrapper import JyProject
 import pyJianYingDraft as d
 root=Path(args.output).resolve();dest=root/plan['name']
 if dest.exists():raise SystemExit('Refusing to overwrite an existing draft: '+str(dest))
 # Check requested intro resources before creating anything.
 for r in plan.get('texts',[]):
  if r.get('intro') and not hasattr(d.TextIntro,r['intro']):raise SystemExit('Unsupported intro: '+r['intro'])
 canvas=plan.get('canvas',{});width=canvas.get('width',1080);height=canvas.get('height',1920)
 root.mkdir(parents=True,exist_ok=True);p=JyProject(plan['name'],width=width,height=height,drafts_root=str(root),overwrite=False);p.script.fps=canvas.get('fps',30)
 tracktypes={};material_rows={};dependencies=set();library=[]
 def track(name,kind,index):
  if name in tracktypes:
   if tracktypes[name]!=kind:raise ValueError('Mixed track types: '+name)
  else:p.script.add_track(kind,name,absolute_index=index);tracktypes[name]=kind
 def keyframes(seg,r):
  for channel in r.get('keyframes',[]):
   for t,v in zip(channel['times'],channel['values']):seg.add_keyframe(getattr(d.KeyframeProperty,channel['property']),round((t-r['start'])*1e6),v,**d.Keyframe.EASE_IN_OUT)
 def clip(transform):
  return d.ClipSettings(transform_x=2*transform.get('x',.5)-1,transform_y=1-2*transform.get('y',.5),scale_x=transform.get('scale',1),scale_y=transform.get('scale',1),rotation=transform.get('rotation',0),alpha=transform.get('alpha',1))
 for i,r in enumerate(plan.get('media',[])):
  path=str(Path(r['path']).resolve());dependencies.add(path);tr=d.Timerange(round(r['start']*1e6),round((r['end']-r['start'])*1e6));name=r.get('track','Media_'+str(i))
  if r['type']=='audio':
   track(name,d.TrackType.audio,r.get('render_index',0));mat=d.AudioMaterial(path);source=d.Timerange(round(r.get('source_start',0)*1e6),round(tr.duration*r.get('speed',1)))
   seg=d.AudioSegment(mat,tr,source_timerange=source,volume=r.get('volume',1));seg.add_fade(round(r.get('fade_in',0)*1e6),round(r.get('fade_out',0)*1e6))
  else:
   track(name,d.TrackType.video,r.get('render_index',0));crop=r.get('crop');matargs={}
   if crop:matargs['crop_settings']=d.CropSettings(upper_left_x=crop['left'],upper_left_y=crop['top'],upper_right_x=crop['right'],upper_right_y=crop['top'],lower_left_x=crop['left'],lower_left_y=crop['bottom'],lower_right_x=crop['right'],lower_right_y=crop['bottom'])
   mat=d.VideoMaterial(path,**matargs);kw={}
   if r['type']=='video':kw['source_timerange']=d.Timerange(round(r.get('source_start',0)*1e6),round(tr.duration*r.get('speed',1)))
   seg=d.VideoSegment(mat,tr,volume=r.get('volume',1),clip_settings=clip(r.get('transform',{})),**kw);keyframes(seg,r)
  p.script.add_segment(seg,name)
 for i,r in enumerate(plan.get('texts',[])):
  name=r.get('track','Text_'+str(i));track(name,d.TrackType.text,r.get('render_index',14000));size=r.get('size',12);spans=[]
  if r.get('highlight'):
   at=r['text'].index(r['highlight']);end=at+len(r['highlight'])
   if at:spans.append(d.RichTextSpan(0,at))
   spans.append(d.RichTextSpan(at,end,color=tuple(r.get('highlight_color',[1,.8,.51])),size=size*1.12))
   if end<len(r['text']):spans.append(d.RichTextSpan(end,len(r['text'])))
  seg=p.add_text_simple(r['text'],round(r['start']*1e6),round((r['end']-r['start'])*1e6),name,style=d.TextStyle(size=size,color=tuple(r.get('color',[1,1,1])),align=1),border=None,shadow=d.TextShadow(alpha=.6,diffuse=10,distance=5,angle=14),clip_settings=clip({'x':r.get('x',.5),'y':r.get('y',plan['baseline'].get('y',.6))}),rich_spans=spans)
  if r.get('intro'):seg.add_animation(getattr(d.TextIntro,r['intro']),duration=round(r.get('intro_duration',.2)*1e6))
  keyframes(seg,r);material_rows[seg.material_id]=r
 p.save()
 raw=json.loads((dest/'draft_info.json').read_text(encoding='utf-8'));raw['id']=str(uuid.uuid4()).upper();raw['config']['subtitle_sync']=True;batch='import_'+str(uuid.uuid4().int)
 raw['materials']['texts']=list({m['id']:m for m in raw['materials']['texts']}.values())
 for mat in raw['materials']['texts']:
  r=material_rows[mat['id']];font=plan['fonts'][r['font']];path=str(Path(font['path']).resolve());dependencies.add(path);content=json.loads(mat['content'])
  for st in content['styles']:st['font']={'path':path,'id':''};st['strokes']=[];st['shadows']=[d.TextShadow(alpha=.6,diffuse=10,distance=5,angle=14).export_json()]
  mat.update(content=json.dumps(content,ensure_ascii=False),font_path=path,font_name=font['name'],font_size=r.get('size',12),text_size=round(r.get('size',12)*6),border_width=0,has_shadow=True,shadow_alpha=.6,shadow_smoothing=.1)
  if r.get('role')=='base':mat.update(type='subtitle',add_type=2,sub_type=0,group_id=batch,layer_weight=1,recognize_type=0,recognize_task_id='',recognize_text='',relevance_segment=[],words={'start_time':[],'end_time':[],'text':[]},current_words={'start_time':[],'end_time':[],'text':[]},is_rich_text=bool(r.get('highlight')),is_lyric_effect=False,is_words_linear=False)
  else:mat['type']='text';mat.pop('group_id',None)
 for name in ['draft_info.json','draft_content.json']:write(dest/name,raw)
 meta=json.loads((dest/'draft_meta_info.json').read_text(encoding='utf-8'));now=int(time.time()*1e6);meta.update(draft_id=raw['id'],draft_name=plan['name'],draft_root_path=str(root),draft_fold_path=str(dest),tm_duration=round(plan['duration']*1e6),tm_draft_create=now,tm_draft_modified=now)
 seen=set()
 for kind in ['videos','audios']:
  for m in raw['materials'][kind]:
   mid=m.get('local_material_id') or m['id']
   if mid in seen:continue
   seen.add(mid);path=Path(m['path'])
   library.append(dict(id=mid,file_Path=str(path),extra_info=path.name,duration=m.get('duration',0),width=m.get('width',0),height=m.get('height',0),type=0,metetype='none',import_time=int(time.time()),create_time=int(path.stat().st_ctime),md5='',enter_from=0,item_source=1,roughcut_time_range={'start':-1,'duration':-1},sub_time_range={'start':-1,'duration':-1}))
 meta['draft_materials']=[{'type':0,'value':library}];write(dest/'draft_meta_info.json',meta)
 write(dest/'draft_virtual_store.json',{'draft_materials':meta['draft_materials'],'draft_virtual_store':[{'type':0,'value':[]},{'type':1,'value':[{'child_id':m['id'],'parent_id':''} for m in library]},{'type':2,'value':[]}]})
 hashes=[]
 for name in sorted(dependencies):
  f=Path(name);h=hashlib.sha256()
  with f.open('rb') as stream:
   for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
  hashes.append({'path':name,'size':f.stat().st_size,'sha256':h.hexdigest()})
 write(dest/'media_dependencies.json',hashes);write(dest/'verification.json',{'structure_exported':True,'native_app_verified':False,'subtitle_linkage_verified':False,'audio_listened':False,'external_assets':True,'auto_installed_in_app':False})
 print(str(dest))
if __name__=='__main__':main()
