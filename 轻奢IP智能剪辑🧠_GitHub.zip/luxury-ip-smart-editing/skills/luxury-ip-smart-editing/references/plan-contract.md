# 可执行计划契约

计划校验只检查可确定的结构，不判断句意好坏、字体美观或重音。坐标x/y归一化，原点左上；时间为全局秒。关键帧position_x/position_y采用剪映中心坐标（x向右、y向上，-1到1），不是0–1画面坐标；转换要明确。uniform_scale是倍率。

顶层字段：name、duration、canvas（width/height/fps）、baseline（confirmed/x/y）、fonts、media、texts、layouts、notes。不认识的顶层或片段字段拒绝，不静默丢弃。

fonts是字典，每项含真实path与name。media每项含path、type(video/image/audio)、start/end；可设source_start、恒定speed、volume、track、render_index、transform（x/y/scale/rotation/alpha）、keyframes；音频另有fade_in/fade_out（秒）。视频和图片另可设crop，含left/top/right/bottom四个0–1归一化边界，仅支持矩形裁切，不是圆形蒙版。基础视频常用render_index=0，后方字8000、透明前景9000、普通文字14000；这是适配器合成顺序，须软件内验证。

texts每项含text、start/end、font、role（base/title/emphasis/quote/layout等）、size、x/y、color（RGB 0–1）、track/render_index；可选highlight、highlight_color、intro（运行时枚举名称）、intro_duration、keyframes、source_ids、original、layout_group。只有role=base进入同批字幕联动。包装文字其他角色独立。

keyframes每通道：property、times、values、easing。支持position_x、position_y、uniform_scale、rotation、alpha；times绝对秒，导出时减片段起点。easing当前只接受ease_in_out。音频渐变使用fade_in/out，当前不接受任意音量关键帧。

layouts每组含type（up_down/front_back/left_right）、start以及可选结束、源序号、语义理由。以组的首个布局动作启动点计算滚动频次，多层不重复计数。不得拆分/合并记录以规避实际密度。

简例（演示字段，路径需换为真实文件，不是可直接执行的现成项目）：

```json
{
  "name": "口播独立草稿",
  "duration": 5,
  "canvas": {"width": 1080, "height": 1920, "fps": 30},
  "baseline": {"confirmed": true, "x": 0.5, "y": 0.6},
  "fonts": {"base": {"path": "实际字体文件路径", "name": "实际字体家族名"}},
  "media": [{"path": "实际视频文件路径", "type": "video", "start": 0, "end": 5, "volume": 1, "track": "原画原声"}],
  "texts": [{"text": "一句完整的话", "start": 0.4, "end": 3.5, "font": "base", "role": "base", "x": 0.5, "y": 0.6, "size": 12, "track": "基础字幕"}],
  "layouts": []
}
```

导出适配器依赖已有JyWrapper及其pyJianYingDraft运行时；它不负责语音识别、人物抠像、音效搜索、视觉预览或自动安装到剪映首页。那些步骤先完成，透明媒体/音频作为真实输入。脚本生成的是独立草稿文件夹，最终检查导入与播放。
